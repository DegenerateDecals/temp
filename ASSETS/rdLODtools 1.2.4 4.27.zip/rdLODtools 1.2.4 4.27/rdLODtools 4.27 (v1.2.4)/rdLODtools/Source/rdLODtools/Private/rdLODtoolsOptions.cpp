//
// rdLODtoolsOptions
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 3rd June 2019
// Last Modified: 1st March 2021
//
// Constructs/Handles the rdLODtools plugin Settings Window
//
// version 1.24
//		CHANGED: 27th Feb 2021 - removed Fake Shading from the settings
//
// version 1.21
//      CHANGED: 30 Mar 2020 - changed RootObjectCustomization to new 4.25 array arg
//
// version 1.2
//		FIXED: If there was no Source MeshDescription there would be a crash
//
//
// version 1.1
//		ADDED: 23 Jul 2019 - Icons for drop-down menu
//		ADDED: 23 Jul 2019 - Gamma setting
//		ADDED: 24 Jul 2019 - Methods to Remove LODs
//		ADDED: 25 Jul 2019 - Saving of LOD options to mesh taglist
//		ADDED: 26 Jul 2019 - option for baked lighting
//
#include "rdLODtoolsOptions.h"
#include "Runtime/Engine/Classes/Engine/StaticMesh.h"
#include "Editor/StaticMeshEditor/Public/IStaticMeshEditor.h"
#include "Runtime/MeshDescription/Public/MeshDescription.h"

//.............................................................................
//  Widget value helpers
//.............................................................................
inline FText getResComboString(int32 res) {
	return FText::FromString(*FString::Printf(TEXT("%dx%d"),res,res));
}

inline int32 getResComboInt(const FString& str) {

	FString s;
	int len=str.Len(),i=0;
	while(i<len && str[i]!=TCHAR('x')) s+=str[i++];
	
	int32 ret=FCString::Atoi(*s);
	return ret;
}

inline FText getMTypeComboString(int32 ret) {

	FString str[3]={TEXT("None"),TEXT("General Mesh"),TEXT("Foliage")};
	
	if(ret<=RDLOD_MESHTYPE_NONE || ret>=RDLOD_MESHTYPE_END) return FText::FromString(*str[1]);
	return FText::FromString(*str[ret]);
}

inline int32 getMTypeComboInt(const FString& str) {

	if(str.Contains(TEXT("Foliage"))) return RDLOD_MESHTYPE_FOLIAGE;
	return RDLOD_MESHTYPE_GENERAL;
}

inline FText getSourceLODComboString(int32 ret) {

	return FText::FromString(*FString::Printf(TEXT("%d"),ret));
}

inline int32 getSourceLODComboInt(const FString& str) {

	int32 ret=FCString::Atoi(*str);
	return ret;
}

//.............................................................................
// Options constructor
//.............................................................................
UrdLODtoolsOptions::UrdLODtoolsOptions() :	lodType(RDLOD_TYPE_NONE),meshType(RDLOD_MESHTYPE_GENERAL),sourceLOD(0),centrePivot(false),
											makeNormalMap(true),makeOtherMaps(false),
											maxLODs(1),
											numFrames(16),startAngle(-180.0),stopAngle(180.0),
											res(2048),screenSize(0.09),wind(false),shadows(true),
											copyMasters(false),renderTilt(0.0),meshTilt(0.0),meshZoom(1.0),inverseOpacity(false),
											removeLOD(0),removeExceptLOD(0),
											bDuplicateMesh(false),
											mesh(NULL) {
}

//----------------------------------------------------------------------------------------------------------------
// FPluginStyle - class for the rdLODtools Icon
//----------------------------------------------------------------------------------------------------------------
void FPluginStyle::Initialize() {

	if(StyleSet.IsValid()) {
		return;
	}

	StyleSet=MakeShared<FSlateStyleSet>(GetStyleSetName());
	StyleSet->SetContentRoot(FPaths::EngineContentDir()/TEXT("Editor/Slate"));
	StyleSet->SetCoreContentRoot(FPaths::EngineContentDir()/TEXT("Slate"));

	const FVector2D Icon20x20(20.0f,20.0f);
	const FVector2D Icon40x40(40.0f,40.0f);

	// Icons for the mode panel tabs
	StyleSet->Set("StaticMeshEditor.rdLODtools",new IMAGE_PLUGIN_BRUSH(TEXT("Icons/rdLODtools_40px"),Icon40x40));
	StyleSet->Set("StaticMeshEditor.rdLODtools.Small",new IMAGE_PLUGIN_BRUSH(TEXT("Icons/rdLODtools_40px"),Icon20x20));
	StyleSet->Set("StaticMeshEditor.rdLODtools.Logo",new IMAGE_PLUGIN_BRUSH(TEXT("Icons/rdLODtools_350px"),FVector2D(140.0,140.0)));

	// Icons for the dropdown menu
	StyleSet->Set("StaticMeshEditor.rdLODtools.DupAndEdit",new IMAGE_BRUSH(TEXT("Icons/Edit/icon_Edit_Duplicate_16x"), Icon20x20));
	StyleSet->Set("StaticMeshEditor.rdLODtools.RemoveLODs",new IMAGE_BRUSH(TEXT("Icons/Edit/icon_Edit_Cut_40x"), Icon20x20));
	StyleSet->Set("StaticMeshEditor.rdLODtools.CreateBillboard",new IMAGE_BRUSH(TEXT("Icons/AssetIcons/PaperSpriteActor_16x"), Icon20x20));
	StyleSet->Set("StaticMeshEditor.rdLODtools.CreatePlanar",new IMAGE_BRUSH(TEXT("Icons/icon_BlueprintEditor_Components_16x"), Icon20x20));
	StyleSet->Set("StaticMeshEditor.rdLODtools.About",new IMAGE_BRUSH(TEXT("Icons/AssetIcons/DocumentationActor_16x"), Icon20x20));

	FSlateStyleRegistry::RegisterSlateStyle(*StyleSet.Get());
}

//----------------------------------------------------------------------------------------------------------------
// Shutdown
//----------------------------------------------------------------------------------------------------------------
void FPluginStyle::Shutdown() {

	if(StyleSet.IsValid()) {

		FSlateStyleRegistry::UnRegisterSlateStyle(*StyleSet.Get());
		ensure(StyleSet.IsUnique());
		StyleSet.Reset();
	}
}

TSharedPtr<class ISlateStyle> FPluginStyle::Get() {
	return StyleSet; 
}	

FName FPluginStyle::GetStyleSetName() {
	static FName StyleName("rdLODtoolsStyle");
	return StyleName;
}

FString FPluginStyle::InContent(const FString& RelativePath,const ANSICHAR* Extension) {
	static FString ContentDir=IPluginManager::Get().FindPlugin(TEXT("rdLODtools"))->GetContentDir();
	return (ContentDir/RelativePath)+Extension;
}

TSharedPtr<FSlateStyleSet> FPluginStyle::StyleSet=nullptr;

//----------------------------------------------------------------------------------------------------------------
// ToString
//----------------------------------------------------------------------------------------------------------------
FString	UrdLODtoolsOptions::ToString() {

	FString str="4"; // version
	str+=FString::Printf(TEXT("|%d|%d|%d|%d|%d|%d|%d|%d|%f|%d|%d|%d|%f|%f|%f|%f|%f|%d"),
							meshType,
							sourceLOD,
							centrePivot,
							makeNormalMap,
							makeOtherMaps,
							maxLODs,
							numFrames,
							res,
							screenSize,
							wind,
							shadows,
							copyMasters,
							startAngle,
							stopAngle,
							renderTilt,
							meshTilt,
							meshZoom,
							inverseOpacity
						);

	return str;
}

//----------------------------------------------------------------------------------------------------------------
// FromString
//----------------------------------------------------------------------------------------------------------------
bool UrdLODtoolsOptions::FromString(const FString& str) {
	
	TArray<FString> vals;
	int32 num=str.ParseIntoArray(vals,TEXT("|"));
	if(num<16) {
		return false;
	}
	int32 version=FCString::Atoi(*vals[0]);
	if(version>4 || (version==1 && num!=16) || (version==2 && num!=18) || (version==3 && num!=17) || (version==4 && num!=19) ) {
		return false;
	}

	meshType=FCString::Atoi(*vals[1]);
	sourceLOD=FCString::Atoi(*vals[2]);
	centrePivot=vals[3].ToBool();
	makeNormalMap=vals[4].ToBool();
	makeOtherMaps=vals[5].ToBool();
	maxLODs=FCString::Atoi(*vals[6]);
	numFrames=FCString::Atoi(*vals[7]);
	res=FCString::Atoi(*vals[8]);
	screenSize=FCString::Atof(*vals[9]);
	wind=vals[10].ToBool();
	shadows=vals[11].ToBool();
	copyMasters=vals[12].ToBool();
	if(version>=3) {
		startAngle=FCString::Atof(*vals[13]);
		stopAngle=FCString::Atof(*vals[14]);
		if(version>=4) {

			renderTilt=FCString::Atof(*vals[15]);
			meshTilt=FCString::Atof(*vals[16]);
			meshZoom=FCString::Atof(*vals[17]);
			inverseOpacity=vals[18].ToBool();
		}

	} else {

		//bakeLighting=vals[13].ToBool(); these are not there any more
		//fakeShading=vals[14].ToBool();
		//gamma=FCString::Atof(*vals[15]);
		if(version>1) {
			startAngle=FCString::Atof(*vals[16]);
			stopAngle=FCString::Atof(*vals[17]);
		}
	}
	return true;
}

//----------------------------------------------------------------------------------------------------------------
// SaveToTag
//----------------------------------------------------------------------------------------------------------------
bool UrdLODtoolsOptions::SaveToTag(const FString& tag) {

	UrdTagAssetUserData* ourTag=(UrdTagAssetUserData*)mesh->GetAssetUserDataOfClass(UrdTagAssetUserData::StaticClass());
	if(ourTag) {
	
		ourTag->SetItem(tag,ToString());
	
	} else {
	
		UrdTagAssetUserData* userData=NewObject<UrdTagAssetUserData>(mesh);
		userData->SetName(TEXT("rdTags"));
		userData->SetItem(tag,ToString());
		mesh->AddAssetUserData(userData);
	}

	return true;
}

//----------------------------------------------------------------------------------------------------------------
// LoadFromTag
//----------------------------------------------------------------------------------------------------------------
bool UrdLODtoolsOptions::LoadFromTag(const FString& tag) {

	UrdTagAssetUserData* ourTag=(UrdTagAssetUserData*)mesh->GetAssetUserDataOfClass(UrdTagAssetUserData::StaticClass());
	if(ourTag) {
	
		const FString& vals=ourTag->GetItem(tag);
		if(vals.Len()>0) {
			FromString(vals);
		}
	
	} else {
		return false;
	}

	return true;
}

//----------------------------------------------------------------------------------------------------------------
// OnRemoveBillboardLODs
//----------------------------------------------------------------------------------------------------------------
void UrdLODtoolsOptions::OnRemoveBillboardLODs(bool resetCurrLod) {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("rdRemoving Billboard LODs..."));
#endif

	int32 numSrcs=GetMeshSourceModels().Num(),bbInd=0;

	// Find the billboard LOD if one exists
	for(;bbInd<numSrcs;bbInd++) {
		if(GetMeshSourceModel(bbInd).SourceImportFilename==TEXT("rdBillboard.inline")) {
			break;
		}
	}
	if(bbInd<numSrcs) {
	
		GetMeshSourceModels().RemoveAt(bbInd);
		bbInd=0;
		for(auto mat:mesh->StaticMaterials) {
		
			if(mat.ImportedMaterialSlotName==TEXT("rdBillboard")) {
				mesh->StaticMaterials.RemoveAt(bbInd);
				break;
			}
			bbInd++;
		}

		// Now rebuild the mesh with it's LODs
		mesh->CreateBodySetup();
		mesh->PostEditChange();

		// Refresh the Editor
		FGlobalComponentReregisterContext RecreateComponents;
		meshEditor->RefreshTool();

	// Set the Editor LOD to Auto
	if(resetCurrLod) {
		meshEditor->GetStaticMeshComponent()->ForcedLodModel=0;
	}

#ifdef _INCLUDE_DEBUGGING_STUFF
		UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
	}
}

//----------------------------------------------------------------------------------------------------------------
// OnRemovePlanarLODs
//----------------------------------------------------------------------------------------------------------------
void UrdLODtoolsOptions::OnRemovePlanarLODs(bool resetCurrLod) {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("rdRemoving Planar LODs..."));
#endif

	int32 numSrcs=GetMeshSourceModels().Num(),bbInd=0;

	// Find the planar LOD if one exists
	for(;bbInd<numSrcs;bbInd++) {
		if(GetMeshSourceModel(bbInd).SourceImportFilename==TEXT("rdPlanar.inline")) {
			break;
		}
	}
	if(bbInd<numSrcs) {
	
		GetMeshSourceModels().RemoveAt(bbInd);
		bbInd=0;
		for(auto mat:mesh->StaticMaterials) {
		
			if(mat.ImportedMaterialSlotName==TEXT("rdPlanar")) {
				mesh->StaticMaterials.RemoveAt(bbInd);
				break;
			}
			bbInd++;
		}

		// Now rebuild the mesh with it's LODs
		mesh->CreateBodySetup();
		mesh->PostEditChange();

		// Refresh the Editor
		FGlobalComponentReregisterContext RecreateComponents;
		meshEditor->RefreshTool();

	// Set the Editor LOD to Auto
	if(resetCurrLod) {
		meshEditor->GetStaticMeshComponent()->ForcedLodModel=0;
	}

#ifdef _INCLUDE_DEBUGGING_STUFF
		UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
	}
}

//----------------------------------------------------------------------------------------------------------------
// OnRemoveLOD
//----------------------------------------------------------------------------------------------------------------
void UrdLODtoolsOptions::OnRemoveLOD() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("rdRemoving LOD.."));
#endif

	if(removeLOD==0) {

		if(	GetMeshSourceModel(1).SourceImportFilename!=TEXT("rdBillboard.inline") &&
			GetMeshSourceModel(1).SourceImportFilename!=TEXT("rdPlanar.inline") &&
#if ENGINE_MINOR_VERSION>21
			// New to version 4.22, prior to this there was OriginalMeshDescription in the SourceModels
			!mesh->IsMeshDescriptionValid(1)) {

				mesh->CreateMeshDescription(1,*mesh->GetMeshDescription(0));
				mesh->CommitMeshDescription(1);
#else
			!GetMeshSourceModel(removeExceptLOD).OriginalMeshDescription) {

				GetMeshSourceModel(1).OriginalMeshDescription=MakeUnique<FMeshDescription>().Get();
				UStaticMesh::RegisterMeshAttributes(*(GetMeshSourceModel(1).OriginalMeshDescription));
				*(GetMeshSourceModel(1).OriginalMeshDescription)=*(GetMeshSourceModel(0).OriginalMeshDescription);
#endif	
		}
	}

	// Remove the LOD
	GetMeshSourceModels().RemoveAt(removeLOD);

	// Find Materials not used anymore and remove them
	TArray<int32> matIndexes;
	for(auto m:GetMeshSectionInfoMap().Map) {
		int32 lod=m.Key>>16;
		if(lod!=removeLOD) {
			matIndexes.Add(m.Value.MaterialIndex);
		}
	}
	int c=0,numDelMats=0,firstDelMat=-1;
	for(int i=0;i<mesh->StaticMaterials.Num();c++) {
	
		if(matIndexes.Find(c)<0) {
			mesh->StaticMaterials.RemoveAt(i);
			if(firstDelMat<0) firstDelMat=i;
			numDelMats++;
		} else {
			i++;
		}
	}

	// Update the SectionInfoMap
	TMap<int32,FMeshSectionInfo> tmap;
	for(auto m:GetMeshSectionInfoMap().Map) {
		int32 lod=m.Key>>16;
		if(lod!=removeLOD) {
			if(firstDelMat>=0 && m.Value.MaterialIndex>firstDelMat) {
				m.Value.MaterialIndex-=numDelMats;
			}
			tmap.Add(lod>removeLOD?m.Key-65536:m.Key,m.Value);
		}
	}

	GetMeshSectionInfoMap().Map.Empty();
	for(auto m:tmap) {
		GetMeshSectionInfoMap().Map.Add(m.Key,m.Value);
	}

	// Now rebuild the mesh with it's LODs
	mesh->CreateBodySetup();
	mesh->PostEditChange();

	// Refresh the Editor
	FGlobalComponentReregisterContext RecreateComponents;
	meshEditor->RefreshTool();

	// Set the Editor LOD to Auto
	meshEditor->GetStaticMeshComponent()->ForcedLodModel=0;

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
}

//----------------------------------------------------------------------------------------------------------------
// OnRemoveAllLODsExcept
//----------------------------------------------------------------------------------------------------------------
void UrdLODtoolsOptions::OnRemoveAllLODsExcept() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("rdRemoving LODs except one..."));
#endif

	if(removeExceptLOD>0 && 
		GetMeshSourceModel(removeExceptLOD).SourceImportFilename!=TEXT("rdBillboard.inline") &&
		GetMeshSourceModel(removeExceptLOD).SourceImportFilename!=TEXT("rdPlanar.inline") &&
#if ENGINE_MINOR_VERSION>21
		// New to version 4.22, prior to this there was OriginalMeshDescription in the SourceModels
		!mesh->IsMeshDescriptionValid(removeExceptLOD) && mesh->GetMeshDescription(0)) {

			mesh->CreateMeshDescription(removeExceptLOD,*mesh->GetMeshDescription(0));
			mesh->CommitMeshDescription(removeExceptLOD);
#else
		!GetMeshSourceModel(removeExceptLOD).OriginalMeshDescription && GetMeshSourceModel(0).OriginalMeshDescription) {

			GetMeshSourceModel(removeExceptLOD).OriginalMeshDescription=MakeUnique<FMeshDescription>().Get();
			UStaticMesh::RegisterMeshAttributes(*(GetMeshSourceModel(removeExceptLOD).OriginalMeshDescription));
			*(GetMeshSourceModel(removeExceptLOD).OriginalMeshDescription)=*(GetMeshSourceModel(0).OriginalMeshDescription);
#endif			
	}

	int32 numSrcs=GetMeshSourceModels().Num()-1;

	if(removeExceptLOD==0) {

		GetMeshSourceModels().RemoveAt(1,numSrcs);

	} else if(removeExceptLOD==numSrcs) {

		GetMeshSourceModels().RemoveAt(0,numSrcs);

	} else {

		GetMeshSourceModels().RemoveAt(0,removeExceptLOD);
		GetMeshSourceModels().RemoveAt(1,GetMeshSourceModels().Num()-1);
	}

	TArray<int32> matIndexes;
	for(auto m:GetMeshSectionInfoMap().Map) {
		int32 lod=m.Key>>16;
		if(lod==removeExceptLOD) {
			matIndexes.Add(m.Value.MaterialIndex);
		}
	}
	int c=0;
	for(int i=0;i<mesh->StaticMaterials.Num();c++) {
	
		if(matIndexes.Find(c)<0) {
			mesh->StaticMaterials.RemoveAt(i);
		} else {
			i++;
		}
	}

	// Update the SectionInfoMap
	TMap<int32,FMeshSectionInfo> tmap;
	c=0;
	for(auto m:GetMeshSectionInfoMap().Map) {
		int32 lod=m.Key>>16;
		if(lod==removeExceptLOD) {
			m.Value.MaterialIndex=c++;
			tmap.Add(m.Key&0xffff,m.Value);
		}
	}

	GetMeshSectionInfoMap().Map.Empty();
	GetMeshOriginalSectionInfoMap().Map.Empty();
	for(auto m:tmap) {
		GetMeshSectionInfoMap().Map.Add(m.Key,m.Value);
		GetMeshOriginalSectionInfoMap().Map.Add(m.Key,m.Value);
	}

	// Now rebuild the mesh with it's LODs
	mesh->CreateBodySetup();
	mesh->PostEditChange();

	// Refresh the Editor
	FGlobalComponentReregisterContext RecreateComponents;
	meshEditor->RefreshTool();

	// Set the Editor LOD to Auto
	meshEditor->GetStaticMeshComponent()->ForcedLodModel=0;

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
}

//----------------------------------------------------------------------------------------------------------------
