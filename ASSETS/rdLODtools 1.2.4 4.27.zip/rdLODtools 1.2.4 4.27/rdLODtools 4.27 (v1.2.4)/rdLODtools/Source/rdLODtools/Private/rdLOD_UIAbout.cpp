//
// rdLOD_UIAbout
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 26th July 2019
// Last Modified: 15th March 2021
//
// Constructs/Handles the rdLODtools About Window
//
#include "rdLODtoolsOptions.h"
#include "Editor/MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "PropertyEditorModule.h"
#include "Runtime/Slate/Public/Widgets/Input/SComboBox.h"
#include "Runtime/Slate/Public/Widgets/Input/SButton.h"
#include "Runtime/Slate/Public/Widgets/Input/SCheckBox.h"
#include "Runtime/SlateCore/Public/Brushes/SlateImageBrush.h"
#include "Interfaces/IPluginManager.h"
#include "Runtime/Launch/Resources/Version.h"

class FrdLODAboutOptionsCustomization : public IDetailCustomization {
public:
	static TSharedRef<IDetailCustomization> MakeInstance();
								FrdLODAboutOptionsCustomization();
	TSharedRef<SWidget>			MakeComboWidget(TSharedPtr<FString> InItem);
	virtual void				CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
protected:
	TArray<TSharedPtr<FString>> mtypeComboList;
	TSharedPtr<STextBlock>		mtypeComboBoxLabel;

	TArray<TSharedPtr<FString>> sourceLODComboList;
	TSharedPtr<STextBlock>		sourceLODComboBoxLabel;

	TArray<TSharedPtr<FString>> resComboList;
	TSharedPtr<STextBlock>		bbResComboBoxLabel;
	TSharedPtr<STextBlock>		plResComboBoxLabel;

	TArray<TSharedPtr<FString>> numFramesComboList;
	TSharedPtr<STextBlock>		numFramesComboBoxLabel;

	TArray<TSharedPtr<FString>> numPlanesComboList;
	TSharedPtr<STextBlock>		numPlanesComboBoxLabel;
};

class rdLODAboutOptions : public SCompoundWidget {
public:
	SLATE_BEGIN_ARGS(rdLODAboutOptions)
		: _WidgetWindow()
	{}
		SLATE_ARGUMENT(TSharedPtr<SWindow>,WidgetWindow)
		SLATE_ARGUMENT(TArray<TWeakObjectPtr<UObject>>,SettingsObjects)
		SLATE_END_ARGS()

public:
					rdLODAboutOptions();
	void			Construct(const FArguments& InArgs);

	virtual bool	SupportsKeyboardFocus() const override { return true; }
	virtual FReply	OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override { return (InKeyEvent.GetKey()==EKeys::Escape)?OnConfirm():FReply::Unhandled(); }
	FReply			OnConfirm(){
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}
private:
	TWeakPtr<SWindow>				WidgetWindow;
	TSharedPtr<class IDetailsView>	DetailsView;
	TSharedPtr<SButton>				ConfirmButton;
};

TSharedRef<IDetailCustomization> FrdLODAboutOptionsCustomization::MakeInstance() {
	return MakeShareable(new FrdLODAboutOptionsCustomization());
}

//.............................................................................
// Constructor
//.............................................................................
FrdLODAboutOptionsCustomization::FrdLODAboutOptionsCustomization() {
}

TSharedRef<SWidget> FrdLODAboutOptionsCustomization::MakeComboWidget(TSharedPtr<FString> InItem) {
	return SNew(STextBlock).Text(FText::FromString(*InItem)).Font(FEditorStyle::GetFontStyle(TEXT("PropertyWindow.NormalFont")));
}

//.............................................................................
// CustomizeDetails
//.............................................................................
void FrdLODAboutOptionsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) {

	TArray<TWeakObjectPtr<UObject>> WeakObjects;
	DetailBuilder.GetObjectsBeingCustomized(WeakObjects);

	IDetailCategoryBuilder& CategoryBuilder0=DetailBuilder.EditCategory(TEXT(" "));

	const FSlateBrush* sbrush=FPluginStyle::Get().Get()->GetBrush("StaticMeshEditor.rdLODtools.Logo");
	FString ver=FString::Printf(TEXT("rdLODtools\n\nversion: 1.24 - 15th March 2021\nRecourse Design ltd.\n\nUE4 version:%d.%d.%d"),ENGINE_MAJOR_VERSION,ENGINE_MINOR_VERSION,ENGINE_PATCH_VERSION);

	FDetailWidgetRow& lrow0=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT(" "))).IsEnabled(false);
	lrow0.NameContent()
		[
			SNew(SImage)
			.Image(sbrush)
		];

	TSharedPtr<SHorizontalBox> ContentBox0;
	lrow0.ValueContent()
		[
			SAssignNew(ContentBox0,SHorizontalBox)
		];

	ContentBox0->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(STextBlock)
			.Text(FText::FromString(*ver))
			.Font(DetailBuilder.GetDetailFontBold())
		];

	// .......................................................................
}

rdLODAboutOptions::rdLODAboutOptions() {}

void rdLODAboutOptions::Construct(const FArguments& InArgs) {

	WidgetWindow = InArgs._WidgetWindow;

	// Retrieve property editor module and create a SDetailsView
	FPropertyEditorModule& PropertyEditorModule=FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bAllowSearch=false;
	DetailsViewArgs.NameAreaSettings=FDetailsViewArgs::HideNameArea;
	DetailsViewArgs.bAllowMultipleTopLevelObjects=false;

	DetailsView=PropertyEditorModule.CreateDetailView(DetailsViewArgs);

	// Register instance property customization
	DetailsView->RegisterInstancedCustomPropertyLayout(UrdLODtoolsOptions::StaticClass(), 
														FOnGetDetailCustomizationInstance::CreateLambda([=]() { return FrdLODAboutOptionsCustomization::MakeInstance(); }));

	// Set up root object customization to get desired layout
	DetailsView->SetRootObjectCustomizationInstance(MakeShareable(new FSimpleRootObjectCustomization));

	// Set provided objects on SDetailsView
	DetailsView->SetObjects(InArgs._SettingsObjects,true);

	this->ChildSlot
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
				.Padding(2)
//				.MaxHeight(700.0f)
				[
					DetailsView->AsShared()
				]

			+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Center)
				.Padding(2)
				[
					SNew(SUniformGridPanel)
						.SlotPadding(2)
						+ SUniformGridPanel::Slot(0,0)
						[
							SAssignNew(ConfirmButton,SButton)
							.HAlign(HAlign_Center)
							.Text(LOCTEXT("rdLODtools_Continue"," Continue "))
							.ToolTipText(LOCTEXT("rdLODtools_About_ToolTip0","Close and continue"))
							.OnClicked(this,&rdLODAboutOptions::OnConfirm)
						]
				]
		];
}

//.............................................................................
// ShowAboutSettings
//.............................................................................
bool rdLODclass::ShowAboutSettings() {

	// Create the settings window...
	TSharedRef<SWindow> winLOD=SNew(SWindow)
										.Title(FText::FromString(TEXT("About rdLODtools")))
										.SizingRule(ESizingRule::UserSized)
										.AutoCenter(EAutoCenter::PreferredWorkArea)
										.ClientSize(FVector2D(460,230));

	rdLODoptions=DuplicateObject(GetMutableDefault<UrdLODtoolsOptions>(),GetTransientPackage());
	TArray<TWeakObjectPtr<UObject>> OptionObjects{ rdLODoptions };
	TSharedPtr<rdLODAboutOptions> Options;

	winLOD->SetContent(SAssignNew(Options,rdLODAboutOptions)
						.WidgetWindow(winLOD)
						.SettingsObjects(OptionObjects)
					  );

	TSharedPtr<SWindow> ParentWindow;
	if(!FModuleManager::Get().IsModuleLoaded("MainFrame")) {
		return false;
	}

	// Show Settings Window
	IMainFrameModule& MainFrame=FModuleManager::LoadModuleChecked<IMainFrameModule>("MainFrame");
	FSlateApplication::Get().AddModalWindow(winLOD,MainFrame.GetParentWindow(),false);

	return true;
}