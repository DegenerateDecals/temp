//
// rdLOD_CreateBillboard.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 17th March 2021
//
// version 1.24
//		CHANGED: 17th March 2021 - Changed to new Capture system that works with almost everything
//		CHANGED: 27th Feb 2021 - Changed to World Space Normals for Billboard LODs
//		CHANGED: 14th March 2021 - Changed Base Material name to rdLODMaster2 to avoid conflict with older versions
//		ADDED:   9th March 2021 - Added routine to wait for material compiler to finish
//
// version 1.23
//		FIXED: 28th Oct 2020 - Planar LODs were 90* out with their frames
//
// version 1.2
//		ADDED: Start and stop angles for Billboards
//		CHANGED: Fake Shading options changed
//		CHANGED: "Edit Mats" no longer opens billboard or planar material instances if they exist
//		FIXED:   Trying to open too many materials crashes
//		CHANGED: Materials now copied and referenced from project folder
//		CHANGED: Opacity now rendered per-pixel
//		CHANGED: Normal map creation now maps a curved shape over the normal
//		CHANGED: Instead of deleting any current Billboard and creating a new one, the existing one is now overwritten
//
#include "../Public/rdLODtools.h"

#include "Runtime/Engine/Classes/Materials/MaterialInstanceConstant.h"
#include "Editor/StaticMeshEditor/Public/IStaticMeshEditor.h"
#include "Editor/MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "Runtime/Core/Public/Misc/ScopedSlowTask.h"
#include "Editor/UnrealEd/Public/ScopedTransaction.h"
#include "Runtime/Core/Public/HAL/FileManager.h"
#include "Runtime/Core/Public/HAL/PlatformFilemanager.h"
#include "Interfaces/IPluginManager.h"
#include "Runtime/Core/Public/Misc/MessageDialog.h"
#include "ShaderCompiler.h"
#include "Runtime/Core/Public/Misc/FileHelper.h"

#include "rdLODtoolsOptions.h"
#include "StaticMeshToRenderTarget.h"

#define LOCTEXT_NAMESPACE "FrdLODtoolsModule"


//----------------------------------------------------------------------------------------------------------------
// CreateBillboard
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CreateBillboard() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Opening rdCreateBillboard Window..."));
#endif

	mesh=meshEditor->GetStaticMesh(); // Retrieves the current static mesh displayed in the Static Mesh Editor.

	// Make sure there is at least one source LOD that's not a billboard or planar LOD
	int32 numRealLODs=0;
	for(int32 i=0;i<mesh->GetNumLODs();i++) {
		if(	GetMeshSourceModel(i).SourceImportFilename!=TEXT("rdBillboard.inline") &&
			GetMeshSourceModel(i).SourceImportFilename!=TEXT("rdPlanar.inline")) {

				numRealLODs++;
		}
	}
	if(!numRealLODs) {
		FText msg=FText::FromString(TEXT("There must be a non-rdLOD type source LOD."));
		FMessageDialog::Open(EAppMsgType::Ok,msg,NULL);
		return;
	}

	MeshName=mesh->GetName();
	if(MeshName.StartsWith(TEXT("SM_"),ESearchCase::IgnoreCase)) {
		MeshName=MeshName.Right(MeshName.Len()-3);
	}

	// make sure Textures go into the meshes Textures folder and Materials in the Materials folder
	setUpFolders();

	bool ret=ShowBillboardSettings();
	if(!ret) {
#ifdef _INCLUDE_DEBUGGING_STUFF
		UE_LOG(LogTemp, Display, TEXT("rdLODtools cancelled."));
#endif
		return;
	}

	// Add Undo point
	const FScopedTransaction Transaction(LOCTEXT("rdLODtool","CreateLODs"));
	mesh->Modify();

	// Create the Progress Dialog
	{
	FScopedSlowTask SlowTask(5.0f,LOCTEXT("CreatingLODs","Creating LODs..."));
	SlowTask.MakeDialog();

	SlowTask.EnterProgressFrame(1.0f);

	// If specified, duplicate the mesh, open it in the editor and add the LOD's to this copy
	if(rdLODoptions->bDuplicateMesh) {

#ifdef _INCLUDE_DEBUGGING_STUFF
		UE_LOG(LogTemp, Display, TEXT("rdLODtools is duplicating the mesh..."));
#endif

		TArray<UObject*> srcLst;
		srcLst.Add(mesh);
		TArray<UObject*> dstLst;
		ObjectTools::DuplicateObjects(srcLst,TEXT(""),TEXT(""),false,&dstLst);

		if(dstLst.Num()<1) {
			UE_LOG(LogTemp, Error, TEXT("rdLODtools duplicate mesh failed"));
			return;
		}

		mesh=(UStaticMesh*)dstLst[0];
		TArray<UObject*> assets;
		assets.Add(mesh);
		OpenAssetEditor(assets);
	}

	if(rdLODoptions->centrePivot) {

		CentreMeshPivot(); // Move the mesh vertices so they are centred
	}

	// Store original LOD index and Material index if a Billboard LOD already exists
	origMeshInd=origMatInd=-1;
	for(int32 i=0;i<GetMeshSourceModels().Num();i++) {
		if(GetMeshSourceModel(i).SourceImportFilename==TEXT("rdBillboard.inline")) {
			origMeshInd=i;
			break;
		}
	}
	for(int32 i=0;i<mesh->StaticMaterials.Num();i++) {
		if(mesh->StaticMaterials[i].ImportedMaterialSlotName==TEXT("rdBillboard")) {
			origMatInd=i;
			break;
		}
	}

	mesh->bAutoComputeLODScreenSize=false; // otherwise the screen size is calculated by the Epic LOD generator.

	//ADDED:20th July 2019 - go through and calculate screen sizes for any existing LODs
	if(GetMeshSourceModels().Num()>1) {
		float numLODs=GetMeshSourceModels().Num()-1;
		float minSSz=rdLODoptions->screenSize;
		float sszInc=(1.0-minSSz)/(numLODs+1.0);
		float ssz=1.0-sszInc;
		for(int i=1;i<GetMeshSourceModels().Num();i++) {
			GetMeshSourceModel(i).ScreenSize=ssz;
			ssz-=sszInc;
		}
	}

	//FIXED: 9th March 2021 - Wait for the Vanilla MIs to compile
	GShaderCompilingManager->FinishAllCompilation();

	SlowTask.EnterProgressFrame(1.0f);

	CreateBillboardLOD(); // Generate the Billboard LOD

	SlowTask.EnterProgressFrame(1.0f);

	// Now rebuild the mesh with it's LODs
	mesh->CreateBodySetup();
	mesh->Build();
	mesh->PostEditChange();

	SlowTask.EnterProgressFrame(1.0f);

	SlowTask.EnterProgressFrame(1.0f);
	}

	// Refresh the Editor
	FGlobalComponentReregisterContext RecreateComponents;
	meshEditor->RefreshTool();

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
}

//----------------------------------------------------------------------------------------------------------------
// RenderAngles
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::RenderAngles(UTexture2D* tex,int32 numFrames,bool linearCol) {

	float angle=(rdLODoptions->lodType==RDLOD_TYPE_PLANAR)?135:(rdLODoptions->startAngle+135);//CHANGED: 2nd March 2021 - now the view is at 45�, updated this
	float angleInc=(rdLODoptions->stopAngle-rdLODoptions->startAngle)/(float)numFrames;
	int32 tx=0,ty=0;
	int32 sz=(rdLODoptions->res/sqrt(numFrames))-2;
	for(int32 i=0;i<numFrames;i++) {
		
		meshRenderer->RenderMesh(tex,mesh,FRotator(0.0,angle,0.0),tx+1,ty+1,rdLODoptions,linearCol);
		tx+=sz+2;
		if(tx>=rdLODoptions->res-32) {
			tx=0;
			ty+=sz+2;
		}
		angle+=angleInc;
	}
}

//----------------------------------------------------------------------------------------------------------------
// CreateBillboardLOD
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CreateBillboardLOD() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Creating Billboard LOD..."));
#endif

	int32 sz=(rdLODoptions->res/sqrt(rdLODoptions->numFrames))-2;
	meshRenderer=new MeshRenderHelper();

	FRawMesh rawMesh=FRawMesh();
	UTexture2D* texO=nullptr,*texD=nullptr,*texN=nullptr,*texM=nullptr,*texR=nullptr,*texS=nullptr,*texAO=nullptr,*texPBR=nullptr;

	// Create Package for the Normal Render
	UPackage* normalPackage=MakeTexture(&texN,'N',TEXT("WorldNormal"),true,rdLODoptions->makeNormalMap?false:true,false);

	// Create Texture for the Opacity Render
	MakeTexture(&texO,'O',TEXT("Opacity"),true,true); // temp texture, not saved

	// Create Texture for the AmbientOcclusion
	MakeTexture(&texAO,'A',TEXT("AmbientOcclusion"),true,true); // temp texture, not saved

	// Create Package for the Diffuse Texture
	UPackage* diffusePackage=MakeTexture(&texD,'D',TEXT("BaseColor"),true,false,false);

	FColor* normalData=(FColor*)texN->Source.LockMip(0);
	FColor* opacityData=(FColor*)texO->Source.LockMip(0);
	FColor* aoData=(FColor*)texAO->Source.LockMip(0);
	FColor* diffuseData=(FColor*)texD->Source.LockMip(0);

	int32 nTexW=texN->Source.GetSizeX();
	int32 oTexW=texO->Source.GetSizeX();
	int32 aoTexW=texAO->Source.GetSizeX();
	int32 dTexW=texD->Source.GetSizeX();

	int32 oSrcY=0,nSrcY=0,aoSrcY=0,dSrcY=0;

	// Mask out the undrawn areas in the OpacityMap (use the black bits of the WorldNormal Map)
	for(int y=0;y<rdLODoptions->res;y++) {
		for(int x=0;x<rdLODoptions->res;x++) {

			FColor& nCol=normalData[nSrcY+x];
			FColor& oCol=opacityData[oSrcY+x];
			FColor& aoCol=aoData[aoSrcY+x];
			FColor& dCol=diffuseData[dSrcY+x];

			if(dCol.R+dCol.G+dCol.B==0 && nCol.R+nCol.G+nCol.B<6) { // it's pretty safe to say that if the normalmap pixel is black, it's part of the mask...
				dCol.A=0;
			} else {
				if(oCol.R==0) dCol.A=255; // solid materials get drawn as black in the Opacity visualization so if it's black but the normal is valid, set it as solid
				else dCol.A=rdLODoptions->inverseOpacity?oCol.R:(255-oCol.R);
			}

			nCol.A=aoCol.R; // store the ambient occlusion in the normals alpha channel
		}

		oSrcY+=oTexW;
		nSrcY+=nTexW;
		aoSrcY+=aoTexW;
		dSrcY+=dTexW;
	}

	texO->Source.UnlockMip(0);
	texN->Source.UnlockMip(0);
	texAO->Source.UnlockMip(0);
	texD->Source.UnlockMip(0);

	if(rdLODoptions->makeNormalMap) {
		FinalizePackage(texN,normalPackage,'N');
	}
	FinalizePackage(texD,diffusePackage,'D');

	if(rdLODoptions->makeOtherMaps) {

		MakeTexture(&texR,'R',TEXT("Roughness"),true,true);
		MakeTexture(&texM,'M',TEXT("Metallic"),true,true);
		MakeTexture(&texS,'S',TEXT("Specular"),true,true);

		FString fileName=FString::Printf(TEXT("T_%s_Billboard_PBR"),*MeshName);
#if ENGINE_MINOR_VERSION>25
		UPackage* package=CreatePackage(*(TEXT("/Game/")/texturePath/fileName));
#else
		UPackage* package=CreatePackage(nullptr,*(TEXT("/Game/")/texturePath/fileName));
#endif
		texPBR=createTexture(package,fileName,rdLODoptions->res,0,true);

		FColor* pbrData=(FColor*)texPBR->Source.LockMip(0);
		FColor* roughData=(FColor*)texR->Source.LockMip(0);
		FColor* metalData=(FColor*)texM->Source.LockMip(0);
		FColor* specularData=(FColor*)texS->Source.LockMip(0);

		int32 pbrTexW=texPBR->Source.GetSizeX();
		int32 rTexW=texR->Source.GetSizeX();
		int32 mTexW=texM->Source.GetSizeX();
		int32 sTexW=texS->Source.GetSizeX();

		int32 rSrcY=0,mSrcY=0,sSrcY=0,pbrSrcY=0;

		// Copy these to the channels in the PBR texture
		for(int y=0;y<rdLODoptions->res;y++) {
			for(int x=0;x<rdLODoptions->res;x++) {
				FColor& rCol=roughData[rSrcY+x];
				FColor& mCol=metalData[mSrcY+x];
				FColor& sCol=specularData[sSrcY+x];
				FColor pbrCol;

				pbrCol.R=rCol.R;
				pbrCol.G=mCol.R;
				pbrCol.B=sCol.R;
				pbrCol.A=255; //TODO: add emmisive amount here

				pbrData[pbrSrcY+x]=pbrCol;
			}
			rSrcY+=rTexW;
			mSrcY+=mTexW;
			sSrcY+=sTexW;
			pbrSrcY+=pbrTexW;
		}

		texR->Source.UnlockMip(0);
		texM->Source.UnlockMip(0);
		texS->Source.UnlockMip(0);
		texPBR->Source.UnlockMip(0);

		finaliseTexture(texPBR,package,fileName);
	}

	// Create MaterialInstance for the rdBillboard Master Material
	FString mFileName=FString::Printf(TEXT("MI_%s_Billboard"),*MeshName),masterName;
	FString path=FPaths::ProjectContentDir();

	// Copy the master material and support files to our rdLODtools folder if they don't already exist
	CopyPluginFiles();

	if(rdLODoptions->copyMasters) {

		IPlatformFile& PlatformFile=FPlatformFileManager::Get().GetPlatformFile();
		if(!PlatformFile.FileExists(*(path/materialPath/TEXT("M_rdLODMaster2.uasset")))) {

			// copy the master material to the material folder
			PlatformFile.CopyFile(	*(path/materialPath/TEXT("M_rdLODMaster2.uasset")),
									*(path/TEXT("rdLODtools/Materials/M_rdLODMaster2.uasset")));
		}

		masterName=*(TEXT("/Game")/materialPath/TEXT("M_rdLODMaster2.M_rdLODMaster2"));

	} else {

		masterName=TEXT("/Game/rdLODtools/Materials/M_rdLODMaster2.M_rdLODMaster2");
	}

	UPackage* Package;
	UMaterialInstanceConstant* mi=CreateMaterialInstance(mFileName,*masterName,texD,texN,texPBR,rdLODoptions->numFrames,rdLODoptions->meshType,rdLODoptions->wind?0.3:0.0,&Package);
	mi->BasePropertyOverrides.bOverride_TwoSided=true;
	mi->BasePropertyOverrides.TwoSided=true;
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("WSNormals"),1.0); // Billboards use WorldSpace Normals as of version 1.24
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("StartAngle"),rdLODoptions->startAngle/360.0);
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("StopAngle"),rdLODoptions->stopAngle/360.0);
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("AngleFrac"),360.0/(rdLODoptions->stopAngle-rdLODoptions->startAngle));
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("HueShift_Min"),0.0);
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("HueShift_Max"),0.0);
	if(rdLODoptions->meshType==RDLOD_MESHTYPE_GENERAL) {
		mi->BasePropertyOverrides.bOverride_ShadingModel=true;
		mi->BasePropertyOverrides.ShadingModel=EMaterialShadingModel::MSM_DefaultLit;
	} else {
		mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("SubsurfaceColAmount"),0.075);
		mi->SetVectorParameterValueEditorOnly(FMaterialParameterInfo("SubsurfaceColor"),FLinearColor(0.7,0.76,0.25));
	}

	FStaticParameterSet OutStaticParameters;
	mi->GetStaticParameterValues(OutStaticParameters);
	if(OutStaticParameters.StaticSwitchParameters.Num()>0 && OutStaticParameters.StaticSwitchParameters[0].ParameterInfo.Name==TEXT("Billboard")) {
		OutStaticParameters.StaticSwitchParameters[0].Value=1; // Billboard mode
		OutStaticParameters.StaticSwitchParameters[0].bOverride=true;
	}
	mi->UpdateStaticPermutation(OutStaticParameters);

	ThumbnailTools::GenerateThumbnailForObjectToSaveToDisk(mi);
	FString FilePath=FString::Printf(TEXT("%s%s%s%s"),*absolutePath,*materialPath,*mFileName,*FPackageName::GetAssetPackageExtension());
	bool bSuccess=UPackage::SavePackage(Package,mi,EObjectFlags::RF_Public|EObjectFlags::RF_Standalone,*FilePath);

	CreateBillboardMesh(rawMesh,mi);

	// Save mesh in the StaticMesh
	int32 ind=GetMeshSourceModels().Num();
	if(origMeshInd>=0) {
		ind=origMeshInd;
	} else {
		new(GetMeshSourceModels()) FStaticMeshSourceModel();
	}

	GetMeshSourceModel(ind).BuildSettings.DstLightmapIndex=2;

	GetMeshSourceModel(ind).BuildSettings.bRecomputeNormals=true;
	GetMeshSourceModel(ind).BuildSettings.bRecomputeTangents=true;
	GetMeshSourceModel(ind).BuildSettings.bUseMikkTSpace=false;
	GetMeshSourceModel(ind).BuildSettings.bGenerateLightmapUVs=true;
	GetMeshSourceModel(ind).BuildSettings.bBuildAdjacencyBuffer=false;
	GetMeshSourceModel(ind).BuildSettings.bBuildReversedIndexBuffer=false;
	GetMeshSourceModel(ind).BuildSettings.bUseFullPrecisionUVs=false;
	GetMeshSourceModel(ind).BuildSettings.bUseHighPrecisionTangentBasis=false;

	GetMeshSourceModel(ind).StaticMeshOwner=mesh;
	GetMeshSourceModel(ind).ScreenSize=FPerPlatformFloat(rdLODoptions->screenSize);
	GetMeshSourceModel(ind).SourceImportFilename=TEXT("rdBillboard.inline");
	GetMeshSourceModel(ind).SaveRawMesh(rawMesh);
}

//----------------------------------------------------------------------------------------------------------------
