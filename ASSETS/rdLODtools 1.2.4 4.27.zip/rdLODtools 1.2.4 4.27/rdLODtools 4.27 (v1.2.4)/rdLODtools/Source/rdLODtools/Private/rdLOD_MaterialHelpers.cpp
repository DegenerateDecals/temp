//
// rdLOD_MaterialHelpers.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 28th Feb 2021
//
// Version 1.24
//	CHANGED: 28th Feb 2021 - Billboards now use WorldSpace Normals
//
// Version 1.2
//	FIXED: 9th Aug 2019 - no need to open billboard or planar materials
//	FIXED: plugin would crash when trying to create materials in the root folder
//
#include "../Public/rdLODtools.h"
#include "Runtime/Engine/Classes/Materials/MaterialInstanceConstant.h"
#include "Editor/UnrealEd/Classes/Factories/MaterialInstanceConstantFactoryNew.h"
#include "ObjectTools.h"
#include "AssetRegistryModule.h"
#include "rdLODtoolsOptions.h"

//----------------------------------------------------------------------------------------------------------------
// CreateMaterialInstance
// Helper to create a MaterialInstance. Used for the unlit render mats and the billboard/planer LOD mats
//----------------------------------------------------------------------------------------------------------------
UMaterialInstanceConstant* rdLODclass::CreateMaterialInstance(const FString& MaterialBaseName,const FString& masterMat,UTexture* texD,UTexture* texN,UTexture* texPBR,int32 numFrames,int32 miType,float windStrength,UPackage** pckgPtr) {

	// Create MaterialInstance for the specific Master Material
#if ENGINE_MINOR_VERSION>25
	UPackage* Package=CreatePackage(*(TEXT("/Game/")/materialPath/MaterialBaseName));
#else
	UPackage* Package=CreatePackage(nullptr,*(TEXT("/Game/")/materialPath/MaterialBaseName));
#endif
	if(pckgPtr) *pckgPtr=Package;
	UMaterial *parentMaterial=LoadObject<UMaterial>(nullptr,*masterMat); // Master Materials Reside in the Plugin Content folder (unless it is a plain colour material)

	UMaterialInstanceConstantFactoryNew* miFactory=NewObject<UMaterialInstanceConstantFactoryNew>();
	miFactory->InitialParent=parentMaterial;

	UMaterialInstanceConstant* mi=(UMaterialInstanceConstant*)miFactory->FactoryCreateNew(UMaterialInstanceConstant::StaticClass(),Package,*MaterialBaseName,RF_Standalone|RF_Public,NULL,GWarn);
	
	if(texD) mi->SetTextureParameterValueEditorOnly(FMaterialParameterInfo("Diffuse"),texD);
	if(texN) mi->SetTextureParameterValueEditorOnly(FMaterialParameterInfo("Normal"),texN);
	if(texPBR) mi->SetTextureParameterValueEditorOnly(FMaterialParameterInfo("PBR"),texPBR);

	if(miType>0) {
		mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("NumFrames"),numFrames); // this is both the flipbook frame num for billboard LODs and num planes for Planar LODs
	}
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("WindIntensity"),windStrength);
	mi->SetScalarParameterValueEditorOnly(FMaterialParameterInfo("WindSpeed"),0.3);

	// Save the MaterialInstance
	Package->FullyLoad();
	Package->SetDirtyFlag(true);
	mi->MarkPackageDirty();
	mi->PreEditChange(NULL);
	mi->PostEditChange();

	if(!pckgPtr) {
		ThumbnailTools::GenerateThumbnailForObjectToSaveToDisk(mi);
		FString FilePath=FString::Printf(TEXT("%s%s%s%s"),*absolutePath,*materialPath,*MaterialBaseName,*FPackageName::GetAssetPackageExtension());
		bool bSuccess=UPackage::SavePackage(Package,mi,EObjectFlags::RF_Public|EObjectFlags::RF_Standalone,*FilePath);
	}
	FAssetRegistryModule::AssetCreated(mi);

	return mi;
}

//----------------------------------------------------------------------------------------------------------------
// MakeTexture
//----------------------------------------------------------------------------------------------------------------
UPackage* rdLODclass::MakeTexture(UTexture2D** tex,const char suffix,const FName& shader,bool linearCol,bool tempTex,bool finalize) {

	int32 sz=(rdLODoptions->res/sqrt(rdLODoptions->numFrames))-2;
	meshRenderer->CreateView(sz,sz,rdLODoptions->renderTilt,shader,linearCol);

	FString fileName;
	UPackage* package=nullptr;

	if(tempTex) {

		*tex=UTexture2D::CreateTransient(rdLODoptions->res,rdLODoptions->res);
		(*tex)->Source.Init(rdLODoptions->res,rdLODoptions->res,1,1,TSF_BGRA8);
		(*tex)->MipGenSettings=TMGS_NoMipmaps;
		if(linearCol) {
			(*tex)->SRGB=false;
#if ENGINE_MINOR_VERSION>25
			(*tex)->Downscale=1.0;
#endif
			(*tex)->Filter=TF_Nearest;
			(*tex)->CompressionSettings=TC_HDR;
	} else {
			(*tex)->Filter=TF_Trilinear;//@@
			(*tex)->SRGB=true;
			(*tex)->CompressionSettings=TC_Default;
		}

	} else {

		if(rdLODoptions->lodType==RDLOD_TYPE_BILLBOARD)	{
			fileName=FString::Printf(TEXT("T_%s_Billboard_%c"),*MeshName,suffix);
		} else {
			fileName=FString::Printf(TEXT("T_%s_Planar_%c"),*MeshName,suffix);
		}

#if ENGINE_MINOR_VERSION>25
		package=CreatePackage(*(TEXT("/Game/")/texturePath/fileName));
#else
		package=CreatePackage(nullptr,*(TEXT("/Game/")/texturePath/fileName));
#endif

		*tex=createTexture(package,fileName,rdLODoptions->res,0,linearCol);
	}

	RenderAngles(*tex,rdLODoptions->numFrames,linearCol);

	if(!tempTex && finalize) {

		// Updating Texture & mark it as unsaved
		finaliseTexture(*tex,package,fileName);
	}

	meshRenderer->DestroyView();

	return package;
}


//.............................................................................
// finalizePackage
//.............................................................................
void rdLODclass::FinalizePackage(UTexture2D* tex,UPackage* package,char suffix) {

	FString fileName;
	if(rdLODoptions->lodType==RDLOD_TYPE_BILLBOARD)	{
		fileName=FString::Printf(TEXT("T_%s_Billboard_%c"),*MeshName,suffix);
	} else {
		fileName=FString::Printf(TEXT("T_%s_Planar_%c"),*MeshName,suffix);
	}
	finaliseTexture(tex,package,fileName);
}

//.............................................................................
// createTexture
//.............................................................................
UTexture2D* rdLODclass::createTexture(UPackage* Package,const FString& fileName,int32 res,uint32 clearCol,bool linearCol) {

	UTexture2D* tex=NewObject<UTexture2D>(Package,UTexture2D::StaticClass(),FName(*fileName),RF_Public|RF_Standalone);
	if(!tex) return NULL;

	tex->Source.Init(res,res,1,1,TSF_BGRA8);
	tex->MipGenSettings=TMGS_NoMipmaps;
	if(linearCol) {
		tex->SRGB=false;
#if ENGINE_MINOR_VERSION>25
		tex->Downscale=1.0;
#endif
		tex->Filter=TF_Nearest;
		tex->CompressionSettings=TC_HDR;
	} else {
		tex->Filter=TF_Trilinear;//@@
		tex->SRGB=true;
		tex->CompressionSettings=TC_Default;
	}

	uint8* TextureData=tex->Source.LockMip(0);
	FMemory::Memset(TextureData,clearCol,res*res*4);
	tex->Source.UnlockMip(0);

	return tex;
}

//.............................................................................
// finaliseTexture
//.............................................................................
void rdLODclass::finaliseTexture(UTexture2D* tex,UPackage* Package,const FString& fileName) {

	tex->AddToRoot();
	tex->UpdateResource();

	Package->FullyLoad();
	Package->SetDirtyFlag(true);
	tex->MarkPackageDirty();
	tex->PreEditChange(NULL);
	tex->PostEditChange();

	ThumbnailTools::GenerateThumbnailForObjectToSaveToDisk(tex);
	FString FilePath=FString::Printf(TEXT("%s%s%s%s"),*absolutePath,*texturePath,*fileName,*FPackageName::GetAssetPackageExtension());
	bool bSuccess=UPackage::SavePackage(Package,tex,EObjectFlags::RF_Public|EObjectFlags::RF_Standalone,*FilePath);

	FAssetRegistryModule::AssetCreated(tex);
}

//----------------------------------------------------------------------------------------------------------------
