// StaticMeshToRenderTarget.h - Copyright (c) 2019 Recourse Design ltd.
#pragma once
#include "Editor.h"
#include "EngineModule.h"
#include "Runtime/Engine/Public/LegacyScreenPercentageDriver.h"
#include "AssetRegistryModule.h"
#include "Runtime/Engine/Public/ComponentReregisterContext.h"
#include "ObjectTools.h"
#include "Runtime/Engine/Public/PreviewScene.h"
#include "Editor/UnrealEd/Public/EditorViewportClient.h"
#include "Editor/UnrealEd/Public/AssetEditorModeManager.h"

class UrdLODtoolsOptions;

//----------------------------------------------------------------------------------------------------------------
class MeshRenderViewportClient : public FEditorViewportClient {
public:
					MeshRenderViewportClient() : FEditorViewportClient(new FAssetEditorModeManager()) {}
	void			SetUpVisualization(FViewport* vp,FCanvas* cvs,const FName& shader);
	virtual void	Draw(FViewport *Viewport,FCanvas *Canvas) override;
	FSceneView*		CalcSceneView(FSceneViewFamily* ViewFamily,const EStereoscopicPass StereoPass) override;

	virtual UWorld* GetWorld() const override { return PreviewScene.GetWorld(); }

	FMatrix						viewRotationMatrix;
	FMatrix						projectionMatrix;

	FPreviewScene				PreviewScene;
	float						tilt;
};

//----------------------------------------------------------------------------------------------------------------
class FOffScreenViewport : public FDummyViewport {
public:

			FOffScreenViewport(FViewportClient* InViewportClient) : FDummyViewport(InViewportClient) {};
	virtual ~FOffScreenViewport() override {};
	void	RenderMesh(UStaticMesh* mesh,UTexture2D* tex,int32 tx,int32 ty,const FRotator& rot,UrdLODtoolsOptions* rdLODoptions,bool linearCol=true);
	void	SetSize(int32 tw,int32 th);

	FCanvas*				Canvas;
	UTextureRenderTarget2D*	rtrgt;
};

//----------------------------------------------------------------------------------------------------------------
class MeshRenderHelper {
public:
	void CreateView(int32 tw,int32 th,float tilt,const FName& shader,bool linearCol=true);
	void DestroyView();

	void RenderMesh(UTexture2D* tex,UStaticMesh* mesh,const FRotator& rot,int32 tx,int32 ty,UrdLODtoolsOptions* rdLODoptions,bool linearCol=true);

	MeshRenderViewportClient*	editorViewportClient;
	FOffScreenViewport*			OffScreenRenderViewport;
};
