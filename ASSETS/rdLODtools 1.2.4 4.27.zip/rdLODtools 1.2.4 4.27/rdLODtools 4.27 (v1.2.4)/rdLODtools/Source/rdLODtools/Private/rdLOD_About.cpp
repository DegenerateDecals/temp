//
// rdLOD_About.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 26th July 2019
// Last Modified: 26th July 2019
//
#include "../Public/rdLODtools.h"
#include "Editor/MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "rdLODtoolsOptions.h"

//----------------------------------------------------------------------------------------------------------------
// ShowAboutWindow
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::ShowAboutWindow() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Opening rdAbout Window..."));
#endif

	ShowAboutSettings();

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Done."));
#endif
}

//----------------------------------------------------------------------------------------------------------------
