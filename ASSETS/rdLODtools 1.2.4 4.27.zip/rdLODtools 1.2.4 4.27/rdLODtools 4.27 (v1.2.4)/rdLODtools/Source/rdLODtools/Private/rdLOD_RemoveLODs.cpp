//
// rdLOD_RemoveLODs.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 27th July 2019
//
#include "../Public/rdLODtools.h"
#include "Editor/StaticMeshEditor/Public/IStaticMeshEditor.h"
#include "Editor/UnrealEd/Public/ScopedTransaction.h"
#include "rdLODtoolsOptions.h"

//----------------------------------------------------------------------------------------------------------------
// RemoveLODs
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::RemoveLODs() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Opening rdRemoveLODs Window..."));
#endif

	mesh=meshEditor->GetStaticMesh(); // Retrieves the current static mesh displayed in the Static Mesh Editor.

	bool ret=ShowCleanSettings();
	if(!ret) {
#ifdef _INCLUDE_DEBUGGING_STUFF
		UE_LOG(LogTemp, Display, TEXT("rdLODtools cancelled."));
#endif
		return;
	}

}

//----------------------------------------------------------------------------------------------------------------
