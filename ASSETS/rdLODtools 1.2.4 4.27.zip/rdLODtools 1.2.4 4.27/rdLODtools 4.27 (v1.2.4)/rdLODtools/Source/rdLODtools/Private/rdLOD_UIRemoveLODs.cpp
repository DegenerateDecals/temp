//
// rdLOD_UIRemoveLODs
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 27th July 2019
//
// Constructs/Handles the rdLODtools RemoveLODs Settings Window
//
#include "rdLODtoolsOptions.h"
#include "Editor/MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "PropertyEditorModule.h"
#include "Runtime/Engine/Classes/Engine/StaticMesh.h"
#if ENGINE_MINOR_VERSION<25
#include "Developer/RawMesh/Public/RawMesh.h"
#else
#include "Runtime/RawMesh/Public/RawMesh.h"
#endif
#include "Runtime/Slate/Public/Widgets/Input/SButton.h"
#include "Runtime/Slate/Public/Widgets/Input/SCheckBox.h"

class rdLODCleanOptions;

class FrdLODCleanOptionsCustomization : public IDetailCustomization {
public:
	static TSharedRef<IDetailCustomization> MakeInstance(rdLODCleanOptions* swin);
								FrdLODCleanOptionsCustomization(rdLODCleanOptions* swin);
	TSharedRef<SWidget>			MakeComboWidget(TSharedPtr<FString> InItem);
	virtual void				CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;

	rdLODCleanOptions*			win;
protected:
	TArray<TSharedPtr<FString>> LODComboList;
	TSharedPtr<STextBlock>		LODComboBoxLabel;
	TArray<TSharedPtr<FString>> exceptLODComboList;
	TSharedPtr<STextBlock>		exceptLODComboBoxLabel;
};

class rdLODCleanOptions : public SCompoundWidget {
public:
	SLATE_BEGIN_ARGS(rdLODCleanOptions)
		: _WidgetWindow()
	{}
		SLATE_ARGUMENT(TSharedPtr<SWindow>,WidgetWindow)
		SLATE_ARGUMENT(TArray<TWeakObjectPtr<UObject>>,SettingsObjects)
		SLATE_END_ARGS()

public:
					rdLODCleanOptions();
	void			Construct(const FArguments& InArgs);

	virtual bool	SupportsKeyboardFocus() const override { return true; }
	virtual FReply	OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override { return (InKeyEvent.GetKey()==EKeys::Escape)?OnCancel():FReply::Unhandled(); }
	FReply			OnConfirm(){
						bUserCancelled=false;
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}
	FReply			OnCancel() {
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}

	bool			WasUserCancelled() { return bUserCancelled; }
	bool			WantsToEditMats() { return bEditMats; }
	bool			DuplicateMesh(){ return bDuplicateMesh; }
private:
	TWeakPtr<SWindow>				WidgetWindow;
	bool							bUserCancelled;
	bool							bEditMats;
	bool							bDuplicateMesh;
	TSharedPtr<class IDetailsView>	DetailsView;
	TSharedPtr<SButton>				EditMatsButton;
	TSharedPtr<SButton>				DuplicateAndConfirmButton;
	TSharedPtr<SButton>				ConfirmButton;
};

TSharedRef<IDetailCustomization> FrdLODCleanOptionsCustomization::MakeInstance(rdLODCleanOptions* swin) {
	return MakeShareable(new FrdLODCleanOptionsCustomization(swin));
}

//.............................................................................
// Constructor
//.............................................................................
FrdLODCleanOptionsCustomization::FrdLODCleanOptionsCustomization(rdLODCleanOptions* swin) : win(swin) {
}

TSharedRef<SWidget> FrdLODCleanOptionsCustomization::MakeComboWidget(TSharedPtr<FString> InItem) {
	return SNew(STextBlock).Text(FText::FromString(*InItem)).Font(FEditorStyle::GetFontStyle(TEXT("PropertyWindow.NormalFont")));
}

//.............................................................................
// CustomizeDetails
//.............................................................................
void FrdLODCleanOptionsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) {

	TArray<TWeakObjectPtr<UObject>> WeakObjects;
	DetailBuilder.GetObjectsBeingCustomized(WeakObjects);

	// Try and find rdLODtools options instance in currently edited objects
	UrdLODtoolsOptions* CurrentOptions=Cast<UrdLODtoolsOptions>((WeakObjects.FindByPredicate([](TWeakObjectPtr<UObject> Object) { return Cast<UrdLODtoolsOptions>(Object.Get()); }))->Get());

	exceptLODComboList.Empty();
	for(int32 i=0;i<CurrentOptions->maxLODs;i++) {
		exceptLODComboList.Add(MakeShareable(new FString(*FString::Printf(TEXT("%d"),i))));
	}

	IDetailCategoryBuilder& CategoryBuilder0=DetailBuilder.EditCategory(TEXT("Remove Billboard and Planar LODs"));

	// .......................................................................
	// Billboard LODs

	FDetailWidgetRow& lrow0a=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Remove Billboard and Planar LODs")));
	lrow0a.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Remove Billboard LODs")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox0a;
	lrow0a.ValueContent()
		[
			SAssignNew(ContentBox0a,SHorizontalBox)
		];

	ContentBox0a->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_RemoveBillboardLOD","Remove Billboard LODs"))
			.ToolTipText(LOCTEXT("rdLODtools_Clean_Remove1","Removes any Billboard LODs in the mesh"))
			.OnClicked_Lambda([this,CurrentOptions](){ CurrentOptions->OnRemoveBillboardLODs(); win->OnConfirm(); return FReply::Handled(); })
		];

	// .......................................................................
	// Planar LODs

	FDetailWidgetRow& lrow0b=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Remove Planar LODs")));
	lrow0b.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Remove Planar LODs")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox0b;
	lrow0b.ValueContent()
		[
			SAssignNew(ContentBox0b,SHorizontalBox)
		];

	ContentBox0b->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_RemovePlanarLOD","Remove Planar LODs"))
			.ToolTipText(LOCTEXT("rdLODtools_Clean_Remove2","Removes any Planar LODs in the mesh"))
			.OnClicked_Lambda([this,CurrentOptions](){ CurrentOptions->OnRemovePlanarLODs(); win->OnConfirm(); return FReply::Handled(); })
		];

	// .......................................................................
	// Remove LOD

	IDetailCategoryBuilder& CategoryBuilder1=DetailBuilder.EditCategory(TEXT("Remove LODs"));

	FDetailWidgetRow& lrow1=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Remove LODs")));
	lrow1.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Remove LOD")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox1a;
	lrow1.ValueContent()
		[
			SAssignNew(ContentBox1a,SHorizontalBox)
		];

	ContentBox1a->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&exceptLODComboList)
			.OnGenerateWidget(this,&FrdLODCleanOptionsCustomization::MakeComboWidget)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->removeLOD=getSourceLODComboInt(*Selection); LODComboBoxLabel.Get()->SetText(FText::FromString(*Selection));
										})
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0a","LOD to remove: Specify the LOD that you wish to remove, all others will be kept."))
			.Content()
			[
				SAssignNew(LODComboBoxLabel,STextBlock)
				.Text(getSourceLODComboString(CurrentOptions->removeLOD))
				.MinDesiredWidth(80)
			]
		];

	FDetailWidgetRow& lrow1b=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT(" ")));
	lrow1b.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT(" ")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox1b;
	lrow1b.ValueContent()
		[
			SAssignNew(ContentBox1b,SHorizontalBox)
		];

	ContentBox1b->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_RemoveLOD","Remove LOD"))
			.ToolTipText(LOCTEXT("rdLODtools_Clean_Remove3","Removes the LOD from the mesh, leaving all the others."))
			.IsEnabled_Lambda([=]{ return CurrentOptions->mesh && CurrentOptions->GetMeshSourceModels().Num()>1; })
			.OnClicked_Lambda([this,CurrentOptions](){ CurrentOptions->OnRemoveLOD(); win->OnConfirm(); return FReply::Handled(); })
		];

	// .......................................................................
	// Remove All But LOD section


	FDetailWidgetRow& lrow1c=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Remove LODs")));
	lrow1c.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Remove All LODs except")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox1c;
	lrow1c.ValueContent()
		[
			SAssignNew(ContentBox1c,SHorizontalBox)
		];

	ContentBox1c->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&exceptLODComboList)
			.OnGenerateWidget(this,&FrdLODCleanOptionsCustomization::MakeComboWidget)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->removeExceptLOD=getSourceLODComboInt(*Selection); exceptLODComboBoxLabel.Get()->SetText(FText::FromString(*Selection));
										})
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0c","LOD to keep: Specify the LOD that you wish to keep, all others will be deleted when you click the button below."))
			.Content()
			[
				SAssignNew(exceptLODComboBoxLabel,STextBlock)
				.Text(getSourceLODComboString(CurrentOptions->removeExceptLOD))
				.MinDesiredWidth(80)
			]
		];

	FDetailWidgetRow& lrow1d=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT(" ")));
	lrow1d.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT(" ")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(200)
		];

	TSharedPtr<SHorizontalBox> ContentBox1d;
	lrow1d.ValueContent()
		[
			SAssignNew(ContentBox1d,SHorizontalBox)
		];

	ContentBox1d->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_RemoveAllExcept","Remove all LODs Except"))
			.ToolTipText(LOCTEXT("rdLODtools_Clean_Remove3d","Removes all LODs in the mesh except for the specified one."))
			.OnClicked_Lambda([this,CurrentOptions](){ CurrentOptions->OnRemoveAllLODsExcept(); win->OnConfirm(); return FReply::Handled(); })
		];
}

rdLODCleanOptions::rdLODCleanOptions() : bUserCancelled(true),bEditMats(false),bDuplicateMesh(false) {}

//.............................................................................
// Construct
//.............................................................................
void rdLODCleanOptions::Construct(const FArguments& InArgs) {

	WidgetWindow = InArgs._WidgetWindow;

	// Retrieve property editor module and create a SDetailsView
	FPropertyEditorModule& PropertyEditorModule=FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bAllowSearch=false;
	DetailsViewArgs.NameAreaSettings=FDetailsViewArgs::HideNameArea;
	DetailsViewArgs.bAllowMultipleTopLevelObjects=true;

	DetailsView=PropertyEditorModule.CreateDetailView(DetailsViewArgs);

	// Register instance property customization
	DetailsView->RegisterInstancedCustomPropertyLayout(UrdLODtoolsOptions::StaticClass(), 
														FOnGetDetailCustomizationInstance::CreateLambda([=]() { return FrdLODCleanOptionsCustomization::MakeInstance(this); }));

	// Set up root object customization to get desired layout
	DetailsView->SetRootObjectCustomizationInstance(MakeShareable(new FSimpleRootObjectCustomization));

	// Set provided objects on SDetailsView
	DetailsView->SetObjects(InArgs._SettingsObjects,true);

	this->ChildSlot
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
		.Padding(2)
		.MaxHeight(700.0f)
		[
			DetailsView->AsShared()
		]

	+ SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Center)
		.Padding(2)
		[
			SNew(SUniformGridPanel)
			.SlotPadding(2)
		+ SUniformGridPanel::Slot(0,0)
		[
			SAssignNew(ConfirmButton,SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_Close","Close"))
			.ToolTipText(LOCTEXT("rdLODtools_Clean_ToolTip3","Closes this window"))
			.OnClicked(this,&rdLODCleanOptions::OnConfirm)
		]
	]
	];
}

//.............................................................................
// ShowCleanSettings
//.............................................................................
bool rdLODclass::ShowCleanSettings() {

	rdLODoptions=DuplicateObject(GetMutableDefault<UrdLODtoolsOptions>(),GetTransientPackage());
	rdLODoptions->mesh=mesh;
	rdLODoptions->meshEditor=meshEditor;
	rdLODoptions->maxLODs=mesh->GetNumLODs();

	// Create the settings window...
	TSharedRef<SWindow> winLOD=SNew(SWindow)
										.Title(FText::FromString(TEXT("rdLODtools Clean LODs")))
										.SizingRule(ESizingRule::UserSized)
										.AutoCenter(EAutoCenter::PreferredWorkArea)
										.ClientSize(FVector2D(440,300));

	TArray<TWeakObjectPtr<UObject>> OptionObjects{ rdLODoptions };
	TSharedPtr<rdLODCleanOptions> Options;

	winLOD->SetContent(SAssignNew(Options,rdLODCleanOptions)
						.WidgetWindow(winLOD)
						.SettingsObjects(OptionObjects)
					  );

	TSharedPtr<SWindow> ParentWindow;
	if(!FModuleManager::Get().IsModuleLoaded("MainFrame")) {
		return false;
	}

	// Show Settings Window
	IMainFrameModule& MainFrame=FModuleManager::LoadModuleChecked<IMainFrameModule>("MainFrame");
	FSlateApplication::Get().AddModalWindow(winLOD,MainFrame.GetParentWindow(),false);

	return !Options->WasUserCancelled();
}

//.............................................................................
