//
// rdLOD_MeshHelpers.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 14th March 2021
//
// version 1.2
//		FIXED:	 There was Clipping when the mesh was not centered
//		CHANGED: Only one UV map is created now
//		FIXED:   CenterPivot was not scaling up the offset to the SourceModels scale
//
#include "../Public/rdLODtools.h"
#if ENGINE_MINOR_VERSION<25
#include "Developer/RawMesh/Public/RawMesh.h"
#else
#include "Runtime/RawMesh/Public/RawMesh.h"
#endif
//----------------------------------------------------------------------------------------------------------------
// CreateMesh
// Creates a simple Plane at the specified angle
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CreateMesh(FRawMesh& rawMesh,float angle,float xoffset,float yoffset,float zoffset,float tilt,float zoom,const FVector2D& uv1,const FVector2D& uv2) { // uv1=bottom-left, uv2=top-right

	FBox bx=mesh->GetBoundingBox();
	FBoxSphereBounds sbx=mesh->GetBoundingBox();
	float left,right,front,back,cY=yoffset,top=bx.Max.Z,bottom=bx.Min.Z;

	if((bx.Max.X-bx.Min.X)>(bx.Max.Y-bx.Min.Y)) {
		left=bx.Min.X; //FIXED: when the mesh isn't centered we need to make our plane bigger and the scale smaller to account
		right=bx.Max.X;
		front=bx.Min.Y;
		back=bx.Max.Y;
		if(sbx.Origin.X<0.0) right-=(sbx.Origin.X*2.0);
		else left-=(sbx.Origin.X*2.0);
	} else {
		left=bx.Min.Y;
		right=bx.Max.Y;
		front=bx.Min.X;
		back=bx.Max.X;
		if(sbx.Origin.Y<0.0) right-=(sbx.Origin.Y*2.0);
		else left-=(sbx.Origin.Y*2.0);
	}
	left+=xoffset; // 28th Feb 2021 - Added an offset to the mesh for planar LODs to have a very small gap between sides
	right+=xoffset;//                 The Normalmap was bleeding between sides
	float tiltAmt=(tilt/90.0)*fabs(back-front); // 7th March 2021 - Added an adjustable Tilt to the mesh to help with lighting - tilt between 0 and 45

	TArray<FVector> Vertices;
	FVector vUp=FVector(0,0,1);

	float zoomW=(((right-left)*zoom)-(right-left))/2.0;
	left-=zoomW;
	right+=zoomW;

	float zoomH=(((bottom-top)*zoom)-(bottom-top))/2.0;
	top-=zoomH;

	unsigned int i1=rawMesh.VertexPositions.Add(FVector(left,cY+tiltAmt,bottom).RotateAngleAxis(angle,vUp));//0 = bottom-left (0,1)
	unsigned int i2=rawMesh.VertexPositions.Add(FVector(left,cY-tiltAmt,top).RotateAngleAxis(angle,vUp));//1 = top-left (0,0)
	unsigned int i3=rawMesh.VertexPositions.Add(FVector(right,cY+tiltAmt,bottom).RotateAngleAxis(angle,vUp));//2 = bottom-right (1,1)
	unsigned int i4=rawMesh.VertexPositions.Add(FVector(right,cY-tiltAmt,top).RotateAngleAxis(angle,vUp));//3 = top-right (1,0)

	int numberOfVertices=Vertices.Num();

	struct Face {
		unsigned int v1;
		unsigned int v2;
		unsigned int v3;
		short materialID;
		FVector2D uvCoords1;
		FVector2D uvCoords2;
		FVector2D uvCoords3;
	};

	TArray<Face> Faces;
	Face oneFace;
	oneFace={ i1,i3,i2,  0,  FVector2D(uv1.X,uv2.Y),uv2,uv1 }; // 0,0=bottom-left    0,1=top-left    1,1=top-right      1,0=bottom-right
	Faces.Add(oneFace);
	oneFace={ i3,i4,i2,  0,  uv2,FVector2D(uv2.X,uv1.Y),uv1 };
	Faces.Add(oneFace);
	int numberOfFaces=Faces.Num(); // always 2 for a plane

	FColor WhiteVertex=FColor(255,255,255,255);
	FVector EmptyVector=FVector(0,0,0);

	// Faces and UV/Normals
	for(int faceIndex=0;faceIndex<numberOfFaces;faceIndex++) {

		rawMesh.WedgeIndices.Add(Faces[faceIndex].v1);
		rawMesh.WedgeIndices.Add(Faces[faceIndex].v2);
		rawMesh.WedgeIndices.Add(Faces[faceIndex].v3);

		rawMesh.WedgeColors.Add(WhiteVertex);
		rawMesh.WedgeColors.Add(WhiteVertex);
		rawMesh.WedgeColors.Add(WhiteVertex);

		rawMesh.WedgeTangentX.Add(EmptyVector);
		rawMesh.WedgeTangentX.Add(EmptyVector);
		rawMesh.WedgeTangentX.Add(EmptyVector);

		rawMesh.WedgeTangentY.Add(EmptyVector);
		rawMesh.WedgeTangentY.Add(EmptyVector);
		rawMesh.WedgeTangentY.Add(EmptyVector);

		rawMesh.WedgeTangentZ.Add(EmptyVector);
		rawMesh.WedgeTangentZ.Add(EmptyVector);
		rawMesh.WedgeTangentZ.Add(EmptyVector);

		// Materials
		rawMesh.FaceMaterialIndices.Add(0);

		rawMesh.FaceSmoothingMasks.Add(0xFFFFFFFF); // Phong

		rawMesh.WedgeTexCoords[0].Add(Faces[faceIndex].uvCoords1);
		rawMesh.WedgeTexCoords[0].Add(Faces[faceIndex].uvCoords2);
		rawMesh.WedgeTexCoords[0].Add(Faces[faceIndex].uvCoords3);
	}
}

//----------------------------------------------------------------------------------------------------------------
// CreatePlanarMesh
// Creates the Planes for the Planar LOD
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CreatePlanarMesh(FRawMesh& rawMesh,UMaterialInstanceConstant* mi) {

	int32 matInd=mesh->StaticMaterials.Num();
	if(origMatInd>=0) {
		matInd=origMatInd;
		mesh->StaticMaterials[matInd].MaterialInterface=mi;
	} else {
		mesh->StaticMaterials.Add(mi);
	}
	mesh->StaticMaterials[matInd].ImportedMaterialSlotName=TEXT("rdPlanar");

	int32 ind=GetMeshSourceModels().Num();
	if(origMeshInd>=0) {
		ind=origMeshInd;
	}

	FMeshSectionInfo msi=FMeshSectionInfo(matInd);
	msi.bCastShadow=rdLODoptions->shadows;
	if(origMatInd<0) {
		GetMeshSectionInfoMap().Set(ind,0,msi);
	}

	float angleInc=360.0/(rdLODoptions->numFrames*2.0);
	float uvInc=1.0/ceil(sqrt(rdLODoptions->numFrames*2));
	float uvU=0.0,uvV=1.0-uvInc;
	// 28th Feb 2021 - Added an offset to the mesh planes to have a very small gap between sides
	//                 The Normalmap was bleeding between sides
	float xoff=0.0,yoff=0.0;

	//FIXED:2020.12.22:Planar LODs were not showing the correct faces
	for(float angle=180.0;angle>-180.0;angle-=angleInc) {
		xoff=sin(angle+180)/100.0;
		yoff=cos(angle+180)/100.0;
		CreateMesh(rawMesh,angle,xoff,yoff,0,rdLODoptions->meshTilt,rdLODoptions->meshZoom,FVector2D(uvU,uvV),FVector2D(uvU+uvInc,uvV+uvInc));
		uvU+=uvInc;
		if(uvU>=1.0) {
			uvV-=uvInc;
			uvU=0.0;
		}
	}
}

//----------------------------------------------------------------------------------------------------------------
// CreateBillboardMesh
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CreateBillboardMesh(FRawMesh& rawMesh,UMaterialInstanceConstant* mi) {

	int32 matInd=mesh->StaticMaterials.Num();
	if(origMatInd>=0) {
		matInd=origMatInd;
		mesh->StaticMaterials[matInd].MaterialInterface=mi;
	} else {
		mesh->StaticMaterials.Add(mi);
		mesh->StaticMaterials[matInd].ImportedMaterialSlotName=TEXT("rdBillboard");
	}

	int32 ind=GetMeshSourceModels().Num();
	if(origMeshInd>=0) {
		ind=origMeshInd;
	}

	if(origMatInd<0) {
		FMeshSectionInfo msi=FMeshSectionInfo(matInd);
		msi.bCastShadow=rdLODoptions->shadows;
		GetMeshSectionInfoMap().Set(ind,0,msi);
	}

	CreateMesh(rawMesh,0.0f,0,0,0,rdLODoptions->meshTilt,rdLODoptions->meshZoom,FVector2D(0,0),FVector2D(1,1));
	if(rdLODoptions->shadows) {
		CreateMesh(rawMesh,90.0f,0,0,0,0.0,rdLODoptions->meshZoom,FVector2D(0,0),FVector2D(1,1));
	}
}

//.............................................................................
// CentreMeshPivot
// Centre the mesh so the pivot is at the centre (for billboard rotation)
//.............................................................................
void rdLODclass::CentreMeshPivot() {

	if(mesh) {

		// Center the Mesh for a completely central pivot point
		FBoxSphereBounds bx=mesh->GetBoundingBox();
		FVector meshCenter=bx.GetSphere().Center;
		float bottomZ=bx.GetBox().Min.Z;

#ifdef _INCLUDE_DEBUGGING_STUFF
		FBox box=bx.GetBox();
		UE_LOG(LogTemp, Display, TEXT("Mesh Box :%f,%f,%f - %f,%f,%f - Mesh Extent: %f,%f,%f - SphereCenter: %f,%f,%f"),box.Min.X,box.Min.Y,box.Min.Z,box.Max.X,box.Max.Y,box.Max.Z,bx.BoxExtent.X,bx.BoxExtent.Y,bx.BoxExtent.Z,meshCenter.X,meshCenter.Y,meshCenter.Z);
#endif
		int32 num=GetMeshSourceModels().Num();
		FRawMesh rawMesh=FRawMesh();

		for(int32 i=0;i<num;++i) {

			FVector scale=GetMeshSourceModel(i).BuildSettings.BuildScale3D;

			GetMeshSourceModel(i).LoadRawMesh(rawMesh);

			FVector* vert=&(rawMesh.VertexPositions[0]);
			int32 numVerts=rawMesh.VertexPositions.Num();
			for(int32 v=0;v<numVerts;++v) {
				vert[v].X-=(meshCenter.X*(1.0/scale.X));
				vert[v].Y-=(meshCenter.Y*(1.0/scale.Y));
				vert[v].Z-=(bottomZ*(1.0/scale.Z));
			}

			GetMeshSourceModel(i).SaveRawMesh(rawMesh);
		}

		mesh->CreateBodySetup();
		mesh->PostEditChange();
	}
}

//----------------------------------------------------------------------------------------------------------------
