//
// rdLOD_UIPlanar
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 16th March 2021
//
// Constructs/Handles the rdLODtools Planar Generator Settings Window
//
// version 1.24
//		FIXED:   7th March 2021 - crash when setting size of 256px and 64 frames
//		CHANGED: 28th Feb 2021 - Removed Fake Shading
//		CHANGED: 16th March 2021 - Removed Temparay material UI bits
//
// version 1.2
//		FIXED: Added check to the SourceLOD to make sure any saved source is still valid
//
#include "rdLODtoolsOptions.h"
#include "Editor/MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "PropertyEditorModule.h"
#include "Runtime/Engine/Classes/Engine/StaticMesh.h"
#if ENGINE_MINOR_VERSION<25
#include "Developer/RawMesh/Public/RawMesh.h"
#else
#include "Runtime/RawMesh/Public/RawMesh.h"
#endif
#include "Runtime/Slate/Public/Widgets/Input/SComboBox.h"
#include "Runtime/Slate/Public/Widgets/Input/SButton.h"
#include "Runtime/Slate/Public/Widgets/Input/SCheckBox.h"

class FrdLODPlanarOptionsCustomization : public IDetailCustomization {
public:
	static TSharedRef<IDetailCustomization> MakeInstance();
								FrdLODPlanarOptionsCustomization();
	TSharedRef<SWidget>			MakeComboWidget(TSharedPtr<FString> InItem);
	virtual void				CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) override;
protected:
	TArray<TSharedPtr<FString>> mtypeComboList;
	TSharedPtr<STextBlock>		mtypeComboBoxLabel;

	TArray<TSharedPtr<FString>> sourceLODComboList;
	TSharedPtr<STextBlock>		sourceLODComboBoxLabel;

	TArray<TSharedPtr<FString>> resComboList;
	TSharedPtr<STextBlock>		bbResComboBoxLabel;
	TSharedPtr<STextBlock>		plResComboBoxLabel;

	TArray<TSharedPtr<FString>> numFramesComboList;
	TSharedPtr<STextBlock>		numFramesComboBoxLabel;
};

class rdLODPlanarOptions : public SCompoundWidget {
public:
	SLATE_BEGIN_ARGS(rdLODPlanarOptions)
		: _WidgetWindow()
	{}
		SLATE_ARGUMENT(TSharedPtr<SWindow>,WidgetWindow)
		SLATE_ARGUMENT(TArray<TWeakObjectPtr<UObject>>,SettingsObjects)
		SLATE_END_ARGS()

public:
					rdLODPlanarOptions();
	void			Construct(const FArguments& InArgs);

	virtual bool	SupportsKeyboardFocus() const override { return true; }
	virtual FReply	OnKeyDown(const FGeometry& MyGeometry, const FKeyEvent& InKeyEvent) override { return (InKeyEvent.GetKey()==EKeys::Escape)?OnCancel():FReply::Unhandled(); }
	FReply			OnConfirm(){
						bUserCancelled=false;
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}
	FReply			OnDuplicateAndConfirm() {
						bUserCancelled=false;
						bDuplicateMesh=true;
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}
	FReply			OnCancel() {
						if(WidgetWindow.IsValid()) {
							WidgetWindow.Pin()->RequestDestroyWindow();
						}
						return FReply::Handled();
					}
	bool			WasUserCancelled() { return bUserCancelled; }
	bool			DuplicateMesh(){ return bDuplicateMesh; }
private:
	TWeakPtr<SWindow>				WidgetWindow;
	bool							bUserCancelled;
	bool							bDuplicateMesh;
	TSharedPtr<class IDetailsView>	DetailsView;
	TSharedPtr<SButton>				DuplicateAndConfirmButton;
	TSharedPtr<SButton>				ConfirmButton;
};

TSharedRef<IDetailCustomization> FrdLODPlanarOptionsCustomization::MakeInstance() {
	return MakeShareable(new FrdLODPlanarOptionsCustomization());
}

//.............................................................................
// Constructor
//.............................................................................
FrdLODPlanarOptionsCustomization::FrdLODPlanarOptionsCustomization() {

	mtypeComboList.Add(MakeShareable(new FString(TEXT("General Mesh"))));
	mtypeComboList.Add(MakeShareable(new FString(TEXT("Foliage"))));

	resComboList.Add(MakeShareable(new FString(TEXT("256x256"))));
	resComboList.Add(MakeShareable(new FString(TEXT("512x512"))));
	resComboList.Add(MakeShareable(new FString(TEXT("1024x1024"))));
	resComboList.Add(MakeShareable(new FString(TEXT("2048x2048"))));
	resComboList.Add(MakeShareable(new FString(TEXT("4096x4096"))));
	resComboList.Add(MakeShareable(new FString(TEXT("8192x8192"))));

	numFramesComboList.Add(MakeShareable(new FString(TEXT("2"))));
	numFramesComboList.Add(MakeShareable(new FString(TEXT("3"))));
	numFramesComboList.Add(MakeShareable(new FString(TEXT("4"))));
	numFramesComboList.Add(MakeShareable(new FString(TEXT("8"))));
	numFramesComboList.Add(MakeShareable(new FString(TEXT("16"))));
	numFramesComboList.Add(MakeShareable(new FString(TEXT("32"))));
}

TSharedRef<SWidget> FrdLODPlanarOptionsCustomization::MakeComboWidget(TSharedPtr<FString> InItem) {
	return SNew(STextBlock).Text(FText::FromString(*InItem)).Font(FEditorStyle::GetFontStyle(TEXT("PropertyWindow.NormalFont")));
}

//.............................................................................
// CustomizeDetails
//.............................................................................
void FrdLODPlanarOptionsCustomization::CustomizeDetails(IDetailLayoutBuilder& DetailBuilder) {

	TArray<TWeakObjectPtr<UObject>> WeakObjects;
	DetailBuilder.GetObjectsBeingCustomized(WeakObjects);

	// Try and find rdLODtools options instance in currently edited objects
	UrdLODtoolsOptions* CurrentOptions=Cast<UrdLODtoolsOptions>((WeakObjects.FindByPredicate([](TWeakObjectPtr<UObject> Object) { return Cast<UrdLODtoolsOptions>(Object.Get()); }))->Get());

	sourceLODComboList.Empty();
	for(int32 i=0;i<CurrentOptions->maxLODs;i++) {
		if(	CurrentOptions->GetMeshSourceModel(i).SourceImportFilename!=TEXT("rdBillboard.inline") &&
			CurrentOptions->GetMeshSourceModel(i).SourceImportFilename!=TEXT("rdPlanar.inline")) {

				sourceLODComboList.Add(MakeShareable(new FString(*FString::Printf(TEXT("%d"),i))));
		}
	}

	IDetailCategoryBuilder& CategoryBuilder0=DetailBuilder.EditCategory(TEXT("General Settings"));

	FDetailWidgetRow& lrow0=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("General Settings")));
	lrow0.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Mesh Type")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox0;
	lrow0.ValueContent()
		[
			SAssignNew(ContentBox0,SHorizontalBox)
		];

	ContentBox0->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&mtypeComboList)
			.OnGenerateWidget(this,&FrdLODPlanarOptionsCustomization::MakeComboWidget)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->meshType=getMTypeComboInt(*Selection); 	mtypeComboBoxLabel.Get()->SetText(FText::FromString(*Selection));
										})
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0","Mesh Type: Different mesh types have different LOD creation methods.\nIt pays to select the correct type here first."))
			.Content()
			[
				SAssignNew(mtypeComboBoxLabel,STextBlock)
				.Text(getMTypeComboString(CurrentOptions->meshType))
				.MinDesiredWidth(80)
			]
		];

	// .......................................................................
	// Source LOD

	FDetailWidgetRow& lrow0a=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Source LOD")));
	lrow0a.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Source LOD")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox0a;
	lrow0a.ValueContent()
		[
			SAssignNew(ContentBox0a,SHorizontalBox)
		];

	ContentBox0a->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&sourceLODComboList)
			.OnGenerateWidget(this,&FrdLODPlanarOptionsCustomization::MakeComboWidget)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->sourceLOD=getSourceLODComboInt(*Selection);	sourceLODComboBoxLabel.Get()->SetText(FText::FromString(*Selection));
										})
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0a","Source LOD: Specify the LOD level you wish to use as the Source. (1=Closest LOD)\nThe most seamless effect is by selecting the last LOD."))
			.Content()
			[
				SAssignNew(sourceLODComboBoxLabel,STextBlock)
				.Text(getSourceLODComboString(CurrentOptions->sourceLOD))
				.MinDesiredWidth(80)
			]
		];

	// .......................................................................
	// Center Pivot

	FDetailWidgetRow& lrow0b=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Centre Pivot")));
	lrow0b.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Centre Pivot")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox0b;
	lrow0b.ValueContent()
		[
			SAssignNew(ContentBox0b,SHorizontalBox)
		];

	ContentBox0b->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  (CurrentOptions->centrePivot)?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->centrePivot=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0b", "Centre the Pivot Point of the Mesh.\nThis needs to be done for edged based pivots to make sure the Billboards rotate correctly.\nNote: This can not be undone, plase make a backup first."))
		];

	// .......................................................................
	// Copy Master Materials

	FDetailWidgetRow& lrow0c=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Copy Master Materials")));
	lrow0c.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Copy Master Materials")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox0c;
	lrow0c.ValueContent()
		[
			SAssignNew(ContentBox0c,SHorizontalBox)
		];

	ContentBox0c->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  (CurrentOptions->copyMasters)?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->copyMasters=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0f", "Copy the Master Materials into the meshes Material Folder and reference those."))
		];

	// .......................................................................
	// Render Tilt

	FDetailWidgetRow& lrow0d=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Render Tilt")));
	lrow0d.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Render Tilt")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox0d;
	lrow0d.ValueContent()
		[
			SAssignNew(ContentBox0d, SHorizontalBox)
		];

	ContentBox0d->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SSpinBox<float>)
			.MinDesiredWidth(100)
			.Value_Lambda([=]{ return CurrentOptions->renderTilt; })
			.OnValueChanged_Lambda([=](float val){ CurrentOptions->renderTilt=val;})
			.MinValue(-45.0)
			.MaxValue(45.0)
			.MaxSliderValue(45.0)
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0g", "Render Tilt: Renders the billboard with a tilt (-45*->45*) to help with depth."))
		];

	// .......................................................................
	// Mesh Tilt

	FDetailWidgetRow& lrow0e=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Mesh Tilt")));
	lrow0e.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Mesh Tilt")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox0e;
	lrow0e.ValueContent()
		[
			SAssignNew(ContentBox0e, SHorizontalBox)
		];

	ContentBox0e->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SSpinBox<float>)
			.MinDesiredWidth(100)
			.Value_Lambda([=]{ return CurrentOptions->meshTilt; })
			.OnValueChanged_Lambda([=](float val){ CurrentOptions->meshTilt=val;})
			.MinValue(0.0)
			.MaxValue(45.0)
			.MaxSliderValue(45.0)
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0h", "Mesh Tilt: Tilts the billboard (0*->45*) to help with lighting and smaller objects."))
		];

	// .......................................................................
	// Mesh Zoom

	FDetailWidgetRow& lrow0f=CategoryBuilder0.AddCustomRow(FText::FromString(TEXT("Mesh Zoom")));
	lrow0f.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Mesh Zoom")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox0f;
	lrow0f.ValueContent()
		[
			SAssignNew(ContentBox0f, SHorizontalBox)
		];

	ContentBox0f->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SSpinBox<float>)
			.MinDesiredWidth(100)
			.Value_Lambda([=]{ return CurrentOptions->meshZoom; })
			.OnValueChanged_Lambda([=](float val){ CurrentOptions->meshZoom=val;})
			.MinValue(0.1)
			.MaxValue(10.0)
			.MaxSliderValue(10.0)
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0i", "Mesh Zoom: Makes the billboard larger or smaller."))
		];

	// .......................................................................
	// Billboard LOD section

	IDetailCategoryBuilder& CategoryBuilder1=DetailBuilder.EditCategory(TEXT("Lighting"));

	// .......................................................................
	// MakeNormalMap

	FDetailWidgetRow& lrow1b=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Make NormalMap")));
	lrow1b.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Make NormalMap")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox1b;
	lrow1b.ValueContent()
		[
			SAssignNew(ContentBox1b,SHorizontalBox)
		];

	ContentBox1b->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  (CurrentOptions->makeNormalMap)?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->makeNormalMap=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0d", "Make NormalMap - creates a normal map containing each frame of the LOD.\n  The Alpha channel of the Normal contains the AO data."))
		];

	// .......................................................................
	// MakeOtherMaps

	FDetailWidgetRow& lrow1c=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Make Other Maps")));
	lrow1c.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Make Other Maps")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox1c;
	lrow1c.ValueContent()
		[
			SAssignNew(ContentBox1c,SHorizontalBox)
		];

	ContentBox1c->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  (CurrentOptions->makeOtherMaps)?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->makeOtherMaps=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0e", "Make Other Maps -  creates a texture containing the metallic, roughness and specular data for each frame of the LOD."))
		];

	// .......................................................................
	// InverseOpacity

	FDetailWidgetRow& lrow1d=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Inverse Opacity Map")));
	lrow1d.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Inverse Opacity Map")))
			.Font(DetailBuilder.GetDetailFont())
			.MinDesiredWidth(160)
		];

	TSharedPtr<SHorizontalBox> ContentBox1d;
	lrow1d.ValueContent()
		[
			SAssignNew(ContentBox1d,SHorizontalBox)
		];

	ContentBox1d->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  CurrentOptions->inverseOpacity?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->inverseOpacity=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip0ee", "Inverse Opacity Map - If your LOD is invisible or has parts missing, try ticking this."))
		];

	// .......................................................................
	// Cast Shadow

	FDetailWidgetRow& lrow1e=CategoryBuilder1.AddCustomRow(FText::FromString(TEXT("Cast Shadow")));
	lrow1e.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Cast Shadow")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox1e;
	lrow1e.ValueContent()
		[
			SAssignNew(ContentBox1e,SHorizontalBox)
		];

	ContentBox1e->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  CurrentOptions->shadows?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->shadows=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip6", "Cast Shadow: Cast a shadow from this LOD (note this does slow the rendering down by a small fraction)."))
		];

	// .......................................................................
	// Planar LOD section

	IDetailCategoryBuilder& CategoryBuilder=DetailBuilder.EditCategory(TEXT("Planar LOD"));

	// .......................................................................
	// Number of Planes
	FDetailWidgetRow& lrow2=CategoryBuilder.AddCustomRow(FText::FromString(TEXT("Number of Planes")));
	lrow2.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Number of Planes")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox2;
	lrow2.ValueContent()
		[
			SAssignNew(ContentBox2,SHorizontalBox)
		];

	ContentBox2->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&numFramesComboList)
			.OnGenerateWidget(this,&FrdLODPlanarOptionsCustomization::MakeComboWidget)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->numFrames=FCString::Atoi(*FString(*Selection)); numFramesComboBoxLabel.Get()->SetText(FText::FromString(FString::FromInt(CurrentOptions->numFrames))); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip2","Number of Planes: how many planes the planar LOD should have."))
			.Content()
			[
				SAssignNew(numFramesComboBoxLabel,STextBlock)
				.Text(FText::FromString(*FString::FromInt(CurrentOptions->numFrames)))
				.MinDesiredWidth(80)
			]
		];

	// .......................................................................
	// Billboard Resolution

	FDetailWidgetRow& lrow3=CategoryBuilder.AddCustomRow(FText::FromString(TEXT("Resolution")));
	lrow3.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Resolution")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox3;
	lrow3.ValueContent()
		[
			SAssignNew(ContentBox3,SHorizontalBox)
		];

	ContentBox3->AddSlot()
		.Padding(FMargin(2.0f,2.0f,2.0f,2.0f))
		.AutoWidth()
		[
			SNew(SComboBox<TSharedPtr<FString>>)
			.OptionsSource(&resComboList)
			.OnSelectionChanged_Lambda([=](TSharedPtr<FString> Selection,ESelectInfo::Type SelectInfo){ CurrentOptions->res=getResComboInt(*Selection); bbResComboBoxLabel.Get()->SetText(getResComboString(CurrentOptions->res)); })
			.OnGenerateWidget(this,&FrdLODPlanarOptionsCustomization::MakeComboWidget)
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip3", "Resolution: The size of the stored planar texture."))
			.Content()
			[
				SAssignNew(bbResComboBoxLabel,STextBlock)
				.Text(getResComboString(CurrentOptions->res))
				.MinDesiredWidth(80)
			]
		];

	// .......................................................................
	// Screen Size

	FDetailWidgetRow& lrow6=CategoryBuilder.AddCustomRow(FText::FromString(TEXT("Screen Size")));
	lrow6.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("Screen Size")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox7;
	lrow6.ValueContent()
		[
			SAssignNew(ContentBox7, SHorizontalBox)
		];

	ContentBox7->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SSpinBox<float>)
			.MinDesiredWidth(100)
			.Value_Lambda([=]{ return CurrentOptions->screenSize; })
			.OnValueChanged_Lambda([=](float val){ CurrentOptions->screenSize=val;})
			.MinValue(0.01)
			.MaxValue(1.0)
			.MaxSliderValue(1.0)
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip4", "Screen Size: The size on-screen the object should be when flipped to this LOD (1.0=full screen)."))
		];

	// .......................................................................
	// React to Wind

	FDetailWidgetRow& lrow4=CategoryBuilder.AddCustomRow(FText::FromString(TEXT("React to Wind")));
	lrow4.NameContent()
		[
			SNew(STextBlock)
			.Text(FText::FromString(TEXT("React to Wind")))
			.Font(DetailBuilder.GetDetailFont())
		];

	TSharedPtr<SHorizontalBox> ContentBox5;
	lrow4.ValueContent()
		[
			SAssignNew(ContentBox5,SHorizontalBox)
		];

	ContentBox5->AddSlot()
		.Padding(FMargin(2.0f, 2.0f, 2.0f, 2.0f))
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked_Lambda([=]{ return  (CurrentOptions->wind && (CurrentOptions->meshType==1 || CurrentOptions->meshType==2))?ECheckBoxState::Checked:ECheckBoxState::Unchecked; })
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState){  CurrentOptions->wind=(NewState==ECheckBoxState::Checked); })
			.ToolTipText(LOCTEXT("rdLODtools_Options_ToolTip5", "React to Wind: When checked, the LOD will sway in the wind. There is only a minimal impact with this option."))
		];

	// .......................................................................
}

rdLODPlanarOptions::rdLODPlanarOptions() : bUserCancelled(true),bDuplicateMesh(false) {}

void rdLODPlanarOptions::Construct(const FArguments& InArgs) {

	WidgetWindow = InArgs._WidgetWindow;

	// Retrieve property editor module and create a SDetailsView
	FPropertyEditorModule& PropertyEditorModule=FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bAllowSearch=false;
	DetailsViewArgs.NameAreaSettings=FDetailsViewArgs::HideNameArea;
	DetailsViewArgs.bAllowMultipleTopLevelObjects=true;

	DetailsView=PropertyEditorModule.CreateDetailView(DetailsViewArgs);

	// Register instance property customization
	DetailsView->RegisterInstancedCustomPropertyLayout(UrdLODtoolsOptions::StaticClass(), 
														FOnGetDetailCustomizationInstance::CreateLambda([=]() { return FrdLODPlanarOptionsCustomization::MakeInstance(); }));

	// Set up root object customization to get desired layout
	DetailsView->SetRootObjectCustomizationInstance(MakeShareable(new FSimpleRootObjectCustomization));

	// Set provided objects on SDetailsView
	DetailsView->SetObjects(InArgs._SettingsObjects,true);

	this->ChildSlot
		[
			SNew(SVerticalBox)

			+ SVerticalBox::Slot()
		.Padding(2)
		.MaxHeight(700.0f)
		[
			DetailsView->AsShared()
		]

	+ SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Right)
		.Padding(2)
		[
			SNew(SUniformGridPanel)
			.SlotPadding(2)
		+ SUniformGridPanel::Slot(0,0)
		[
			SAssignNew(DuplicateAndConfirmButton,SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_DupCreate","Dup & Create"))
			.ToolTipText(LOCTEXT("rdLODtools_Create_ToolTip2","Duplicates the Mesh and Creates the LODs"))
			.OnClicked(this,&rdLODPlanarOptions::OnDuplicateAndConfirm)
		]
		+ SUniformGridPanel::Slot(1,0)
		[
			SAssignNew(ConfirmButton,SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_Create","Create"))
			.ToolTipText(LOCTEXT("rdLODtools_Create_ToolTip3","Creates the LODs"))
			.OnClicked(this,&rdLODPlanarOptions::OnConfirm)
		]
		+ SUniformGridPanel::Slot(2,0)
		[
			SNew(SButton)
			.HAlign(HAlign_Center)
			.Text(LOCTEXT("rdLODtools_Cancel","Cancel"))
			.ToolTipText(LOCTEXT("rdLODtools_Cancel_ToolTip4","Cancels creating any LODs"))
			.OnClicked(this,&rdLODPlanarOptions::OnCancel)
		]
	]
	];
}

//.............................................................................
// ShowPlanarSettings
//.............................................................................
bool rdLODclass::ShowPlanarSettings() {

	// Create the settings window...
	TSharedRef<SWindow> winLOD=SNew(SWindow)
										.Title(FText::FromString(TEXT("rdLODtools Planar")))
										.SizingRule(ESizingRule::UserSized)
										.AutoCenter(EAutoCenter::PreferredWorkArea)
										.ClientSize(FVector2D(426,580));

	rdLODoptions=DuplicateObject(GetMutableDefault<UrdLODtoolsOptions>(),GetTransientPackage());
	rdLODoptions->lodType=RDLOD_TYPE_PLANAR;
	rdLODoptions->mesh=mesh;
	rdLODoptions->meshEditor=meshEditor;
	rdLODoptions->numFrames=2;
	rdLODoptions->shadows=false;
	rdLODoptions->LoadFromTag("rdLOD_Planar");
	rdLODoptions->maxLODs=mesh->GetNumLODs();
	if(rdLODoptions->sourceLOD>=rdLODoptions->maxLODs) {
		rdLODoptions->sourceLOD=0;
	}

	TArray<TWeakObjectPtr<UObject>> OptionObjects{ rdLODoptions };
	TSharedPtr<rdLODPlanarOptions> Options;

	winLOD->SetContent(SAssignNew(Options,rdLODPlanarOptions)
						.WidgetWindow(winLOD)
						.SettingsObjects(OptionObjects)
					  );

	TSharedPtr<SWindow> ParentWindow;
	if(!FModuleManager::Get().IsModuleLoaded("MainFrame")) {
		return false;
	}

	// Show Settings Window
	IMainFrameModule& MainFrame=FModuleManager::LoadModuleChecked<IMainFrameModule>("MainFrame");
	FSlateApplication::Get().AddModalWindow(winLOD,MainFrame.GetParentWindow(),false);

	if(Options->WasUserCancelled()) {
		return false;
	}

	if(rdLODoptions->numFrames>=64 && rdLODoptions->res<512) rdLODoptions->res=512; //FIXED: 7th March - would crash when 64 frames and res of 256

	rdLODoptions->bDuplicateMesh=Options->DuplicateMesh();

	rdLODoptions->SaveToTag("rdLOD_Planar");

	return true;
}

//.............................................................................
