// rdLODtoolsOptions.h Copyright (c) 2019 Recourse Design ltd. All rights reserved.
#pragma once
#include "Editor/PropertyEditor/Public/IDetailRootObjectCustomization.h"
#include "Editor/PropertyEditor/Public/IDetailCustomization.h"
#include "Editor/PropertyEditor/Public/DetailCategoryBuilder.h"
#include "Editor/PropertyEditor/Public/DetailLayoutBuilder.h"
#include "Editor/PropertyEditor/Public/DetailWidgetRow.h"
#include "Runtime/Slate/Public/Widgets/Input/SSpinBox.h"
#include "Runtime/Slate/Public/Widgets/Layout/SUniformGridPanel.h"
#include "IPropertyTypeCustomization.h"
#include "Runtime/Engine/Classes/Engine/AssetUserData.h"
#include "IrdLODtools.h"
#include "rdLODtoolsOptions.generated.h"

class UStaticMesh;
class IStaticMeshEditor;

enum {
	RDLOD_TYPE_NONE=0,
	RDLOD_TYPE_BILLBOARD,
	RDLOD_TYPE_PLANAR,
	RDLOD_TYPE_END
};

enum {
	RDLOD_MESHTYPE_NONE=0,
	RDLOD_MESHTYPE_GENERAL,
	RDLOD_MESHTYPE_FOLIAGE,
	RDLOD_MESHTYPE_END
};

UCLASS(config=Editor,Blueprintable)
class UrdLODtoolsOptions : public UObject {
	GENERATED_BODY()
public:
			UrdLODtoolsOptions();

	FString	ToString();
	bool	FromString(const FString& str);

	bool	SaveToTag(const FString& tag);
	bool	LoadFromTag(const FString& tag);

	void	OnRemoveBillboardLODs(bool resetCurrLod=true);
	void	OnRemovePlanarLODs(bool resetCurrLod=true);
	void	OnRemoveLOD();
	void	OnRemoveAllLODsExcept();

	int32   lodType;
	int32	meshType;
	int32	sourceLOD;
	bool	centrePivot;
	bool	makeNormalMap;
	bool	makeOtherMaps;
	int32	maxLODs;
	int32	numFrames;
	float	startAngle;
	float	stopAngle;
	int32	res;
	float	screenSize;
	bool	wind;
	bool	shadows;
	bool	copyMasters;
	float	renderTilt;
	float	meshTilt;
	float	meshZoom;
	bool	inverseOpacity;

	int32				removeLOD;
	int32				removeExceptLOD;
	bool				bDuplicateMesh;
	UStaticMesh*		mesh;
	IStaticMeshEditor*	meshEditor;
};

class FSimpleRootObjectCustomization : public IDetailRootObjectCustomization {
public:
#if ENGINE_MINOR_VERSION<25
	virtual TSharedPtr<SWidget> CustomizeObjectHeader(const UObject* InRootObject) override;
	virtual bool IsObjectVisible(const UObject* InRootObject) const override { return true; }
	virtual bool ShouldDisplayHeader(const UObject* InRootObject) const override { return false; }
#else
	virtual TSharedPtr<SWidget> CustomizeObjectHeader(const FDetailsObjectSet& InRootObjectSet) override;
	virtual bool AreObjectsVisible(const FDetailsObjectSet& InRootObjectSet) const override { return true; }
	virtual bool ShouldDisplayHeader(const FDetailsObjectSet& InRootObjectSet) const override { return false; }
#endif	
};

FText getResComboString(int32 res);
int32 getResComboInt(const FString& str);
FText getMTypeComboString(int32 ret);
int32 getMTypeComboInt(const FString& str);
FText getSourceLODComboString(int32 ret);
int32 getSourceLODComboInt(const FString& str);

//----------------------------------------------------------------------------------------------------------------
// FPluginStyle - class for the rdLODtools Icon
//----------------------------------------------------------------------------------------------------------------
class FPluginStyle {
public:
	static void Initialize();
	static void Shutdown();
	static TSharedPtr<class ISlateStyle> Get();
	static FName GetStyleSetName();
private:
	static FString InContent(const FString& RelativePath,const ANSICHAR* Extension);
	static TSharedPtr<class FSlateStyleSet> StyleSet;
};

UCLASS()
class UrdTagAssetUserData : public UAssetUserData {
	GENERATED_BODY()
public:
	const FString&	GetName() { return name; }
	void			SetName(const FString& nm) { name=nm; }

	const FString&	GetItem(const FString& nm) { if(tags.Find(nm)==nullptr){ return blankString; } return tags[nm]; }
	void			SetItem(const FString& nm,const FString& val) { tags.Add(nm,val); }

protected:
	UPROPERTY()
	FString					name;
	FString					blankString;
	UPROPERTY()
	TMap<FString,FString>	tags;
};
