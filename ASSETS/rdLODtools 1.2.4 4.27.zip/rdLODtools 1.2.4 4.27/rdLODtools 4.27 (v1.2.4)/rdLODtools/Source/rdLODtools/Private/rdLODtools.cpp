//
// rdLODtools.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Version 1.24
//
// Creation Date: 23rd May 2019
// Last Modified: 15th March 2021
//
// version 1.24
//		* FIXED:   With Planar LODs, planes were bleeding their normals to the other side
//		* FIXED:   Planar LODs were not calculating their normals correctly
//		* FIXED:   Created LOD textures were sometimes not copying to the correct place if a material referenced Engine textures
//		* FIXED:   Crash when creating billboard with 64 frames and a 256x256 map
//		* FIXED:   Added routine to make LOD creation wait for materials to finish compiling
//		* CHANGED: Changed to new Capture system that works with almost all meshes
//		* CHANGED: Moved to WorldSpace Normals
//		* CHANGED: Removed Fake Shading
//		* CHANGED: Made some of the defaults more in-line with real usage
//		* CHANGED: Billboard LODs that are on an angle now do not rotate, act more like planar LODs
//		* CHANGED: Removed obsification from CalcFrame routine
//		* CHANGED: Frames now start at middle of their rotation to give better visuals
//		* ADDED:   A tilt option to the mesh to help with 270� lighting and low lying objects
//		* ADDED:   A Zoom option to the mesh to help with meshes that are deep
//		* ADDED:   A tilt option to the rendering to help with mesh depth and low lying objects
//		* ADDED:   Normal Strength value to Material Instances
//		
// version 1.23
//		* FIXED: Planar LODs were 90� off for their frames
//		* CHANGED: Updated for latest UE version
//
// version 1.22
//		* CHANGED: Updated for latest UE version
//
// version 1.21
//		* CHANGED: Updated for latest UE version
//
// version 1.2
//
//		* CHANGED: Moved most of the code over to separate cpp files in the Generators, UI and Helpers
//		* CHANGED: various optimizations and repairs
//		* ADDED: Start and Stop angles for Billboards
//		* ADDED: Constructor for the rdLODtools class
//
//	Materials:
//		* CHANGED: Integrated into 1 new master material that does everything
//		* CHANGED: Materials now get copied to the rdLODtools folder in your project
//		* ADDED: A new actor is also copied, it must be added to each scene to handle directional light sources
//		* ADDED: Color variation in materials
//		* ADDED: True Opacity for sub-surface rendering
//
// version 1.1
//		* Changed: 15 Jul 2019 - open window on prefered screen now rather than default
//		* Fixed: 19 Jul 2019 - creating planar at 256x256 crashing - Planar creation was using bbRes rather than plRes
//		* Added: 20 Jul 2019 - recaculating existing LOD screen sizes to fit within our new LODs sizes
//
//
// Main Source file for the rdLODtools plugin. 
// This handles:
//		* Construction/handling of the plugin
//		* Construction/handling of the toolbar button
//
//	The rendering of the mesh onto the rendertarget is in StaticMeshToRenderTarget.cpp
//	The main options class is in rdLODtoolsOptions.cpp/.h
//	The settings windows are prefixed with rdLOD_UI and one for each tool in the UI folder in the solution
//	The Actual code for each tool are in files prefixed with rdLOD_, in the Generators folder in the solution
//
#include "../Public/rdLODtools.h"

#include "Styling/SlateStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Interfaces/IPluginManager.h"

#include "rdLODtoolsOptions.h"

#define IMAGE_BRUSH(RelativePath,...) FSlateImageBrush(StyleSet->RootToContentDir(RelativePath,TEXT(".png")),__VA_ARGS__)
#define IMAGE_PLUGIN_BRUSH(RelativePath,...) FSlateImageBrush(FPluginStyle::InContent(RelativePath,".png"),__VA_ARGS__)


#define LOCTEXT_NAMESPACE "FrdLODtoolsModule"
IMPLEMENT_MODULE(FrdLODtools,rdLODtools)

//----------------------------------------------------------------------------------------------------------------
// StartupModule
//----------------------------------------------------------------------------------------------------------------
void FrdLODtools::StartupModule() {

	FPluginStyle::Initialize();

#if ENGINE_MINOR_VERSION<24
	FDelegateHandle OnOpenAssetHandle=FAssetEditorManager::Get().OnAssetOpenedInEditor().AddRaw(this, &FrdLODtools::HandleAssetOpenedInEditor);
#else
	UAssetEditorSubsystem* assEdSubsystem=GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
	if(assEdSubsystem) {
		assEdSubsystem->OnAssetOpenedInEditor().AddRaw(this, &FrdLODtools::HandleAssetOpenedInEditor);
	}
#endif

}

//----------------------------------------------------------------------------------------------------------------
// ShutdownModule
//----------------------------------------------------------------------------------------------------------------
void FrdLODtools::ShutdownModule() {

#if ENGINE_MINOR_VERSION<24
	FAssetEditorManager::Get().OnAssetOpenedInEditor().RemoveAll(this);
#else
//	UAssetEditorSubsystem* assEdSubsystem=GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
//	if(assEdSubsystem) {
//		assEdSubsystem->OnAssetOpenedInEditor().RemoveAll(this);
//	}
#endif

	FPluginStyle::Shutdown();
}

//----------------------------------------------------------------------------------------------------------------
// rdLODclass Constructor
//----------------------------------------------------------------------------------------------------------------
rdLODclass::rdLODclass() : meshEditor(NULL),mesh(NULL),meshRenderer(NULL),origMeshInd(-1),origMatInd(1) {

}

//----------------------------------------------------------------------------------------------------------------
// Populate Combo Menu 
//----------------------------------------------------------------------------------------------------------------
TSharedRef<SWidget> rdLODclass::PopulateComboMenu() {

	const bool CloseAfterSelection=true;
	FMenuBuilder MenuBuilder(CloseAfterSelection,NULL);

	MenuBuilder.BeginSection("rdLODtools",LOCTEXT("tools","tools"));

	FUIAction Action0(FExecuteAction::CreateRaw(this,&rdLODclass::DuplicateAndEdit));
	FSlateIcon Icon0=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools.DupAndEdit","StaticMeshEditor.rdLODtools.DupAndEdit");
	MenuBuilder.AddMenuEntry(
		LOCTEXT("DuplicateEdit", "Duplicate and Edit"),
		LOCTEXT("rdLODtools_Tooltip0", "Duplicate this Mesh and Edit"),
		Icon0,
		Action0,
		NAME_None,
		EUserInterfaceActionType::Button);

	FUIAction Action1(FExecuteAction::CreateRaw(this, &rdLODclass::RemoveLODs));
	FSlateIcon Icon1=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools.RemoveLODs","StaticMeshEditor.rdLODtools.RemoveLODs");

	MenuBuilder.AddMenuEntry(
		LOCTEXT("RemoveLODs", "Remove LODs..."),
		LOCTEXT("rdLODtools_Tooltip1", "Various options to remove existing LODs"),
		Icon1,
		Action1,
		NAME_None,
		EUserInterfaceActionType::Button);

	FUIAction Action2(FExecuteAction::CreateRaw(this, &rdLODclass::CreateBillboard));
	FSlateIcon Icon2=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools.CreateBillboard","StaticMeshEditor.rdLODtools.CreateBillboard");

	MenuBuilder.AddMenuEntry(
		LOCTEXT("CreateBillboard", "Create Billboard LOD..."),
		LOCTEXT("rdLODtools_Tooltip2", "Create Billboard LOD (2-4 polygons)."),
		Icon2,
		Action2,
		NAME_None,
		EUserInterfaceActionType::Button);

	FUIAction Action3(FExecuteAction::CreateRaw(this,&rdLODclass::CreatePlanar));
	FSlateIcon Icon3=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools.CreatePlanar","StaticMeshEditor.rdLODtools.CreatePlanar");

	MenuBuilder.AddMenuEntry(
		LOCTEXT("CreatePlanar", "Create Planar LOD..."),
		LOCTEXT("rdLODtools_Tooltip3", "Create Planar LOD (4-16 polygons)."),
		Icon3,
		Action3,
		NAME_None,
		EUserInterfaceActionType::Button);

	FUIAction Action4(FExecuteAction::CreateRaw(this, &rdLODclass::ShowAboutWindow));
	FSlateIcon Icon4=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools.About","StaticMeshEditor.rdLODtools.About");

	MenuBuilder.AddMenuEntry(
		LOCTEXT("ShowAbout", "About..."),
		LOCTEXT("rdLODtools_Tooltip4", "Show About Window."),
		Icon4,
		Action4,
		NAME_None,
		EUserInterfaceActionType::Button);

	MenuBuilder.EndSection();
	return MenuBuilder.MakeWidget();
}

//----------------------------------------------------------------------------------------------------------------
// AddToolbarButton
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::AddToolbarButton(FToolBarBuilder& Builder) {

	FSlateIcon IconBrush=FSlateIcon(FPluginStyle::GetStyleSetName(),"StaticMeshEditor.rdLODtools","StaticMeshEditor.rdLODtools.Small"); 

	Builder.AddComboButton(	FUIAction(),
							FOnGetContent::CreateRaw(this,&rdLODclass::PopulateComboMenu),
							LOCTEXT("rdLODtoolsButton_Override","rdLODtools"), 
							LOCTEXT("rdLODtoolsButton_ToolTipOverride","Open the rdLODtools menu"),
							IconBrush, 
							false,
							NAME_None
						);
}

//----------------------------------------------------------------------------------------------------------------
// HandleAssetOpenedInEditor
//----------------------------------------------------------------------------------------------------------------
void FrdLODtools::HandleAssetOpenedInEditor(UObject* Asset,IAssetEditorInstance *Editor) {

	auto Mesh = Cast<UStaticMesh>(Asset);
	if(Editor->GetEditorName()!="StaticMeshEditor" || !Mesh) {
		return;
	}

	rdLODClassList.Add(MakeShared<rdLODclass>());
	rdLODclass& newLODclass=rdLODClassList[rdLODClassList.Num()-1].Get();

	newLODclass.meshEditor=StaticCast<IStaticMeshEditor*>(Editor);

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Handle AssetOpenedInEditor - StaticMeshEditor..."));
#endif

	auto ToolbarExtender=MakeShared<FExtender>();
	ToolbarExtender->AddToolBarExtension("Command",EExtensionHook::After,NULL,FToolBarExtensionDelegate::CreateRaw(&newLODclass,&rdLODclass::AddToolbarButton));
	newLODclass.meshEditor->AddToolbarExtender(ToolbarExtender);
	
}

//----------------------------------------------------------------------------------------------------------------
