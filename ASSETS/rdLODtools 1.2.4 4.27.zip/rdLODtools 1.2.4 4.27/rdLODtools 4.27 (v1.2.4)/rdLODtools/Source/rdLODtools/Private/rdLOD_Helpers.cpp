//
// rdLOD_Helpers.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 17th March 2021
//
// Version 1.24
//		CHANGED: 17th Mar 2021 - Removed old material routines
//
// Version 1.2
//		FIXED: 9th Aug 2019, was failing for materials in the root folder without this
//		ADDED: Copy all materials and associated files to project
//
#include "../Public/rdLODtools.h"
#include "Runtime/Core/Public/HAL/FileManager.h"
#include "Runtime/Core/Public/HAL/PlatformFilemanager.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "FrdLODtoolsModule"

//----------------------------------------------------------------------------------------------------------------
// GetAssetPath
//----------------------------------------------------------------------------------------------------------------
FString rdLODclass::GetAssetPath(const FString& str) {

	FString ret=TEXT("");
	int32 nind=0,nind2=0;
	if(str.FindChar('/',nind)) {
		ret=str.Right(str.Len()-(nind+1));
		if(ret.FindChar('/',nind)) {
			FString ret2=ret.Right(ret.Len()-(nind+1));
			if(ret2.FindLastChar('/',nind2)) {
				ret=ret2.Left(nind2+1);
			} else {
				ret=ret.Left(nind+1); //FIXED: 9th Aug 2019, was failing for materials in the root folder without this
			}
		}
	}
	return ret;
}

//.............................................................................
// setUpFolders
//.............................................................................
void rdLODclass::setUpFolders() {

	absolutePath=FPaths::ProjectContentDir();
	materialPath=TEXT("");
	texturePath=TEXT("");

	if(mesh->StaticMaterials.Num()>0) {

		FStaticMaterial& mat0=mesh->StaticMaterials[0];
		FString fullName=mat0.MaterialInterface->GetFullName();
		materialPath=GetAssetPath(fullName);
		bool found=false;

		TArray<UTexture*> texList; // This is the list of used textures in the material (find a material that has textures)
#if ENGINE_MINOR_VERSION<25
		mat0.MaterialInterface->GetUsedTextures(texList,EMaterialQualityLevel::Medium,true,ERHIFeatureLevel::ES2,true);
#else
		mat0.MaterialInterface->GetUsedTextures(texList,EMaterialQualityLevel::Medium,true,ERHIFeatureLevel::ES3_1,true);
#endif		
		if(texList.Num()>0) {
			int i; // 2nd Mar 2021 - FIXED: was using folder path of Engine based textures
			for(i=0;i<texList.Num();i++) {
				fullName=texList[i]->GetFullName();
				if(fullName.StartsWith("Texture2D /Game/")) {
					texturePath=GetAssetPath(texList[i]->GetFullName());
					found=true;
					break;
				}
			}
		}
		
		if(!found) {

			for(auto mat:mesh->StaticMaterials) {
				if(mat.MaterialInterface==NULL) continue; // FIXED: 2nd Mar 2021 - Unhandled Exception if MaterialInterface was null (a deleted texture referenced by a material)
#if ENGINE_MINOR_VERSION<25
				mat.MaterialInterface->GetUsedTextures(texList,EMaterialQualityLevel::Medium,true,ERHIFeatureLevel::ES2,true);
#else
				mat.MaterialInterface->GetUsedTextures(texList,EMaterialQualityLevel::Medium,true,ERHIFeatureLevel::ES3_1,true);
#endif		
				if(texList.Num()>0) {
					int i; // 2nd Mar 2021 - FIXED: was using folder path of Engine based textures
					for(i=0;i<texList.Num();i++) {
						fullName=texList[i]->GetFullName();
						if(fullName.StartsWith("Texture2D /Game/")) {
							texturePath=GetAssetPath(texList[i]->GetFullName());
							found=true;
							break;
						}
					}
				}
			}
		}

		if(!found) { // store the textures in the same folder as the material
			texturePath=materialPath;
		}

	} else { // use the same folder as the mesh resides in if it has no materials

		FString path=mesh->GetPathName();
		int32 ind=0;
		bool b=path.FindLastChar(L'/',ind);
		materialPath=path.Left(ind+1);
		texturePath=materialPath;
	}
}

//----------------------------------------------------------------------------------------------------------------
// makeDir
//----------------------------------------------------------------------------------------------------------------
void makeDir(const FString& dir,IPlatformFile& pf) {

	if(!pf.DirectoryExists(*dir)) {

		pf.CreateDirectory(*dir);
	}
}

//----------------------------------------------------------------------------------------------------------------
// copyFile
//----------------------------------------------------------------------------------------------------------------
void copyFile(const FString& src,const FString& dst,IPlatformFile& pf) {

	if(!pf.FileExists(*dst)) {

		pf.CopyFile(*dst,*src);
	}
}

//----------------------------------------------------------------------------------------------------------------
// CopyPluginFiles
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::CopyPluginFiles() {

	FString path=FPaths::ProjectContentDir(),pluginpath=IPluginManager::Get().FindPlugin(TEXT("rdLODtools"))->GetContentDir();
	IPlatformFile& pf=FPlatformFileManager::Get().GetPlatformFile();
	makeDir(*(path/TEXT("rdLODtools/")),pf);
	makeDir(*(path/TEXT("rdLODtools/Materials/")),pf);
	makeDir(*(path/TEXT("rdLODtools/MaterialFunctions/")),pf);
	makeDir(*(path/TEXT("rdLODtools/Textures/")),pf);

	copyFile(*(pluginpath/TEXT("BaseMaterials/M_rdLODMaster2.uasset")),*(path/TEXT("rdLODtools/Materials/M_rdLODMaster2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_CalcAngleOffsetPos2.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_CalcAngleOffsetPos2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_CalcBillboardAngle2.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_CalcBillboardAngle2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_CalculateFrameFromAngle2.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_CalculateFrameFromAngle2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_CalcWind.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_CalcWind.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_DiffuseAdjust2.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_DiffuseAdjust2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_RotateNormal2.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_RotateNormal2.uasset")),pf);
	copyFile(*(pluginpath/TEXT("MaterialFunctions/MF_Ramp.uasset")),*(path/TEXT("rdLODtools/MaterialFunctions/MF_Ramp.uasset")),pf);
	copyFile(*(pluginpath/TEXT("Textures/LinearColor.uasset")),*(path/TEXT("rdLODtools/Textures/LinearColor.uasset")),pf);
	copyFile(*(pluginpath/TEXT("Textures/DefaultPBR.uasset")),*(path/TEXT("rdLODtools/Textures/DefaultPBR.uasset")),pf);
}

//----------------------------------------------------------------------------------------------------------------
// OpenAssetEditor
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::OpenAssetEditor(const TArray<UObject*>& assets) {

#if ENGINE_MINOR_VERSION<24
	FAssetEditorManager::Get().OpenEditorForAssets(assets);
#else
	UAssetEditorSubsystem* assEdSubsystem=GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
	if(assEdSubsystem) {
		assEdSubsystem->OpenEditorForAssets(assets);
	}
#endif
}

//----------------------------------------------------------------------------------------------------------------
