//
// rdLOD_DuplicateAndEdit.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd July 2019
// Last Modified: 23rd July 2019
//
#include "../Public/rdLODtools.h"

#include "Editor/StaticMeshEditor/Public/IStaticMeshEditor.h"

//----------------------------------------------------------------------------------------------------------------
// DuplicateAndEdit
//----------------------------------------------------------------------------------------------------------------
void rdLODclass::DuplicateAndEdit() {

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Duplicate and Edit..."));
#endif

	// Duplicate the Mesh and open it in the StaticMeshEditor
	mesh=meshEditor->GetStaticMesh(); // Retrieves the current static mesh displayed in the Static Mesh Editor.

	TArray<UObject*> srcLst;
	srcLst.Add(mesh);
	TArray<UObject*> dstLst;
	ObjectTools::DuplicateObjects(srcLst,TEXT(""),TEXT(""),false,&dstLst);

	if(dstLst.Num()<1) {
		UE_LOG(LogTemp, Error, TEXT("rdLODtools duplicate mesh failed"));
		return;
	}

	mesh=(UStaticMesh*)dstLst[0];
	TArray<UObject*> assets;
	assets.Add(mesh);
	OpenAssetEditor(assets);

}

//----------------------------------------------------------------------------------------------------------------
