//
// StaticMeshToRenderTarget.cpp
//
// Copyright (c) 2019 Recourse Design ltd. All rights reserved.
//
// Creation Date: 23rd May 2019
// Last Modified: 17th March 2021
//
// version 1.24
//		CHANGED: 27th Feb 2021 - Removed the curved normal map code as World Space normals are now used
//		CHANGED: 27th Feb 2021 - Some compilers pre-increment '++sy' in a for loop so changed them to 'sy++'
//		CHANGED: 16th Mar 2021 - Changed over to using the visualize viewmodes for grabbing BaseColor, Normal etc
//		ADDED:   29th Feb 2021 - Added a tilt amount to the projection for frame rendering
//
// version 1.2
//		FIXED: SkyLight was not working for BakedLighting
//		FIXED: There was Clipping when the mesh was not centered
//		CHANGED: Now the viewport is only created and destroyed once per LOD creation
//		FIXED: Sped up rendering and fixed memory leak
//		FIXED: Meshes were not being placed correctly on the ground
//		CHANGED: Opacity now rendered as per-pixel
//		CHANGED: Normals now have a curved shape added to the Normal
//
// version 1.1
//		ADDED: option for baked lighting
//		CHANGED: pass in rdLODOptions instead of multiple parameters
//		ADDED: Gamma setting
//
//
// version 1.01
//		CHANGED: 15th July 2019 - added normal loop to avoid the compare
//		FIXED: 20th July 2019 - didn't need to flip green channel
//
#include "StaticMeshToRenderTarget.h"
#include "../Public/IrdLODtools.h"
#include "Runtime/Engine/Public/CanvasTypes.h"
#include "Runtime/Engine/Classes/Engine/TextureRenderTarget2D.h"
#include "Runtime/Engine/Classes/Materials/MaterialInstanceConstant.h"
#include "Runtime/Engine/Classes/Components/DirectionalLightComponent.h"
#include "Runtime/Engine/Classes/Components/SkyLightComponent.h"
#include "Runtime/Engine/Public/BufferVisualizationData.h"
#include "Editor/UnrealEd/Public/EditorViewportClient.h"
#include "Runtime/Engine/Classes/Kismet/KismetRenderingLibrary.h"
#include "Editor/UnrealEd/Public/EditorModes.h"

#ifdef _INCLUDE_DEBUGGING_STUFF
#include "Runtime/Core/Public/Misc/FileHelper.h"
#endif

//----------------------------------------------------------------------------------------------------------------
// SetUpVisualization
//----------------------------------------------------------------------------------------------------------------
void MeshRenderViewportClient::SetUpVisualization(FViewport* vp,FCanvas* cvs,const FName& shader) {

	const FIntPoint ViewportSizeXY=vp->GetSizeXY();
	FRotator rot=FRotator(tilt,45.0,0.0);

	viewRotationMatrix=FInverseRotationMatrix(rot)*FMatrix(  // 45� gives the WorldSpace Red and Green even dispursal making less instructions needed in runtime
															FPlane(0, 0, 1, 0), // to get the Z rotation of the normal, if the channel floats are between 0.0 and 1.0 it's quick to 
															FPlane(1, 0, 0, 0), // just do (-R+G)*0.25 to get an approximation on the angle they represent. To make it more accurate
															FPlane(0, 1, 0, 0), // it would require an arcsine on the values to get the correct angles but at a distance you just 
															FPlane(0, 0, 0, 1)  // don't notice
														   );
							//TODO: bool IsPerspectiveProjection() const { return ProjectionMatrix.M[3][3] < 1.0f; }

	projectionMatrix=FReversedZOrthoMatrix(	(100.0f/ViewportSizeXY.X)*ViewportSizeXY.X,
											(100.0f/ViewportSizeXY.X)*ViewportSizeXY.Y,
											((shader==TEXT("AmbientOcclusion"))?1.0f:0.5f)/HALF_WORLD_MAX, // add a bit of depth to the AO projection
											HALF_WORLD_MAX
										  );

	if(shader==TEXT("BaseColor")) {
		CurrentBufferVisualizationMode=NAME_None;
		SetViewMode(EViewModeIndex::VMI_Unlit); // the VMI_Unlit also renders the separate translucencies and emmissive where the BaseColor visualisation doesn't
	} else {
		CurrentBufferVisualizationMode=shader;
		SetViewMode(EViewModeIndex::VMI_VisualizeBuffer);
	}
};

//----------------------------------------------------------------------------------------------------------------
// CalcSceneView
//	Stripped down version of the FEditorViewportClient CalcSceneVeiw method, just uses the transforms we already have
//----------------------------------------------------------------------------------------------------------------
FSceneView* MeshRenderViewportClient::CalcSceneView(FSceneViewFamily* ViewFamily,const EStereoscopicPass StereoPass) {

	FSceneViewInitOptions ViewInitOptions;

	ViewInitOptions.ViewOrigin=FVector(0,0,0);

	const FIntPoint ViewportSizeXY=Viewport->GetSizeXY();
	FIntRect ViewRect=FIntRect(0,0,ViewportSizeXY.X,ViewportSizeXY.Y);

	ViewInitOptions.SetViewRectangle(ViewRect);
	ViewInitOptions.ViewRotationMatrix=viewRotationMatrix;
	ViewInitOptions.ProjectionMatrix=projectionMatrix;
	ViewInitOptions.ViewFamily=ViewFamily;
	ViewInitOptions.BackgroundColor=FLinearColor(0,0,0,0);
	ViewInitOptions.OverrideLODViewOrigin=FVector::ZeroVector;
	ViewInitOptions.bUseFauxOrthoViewPos=true;

	FSceneView* View=new FSceneView(ViewInitOptions);
	View->SubduedSelectionOutlineColor=GEngine->GetSubduedSelectionOutlineColor();
	ViewFamily->Views.Add(View);
	View->StartFinalPostprocessSettings(View->ViewLocation);
	OverridePostProcessSettings(*View);
	View->EndFinalPostprocessSettings(ViewInitOptions);

	return View;
}

//----------------------------------------------------------------------------------------------------------------
// Draw
//	Viewport Render override - renders the viewport onto the passed in Canvas (stripped down version from FEditorViewportClient)
//----------------------------------------------------------------------------------------------------------------
void MeshRenderViewportClient::Draw(FViewport* InViewport,FCanvas* Canvas) {

	Viewport=InViewport;

	Canvas->SetScaledToRenderTarget(false);
	Canvas->SetStereoRendering(false);

	// Setup a FSceneViewFamily/FSceneView for the viewport.
	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(Canvas->GetRenderTarget(),GetScene(),EngineShowFlags));
	ViewFamily.EngineShowFlags=EngineShowFlags;
#if ENGINE_MINOR_VERSION>23
	ViewFamily.bIsHDR=Viewport->IsHDRViewport();
#endif
	ViewFamily.EngineShowFlags.CameraInterpolation=0;
	ViewFamily.EngineShowFlags.SetScreenPercentage(false);

	EViewModeIndex CurrentViewMode=GetViewMode();
	ViewFamily.ViewMode=CurrentViewMode;
	EngineShowFlagOverride(ESFIM_Editor,ViewFamily.ViewMode,ViewFamily.EngineShowFlags,true);

	if(ViewFamily.GetScreenPercentageInterface()==nullptr) {
		ViewFamily.EngineShowFlags.SetScreenPercentage(false);
		ViewFamily.SetScreenPercentageInterface(new FLegacyScreenPercentageDriver(ViewFamily,1.0,false));
	}

	FSceneView* View=CalcSceneView(&ViewFamily,eSSP_FULL);
	SetupViewForRendering(ViewFamily,*View);

	// Draw the 3D scene
	GetRendererModule().BeginRenderingViewFamily(Canvas,&ViewFamily);

	Viewport=nullptr;
}

//----------------------------------------------------------------------------------------------------------------
// SetSize
//----------------------------------------------------------------------------------------------------------------
void FOffScreenViewport::SetSize(int32 tw,int32 th) {

	SizeX=tw;
	SizeY=th;
}

//----------------------------------------------------------------------------------------------------------------
// RenderMesh
//	Viewport method which creates rendertarget and renders mesh with the viewport override
//----------------------------------------------------------------------------------------------------------------
void FOffScreenViewport::RenderMesh(UStaticMesh* mesh,UTexture2D* tex,int32 tx,int32 ty,const FRotator& rot,UrdLODtoolsOptions* rdLODoptions,bool linearCol) {

	BeginInitResource(this);
	EnqueueBeginRenderFrame(false);

	FTextureRenderTarget2DResource* rtrgtResource=(FTextureRenderTarget2DResource*)rtrgt->Resource;
	int32 tw=SizeX,th=SizeY;
	FReadSurfaceDataFlags readFlags(RCM_UNorm); // between 0 and 1

	TArray<FColor> data;
	FColor* dataMask=NULL;

	((MeshRenderViewportClient*)ViewportClient)->tilt=rdLODoptions->renderTilt;
	ViewportClient->Draw(this,Canvas);
	Canvas->Flush_GameThread();
	FlushRenderingCommands();

	rtrgtResource->ReadPixels(data,readFlags);

#ifdef _INCLUDE_DEBUGGING_STUFF
//	FFileHelper::CreateBitmap(*(FPaths::ScreenShotDir()/"RenderTargetSnap"),tw,th,(FColor*)&data[0]);//@@
#endif

	if(tex->Source.IsValid()) {

		// Copy over the pixel data
		FColor* TextureData=(FColor*)tex->Source.LockMip(0);
		int32 texW=tex->Source.GetSizeX();
		int32 srcY=0,dstY=(ty*texW);

		for(int32 sy=0;sy<th;sy++) {
			for(int32 sx=0;sx<tw;sx++) {

				TextureData[dstY+tx+sx]=data[srcY+sx];
			}
			srcY+=tw;
			dstY+=texW;
		}
	}
	tex->Source.UnlockMip(0);

	ENQUEUE_RENDER_COMMAND(EndDrawingCommand)([=](FRHICommandListImmediate& RHICmdList){EndRenderFrame(RHICmdList,false,false);});

	BeginReleaseResource(this);
	FlushRenderingCommands();
};

//----------------------------------------------------------------------------------------------------------------
// CreateView
//----------------------------------------------------------------------------------------------------------------
void MeshRenderHelper::CreateView(int32 tw,int32 th,float tilt,const FName& shader,bool linearCol) {

	editorViewportClient=new MeshRenderViewportClient();
	OffScreenRenderViewport=new FOffScreenViewport(editorViewportClient);

	OffScreenRenderViewport->rtrgt=UKismetRenderingLibrary::CreateRenderTarget2D(editorViewportClient->GetWorld(),tw,th,RTF_RGBA8);

	OffScreenRenderViewport->rtrgt->bNeedsTwoCopies=false;
	OffScreenRenderViewport->rtrgt->ClearColor=FLinearColor(0.0,0.0,0.0,0.0);
	OffScreenRenderViewport->rtrgt->InitAutoFormat(tw,th);
	OffScreenRenderViewport->rtrgt->RenderTargetFormat=ETextureRenderTargetFormat::RTF_RGBA8;
	OffScreenRenderViewport->rtrgt->SRGB=linearCol?false:true;
	OffScreenRenderViewport->rtrgt->bGPUSharedFlag=true;
	OffScreenRenderViewport->rtrgt->UpdateResourceImmediate();
	OffScreenRenderViewport->SetSize(tw,th);

	FTextureRenderTarget2DResource* rtrgtResource=(FTextureRenderTarget2DResource*)OffScreenRenderViewport->rtrgt->Resource;
	FCanvas* Canvas=new FCanvas(rtrgtResource,NULL,0,0,0,editorViewportClient->GetWorld()->FeatureLevel);
	OffScreenRenderViewport->Canvas=Canvas;

	editorViewportClient->tilt=tilt;
	editorViewportClient->SetUpVisualization(OffScreenRenderViewport,Canvas,shader);
}

//----------------------------------------------------------------------------------------------------------------
// DestroyView
//----------------------------------------------------------------------------------------------------------------
void MeshRenderHelper::DestroyView() {

	if(OffScreenRenderViewport) {

		if(OffScreenRenderViewport->Canvas) {
			delete OffScreenRenderViewport->Canvas;
		}

		if(OffScreenRenderViewport->rtrgt) {
			UKismetRenderingLibrary::ReleaseRenderTarget2D(OffScreenRenderViewport->rtrgt);
		}

		delete OffScreenRenderViewport;
		OffScreenRenderViewport=0;
	}

	if(editorViewportClient) {
		delete editorViewportClient;
		editorViewportClient=0;
	}
}

#if ENGINE_MINOR_VERSION<22
FDummyViewport::~FDummyViewport() {

	if(DebugCanvas != NULL) {
		delete DebugCanvas;
		DebugCanvas = NULL;
	}
}

// UE4.22 has a public GetPreviewScene() in the FEditorViewportClient, so this is just for 4.21 and prior
class rdViewportClient : FEditorViewportClient {
public:
	FPreviewScene* GetPreviewScene() { return PreviewScene; }
};
#endif

//----------------------------------------------------------------------------------------------------------------
// RenderMesh
//    Helper to prepare viewport ready for rendering the mesh
//----------------------------------------------------------------------------------------------------------------
void MeshRenderHelper::RenderMesh(UTexture2D* tex,UStaticMesh* mesh,const FRotator& rot,int32 tx,int32 ty,UrdLODtoolsOptions* rdLODoptions,bool linearCol) {

	UStaticMeshComponent* NewSMComponent=NewObject<UStaticMeshComponent>(GetTransientPackage(),NAME_None,RF_Transient);
	NewSMComponent->SetStaticMesh(mesh);
	NewSMComponent->SetForcedLodModel(rdLODoptions->sourceLOD+1);
	NewSMComponent->OverrideMaterials.Empty();

	FBoxSphereBounds bx=mesh->GetBoundingBox();
	FVector meshCenter=bx.GetSphere().Center; 

	float scaleX=100.0/(bx.BoxExtent.X+fabs(meshCenter.X)); //FIXED: when the mesh isn't centered we need to make our plane bigger and the scale smaller to account
	float scaleY=100.0/(bx.BoxExtent.Y+fabs(meshCenter.Y));
	float scaleZ=100.0/bx.BoxExtent.Z;

	// Keep the aspect ratio correct, we don't want to just fill the whole dimensions
	if(scaleX>scaleY) scaleX=scaleY;
	else scaleY=scaleX;

	float xpos=(meshCenter.X/bx.BoxExtent.X)*scaleX;
	float ypos=(meshCenter.Y/bx.BoxExtent.Y)*scaleY;
	float zpos=-100.0+(bx.BoxExtent.Z-meshCenter.Z)*scaleZ; //FIXED: meshes were not being placed correctly on the ground

#ifdef _INCLUDE_DEBUGGING_STUFF
	UE_LOG(LogTemp, Display, TEXT("Viewport Scale and Pos: %f,%f,%f - %fx%fx%f"),xpos,ypos,zpos,scaleX,scaleY,scaleZ);
#endif
	
	FTransform Transform(rot,FVector(xpos,ypos,zpos),FVector(scaleX,scaleY,scaleZ)); //CHANGED: just optimized the code a little
	editorViewportClient->PreviewScene.AddComponent(NewSMComponent,Transform);

	OffScreenRenderViewport->RenderMesh(mesh,tex,tx,ty,rot,rdLODoptions,linearCol);

	editorViewportClient->PreviewScene.RemoveComponent(NewSMComponent);
	
#if ENGINE_MINOR_VERSION<23
	delete NewSMComponent;
	NewSMComponent=0;
#endif
};

//----------------------------------------------------------------------------------------------------------------
