// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

namespace UnrealBuildTool.Rules
{
	public class rdLODtools : ModuleRules
	{
		public rdLODtools(ReadOnlyTargetRules Target) : base(Target) {

			PrivatePCHHeaderFile = "Public/rdLODtools.h";

			PublicIncludePaths.AddRange(
				new string[] {
					// ... add public include paths required here ...
				}
				);

			PrivateIncludePaths.AddRange(
				new string[] {
					// ... add other private include paths required here ...
				}
				);

			PublicDependencyModuleNames.AddRange(
				new string[]
				{
					"Core",
					"CoreUObject",
					"PropertyEditor",
					"Engine",
					"Slate",
					"UnrealEd",
					"EditorStyle",
					"StaticMeshEditor",
					"Renderer",
					"AssetTools",
					"RenderCore"
				}
				);

			PrivateDependencyModuleNames.AddRange(
				new string[]
				{
					"InputCore",
					"SlateCore",
					"PropertyEditor",
					"LevelEditor",
					"StaticMeshEditor",
					"Engine",
					"Renderer",
					"RawMesh",
					"RenderCore",
					"MainFrame",
                    "MeshDescription",
					"EditorSubsystem",
					"RHI",
					"Projects"
				}
				);

			DynamicallyLoadedModuleNames.AddRange(
				new string[]
				{
					// ... add any modules that your module loads dynamically here ...
				}
				);
		}
	}
}
