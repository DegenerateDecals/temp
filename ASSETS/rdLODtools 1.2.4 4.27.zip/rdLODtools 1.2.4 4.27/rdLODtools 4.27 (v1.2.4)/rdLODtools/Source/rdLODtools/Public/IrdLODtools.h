// IrdLODtools.h - Copyright (c) 2019 Recourse Design ltd.
#pragma once

#define _INCLUDE_DEBUGGING_STUFF

#include "CoreMinimal.h"
#include "Modules/ModuleInterface.h"
#include "Modules/ModuleManager.h"
#include "Runtime/Launch/Resources/Version.h"

class IrdLODtools : public IModuleInterface {
public:

	static inline IrdLODtools& Get() {
		return FModuleManager::LoadModuleChecked<IrdLODtools>("rdLODtools");
	}

	static inline bool IsAvailable() {
		return FModuleManager::Get().IsModuleLoaded("rdLODtools");
	}
};

#if ENGINE_MINOR_VERSION<23
#define GetMeshSourceModels() mesh->SourceModels
#define GetMeshSourceModel(x) mesh->SourceModels[x]
#define GetMeshSectionInfoMap() mesh->SectionInfoMap
#define GetMeshOriginalSectionInfoMap() mesh->OriginalSectionInfoMap
#else
#define GetMeshSourceModels() mesh->GetSourceModels()
#define GetMeshSourceModel(x) mesh->GetSourceModel(x)
#define GetMeshSectionInfoMap() mesh->GetSectionInfoMap()
#define GetMeshOriginalSectionInfoMap() mesh->GetOriginalSectionInfoMap()
#endif
