// rdLODtools.h Copyright (c) 2019 Recourse Design ltd. All rights reserved.
#pragma once
#include "../Public/IrdLODtools.h"
#include "Runtime/Core/Public/Containers/UnrealString.h"
#if ENGINE_MINOR_VERSION<25
#include "Developer/RawMesh/Public/RawMesh.h"
#else
#include "Runtime/RawMesh/Public/RawMesh.h"
#endif
#include "Runtime/Slate/Public/Framework/MultiBox/MultiBoxBuilder.h"
#include "Editor/UnrealEd/Public/Toolkits/AssetEditorManager.h"
#include "Runtime/Engine/Classes/Engine/StaticMesh.h"

class UMaterialInstanceConstant;
class IStaticMeshEditor;
class UTexture;
class UTexture2D;
class UrdLODtoolsOptions;
class MeshRenderHelper;
class rdLODclass;

class FrdLODtools : public IrdLODtools {
public:

	// IModuleInterface implementation 
	virtual void	StartupModule() override;
	virtual void	ShutdownModule() override;

	void			HandleAssetOpenedInEditor(UObject* Asset,IAssetEditorInstance* Editor);
private:
	TArray<TSharedRef<rdLODclass>> rdLODClassList;
};

class rdLODclass {
public:
								rdLODclass();
	void						AddToolbarButton(FToolBarBuilder& Builder);
	TSharedRef<SWidget>			PopulateComboMenu();

	void						setUpFolders();
	void						CopyPluginFiles();

	void						OpenAssetEditor(const TArray<UObject*>& assets);

	void						DuplicateAndEdit();
	bool						ShowCleanSettings();
	void						RemoveLODs();
	bool						ShowBillboardSettings();
	void						CreateBillboard();
	bool						ShowPlanarSettings();
	void						CreatePlanar();
	bool						ShowAboutSettings();
	void						ShowAboutWindow();


	UPackage*					MakeTexture(UTexture2D** tex,const char suffix,const FName& shader,bool linearCol=true,bool tempTex=false,bool finalize=true);
	void						FinalizePackage(UTexture2D* tex,UPackage* package,char suffix);
	void						RenderAngles(UTexture2D* tex,int32 numFrames,bool linearCol=true);
	void						CreatePlanarLOD();
	void						CreateBillboardLOD();

	void						CreateMesh(FRawMesh& rawMesh,float angle,float xoffset,float yoffset,float zoffset,float tilt,float zoom,const FVector2D& uv1,const FVector2D& uv2);
	void						CreatePlanarMesh(FRawMesh& rawMesh,UMaterialInstanceConstant* mi);
	void						CreateBillboardMesh(FRawMesh& rawMesh,UMaterialInstanceConstant* mi);
	FString						GetAssetPath(const FString& str);
	UMaterialInstanceConstant*	CreateMaterialInstance(const FString& MaterialBaseName,const FString& masterMat,UTexture* texD,UTexture* texN,UTexture* texPBR,int32 numFrames,int32 miType,float windStrength,UPackage** pckgPtr);
	void						CentreMeshPivot();
	UTexture2D*					createTexture(UPackage* Package,const FString& fileName,int32 res,uint32 clearCol,bool linearCol=true);
	void						finaliseTexture(UTexture2D* tex,UPackage* Package,const FString& fileName);

	IStaticMeshEditor*			meshEditor;
	UStaticMesh*				mesh;
private:
	FString						MeshName;
	MeshRenderHelper*			meshRenderer;
	FString						absolutePath,materialPath,texturePath;
	UrdLODtoolsOptions*			rdLODoptions;
	int32						origMeshInd,origMatInd;
};
