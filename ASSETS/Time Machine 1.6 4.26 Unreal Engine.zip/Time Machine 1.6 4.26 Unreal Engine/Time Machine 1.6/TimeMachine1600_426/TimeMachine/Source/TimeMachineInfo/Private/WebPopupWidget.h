﻿#pragma once

DECLARE_DELEGATE_RetVal(TSharedPtr<SWidget>, BuildWebPopupWidget)

class WebPopupWidget : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(WebPopupWidget):
        _PartentWindow(),
        _StartingUrl(),
        _HeaderDel(),
        _FooterDel()
    {}
        SLATE_ARGUMENT(TSharedPtr<SWindow>, PartentWindow)
        SLATE_ARGUMENT(FString, StartingUrl)
        SLATE_ARGUMENT(BuildWebPopupWidget, HeaderDel)
        SLATE_ARGUMENT(BuildWebPopupWidget, FooterDel)
    SLATE_END_ARGS()

    static void Display(
        FString StartingUrl,
        FText Title = FText(),
        BuildWebPopupWidget FooterWidgetDel = nullptr,
        BuildWebPopupWidget HeaderWidgetDel = nullptr,
        float MinHeight = 350.0f
    );

    void Construct(const FArguments& InArgs);
    
private:
    FReply OnOkClicked() const;
    
// Members
    TSharedPtr<SWindow> ParentWindow;
    BuildWebPopupWidget HeaderDel;
    BuildWebPopupWidget FooterDel;
    
};
