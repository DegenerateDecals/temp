﻿#include "TimeMachineMenu.h"


#include "TimeMachine/Private/Consts.h"
#include "LevelEditor.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

FTimeMachineMenu::FTimeMachineMenu():
	FTimeMachineMenu(FReleaseNotesManager::Get())
{
}

FTimeMachineMenu::FTimeMachineMenu(TSharedPtr<FReleaseNotesManager> ReleaseNotesManager):
	FTimeMachineMenu(
		ReleaseNotesManager,
		IPluginManager::Get().FindPlugin(PLUGIN_NAME)
	)
{
}

FTimeMachineMenu::FTimeMachineMenu(
	TSharedPtr<FReleaseNotesManager> ReleaseNotesManager,
	const TSharedPtr<IPlugin> TimeMachinePlugin
)
:ReleaseNotesManager(ReleaseNotesManager)
{
	const FPluginDescriptor& TimeMachineDescriptor = TimeMachinePlugin->GetDescriptor();
	
	PluginVersion = TimeMachineDescriptor.VersionName;
	Url = TimeMachineDescriptor.CreatedByURL;
}

void FTimeMachineMenu::BuildMenu(FMenuBuilder& MenuBuilder)
{
	MenuBuilder.BeginSection("Information", LOCTEXT("TimeMachineMenu_InfoSection", "Information"));

	MenuBuilder.AddMenuEntry(
			LOCTEXT("TimeMachineMenu_LaunchWebsite", "Website..."),
			LOCTEXT("TimeMachineMenu_LaunchWebsiteToolTip", "Launch Time Machine Website"),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(this, &FTimeMachineMenu::HandleLaunchWebsite))
		);

	MenuBuilder.EndSection();
	
	MenuBuilder.BeginSection("Support", LOCTEXT("TimeMachineMenu_InfoSection", "Information"));
	
	MenuBuilder.AddMenuEntry(
			LOCTEXT("TimeMachineMenu_ContactSupport", "Contact Support..."),
			LOCTEXT("TimeMachineMenu_ContactSupportToolTip", "Email to Time Machine support "),
			FSlateIcon(),
			FUIAction(FExecuteAction::CreateStatic(&FTimeMachineMenu::HandleContactSupport))
		);

	MenuBuilder.EndSection();

	MenuBuilder.BeginSection("About", LOCTEXT("TimeMachineMenu_AboutSection", "About"));
		
	const auto VersionTextBlock = SNew(STextBlock)
		.Text(FText::Format(LOCTEXT("TimeMachineMenu_Verson", "Version: {0}"), FText::FromString(PluginVersion)))
		.ColorAndOpacity(FSlateColor(FLinearColor(1.0f, 1.0f, 1.0f, 0.5f)));

	MenuBuilder.AddWidget(VersionTextBlock, FText());
		
	MenuBuilder.AddMenuEntry(
			LOCTEXT("TimeMachineMenu_ReleaseNotes", "Release Notes"),
			LOCTEXT("TimeMachineMenu_OpenReleaseNotesToolTop", "Open Release Notes"),
			 FSlateIcon(),
			FUIAction(FExecuteAction::CreateRaw(this, &FTimeMachineMenu::HandleReleaseNotesOpen))
		);

#if IS_PRO == false
	MenuBuilder.AddMenuSeparator();
	MenuBuilder.AddMenuEntry(
			LOCTEXT("TimeMachineMenu_GetPro", "Get Time Machine Pro!"),
			LOCTEXT("TimeMachineMenu_GetProToolTop", "Get Time Machine Pro in the Unreal Marketplace"),
			 FSlateIcon(),
			FUIAction(FExecuteAction::CreateStatic(&FTimeMachineMenu::HandleGetPro))
		);
#endif

	MenuBuilder.EndSection();
}

void FTimeMachineMenu::HandleGetPro()
{
	FPlatformProcess::LaunchURL(TEXT(PRO_URL), nullptr, nullptr);
}


void FTimeMachineMenu::BindMenu()
{
    FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	
	TSharedPtr<FExtender> MenuExtender = MakeShared<FExtender>();

	MenuExtender->AddMenuBarExtension(
		"Help",
		EExtensionHook::Before,
		nullptr,
		FMenuBarExtensionDelegate::CreateLambda([this](FMenuBarBuilder& MenuBuilder)
		{
			MenuBuilder.AddPullDownMenu(
				LOCTEXT("TimeMachineMenu", "Time Machine"),
                LOCTEXT("TimeMachineMenu_ToolTip", "Open the Time Machine Menu"),
                FNewMenuDelegate::CreateRaw(this, &FTimeMachineMenu::BuildMenu)
			);
		})
	);

	LevelEditorModule.GetMenuExtensibilityManager()->AddExtender(MenuExtender);
}

void FTimeMachineMenu::HandleContactSupport()
{
	FPlatformProcess::LaunchURL( TEXT("mailto://support@uetimemachine.com"), nullptr, nullptr );
}

void FTimeMachineMenu::HandleReleaseNotesOpen() const
{
	ReleaseNotesManager->Display();
}

void FTimeMachineMenu::HandleLaunchWebsite() const
{
	FPlatformProcess::LaunchURL( *Url, nullptr, nullptr);
}


#undef LOCTEXT_NAMESPACE

