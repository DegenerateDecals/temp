﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once
#include "Engine/DeveloperSettings.h"
#include "TimeMachineNotesSettings.generated.h"

UCLASS(config=TimeMachineNotes)
class UTimeMachineNotesSettings : public UDeveloperSettings
{
private:
    GENERATED_UCLASS_BODY()

public:
    UPROPERTY(config=TimeMachine)
    FString LastReleaseNotesDisplayed;

    UPROPERTY(config=TimeMachine)
    bool bFirstLoad;
};
