﻿#pragma once

#include "Runtime/Online/HTTP/Public/Http.h"

class FMarketplaceChecker
{
public:
    explicit FMarketplaceChecker(const FString& CurrentVersion);
    
    void Check();
    
private:

    typedef TMemFunPtrType<true, FMarketplaceChecker, void (FHttpRequestPtr Request, FHttpResponsePtr Response, bool bSuccessful)>::Type MarketplaceCallback;
    
    void CallMarketplace(FString ProductId, MarketplaceCallback Callback);
    
    void HandleProResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bSuccessful) const;

    void HandleProductResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bSuccessful) const;

    bool ParseDataFromRequest(FHttpResponsePtr Response, TSharedPtr<FJsonObject>& ParsedDataOut) const;
    
    static inline void PushNotification(FText Text, FText HyperLinkText, const TCHAR* LinkUrl);
    
    static int ConvertVersionString(const FString& Version);
    
// Members
    int CurrentVersionAsNum;
};
