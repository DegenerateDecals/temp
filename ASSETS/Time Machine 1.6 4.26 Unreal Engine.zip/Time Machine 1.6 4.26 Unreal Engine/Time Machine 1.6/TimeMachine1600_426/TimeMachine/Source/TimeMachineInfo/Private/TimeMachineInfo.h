﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "IPluginManager.h"
#include "MarketplaceChecker.h"
#include "ModuleInterface.h"
#include "TimeMachineMenu.h"
#include "ReleaseNotesManager.h"

class FTimeMachineInfo : public IModuleInterface
{
public:
    FTimeMachineInfo();
    	
   	FTimeMachineInfo(
		FMarketplaceChecker MarketplaceChecker,
		const TSharedPtr<FReleaseNotesManager> ReleaseNotesManager
	);
    
    /** IModuleInterface implementation */
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
    
private:
	void OnMainFrameCreationFinished(TSharedPtr<SWindow> InRootWindow, bool bIsNewProjectWindow);

	TSharedPtr<IPlugin> TimeMachinePlugin;
	FMarketplaceChecker MarketplaceChecker;
    TSharedPtr<FReleaseNotesManager> ReleaseNotesManager;
	FTimeMachineMenu Menu;
};
