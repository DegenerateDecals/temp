﻿#include "MarketplaceChecker.h"

#include "TimeMachine/Private/Consts.h"
#include "JsonReader.h"
#include "JsonSerializer.h"
#include "Slate/Public/Framework/Notifications/NotificationManager.h"
#include "SNotificationList.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

FMarketplaceChecker::FMarketplaceChecker(const FString& CurrentVersion):
	CurrentVersionAsNum(ConvertVersionString(CurrentVersion))
{
}

void FMarketplaceChecker::Check()
{
#if IS_PRO == false
	CallMarketplace(TEXT(PRO_PRODUCT_ID), &FMarketplaceChecker::HandleProResponse);
#endif
	
	CallMarketplace(TEXT(PRODUCT_ID), &FMarketplaceChecker::HandleProductResponse);
}

void FMarketplaceChecker::CallMarketplace(FString ProductId, MarketplaceCallback Callback)
{
	FHttpModule& Module = FHttpModule::Get();
    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = Module.CreateRequest();
    
	Request->SetURL(
		FString::Format(
		TEXT("https://www.unrealengine.com/marketplace/api/assets/asset/{0}"),
		{ ProductId }
	));
	Request->SetHeader(TEXT("User-Agent"), TEXT("X-UnrealEngine-Agent"));
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
	Request->SetHeader(TEXT("Accepts"), TEXT("application/json"));
	Request->SetVerb("GET");

	Request->OnProcessRequestComplete().BindRaw(this, Callback);

	Request->ProcessRequest();
}

void FMarketplaceChecker::HandleProResponse(FHttpRequestPtr, FHttpResponsePtr Response, bool bSuccessful) const
{
	if(!bSuccessful) { return; }

	TSharedPtr<FJsonObject> Data;

	ParseDataFromRequest(Response,Data);

	const int32 DiscountPer = Data->GetIntegerField("discountPercentage");
	
	if(DiscountPer < 100)
	{
		const auto OnSaleText =  FText::Format(
			LOCTEXT("ProOnSaleOffBang", "Time Machine Pro is on sale! {0}% Off!"),
			FText::AsNumber(100 - DiscountPer)
		);
		
		PushNotification(
			OnSaleText,
			LOCTEXT("GetTimeMachineProNowBang", "Get Time Machine Pro now!"),
			TEXT(PRO_URL)
		);
	}
}

void FMarketplaceChecker::HandleProductResponse(FHttpRequestPtr, FHttpResponsePtr Response,	bool bSuccessful) const
{
	if(!bSuccessful) { return; }

	TSharedPtr<FJsonObject> Data;

	ParseDataFromRequest(Response,Data);
	
	TArray<TSharedPtr<FJsonValue>> Releases = Data->GetArrayField("ReleaseInfo");
        
	for(const TSharedPtr<FJsonValue> ReleaseInfo : Releases)
	{
		const TSharedPtr<FJsonObject> ReleaseInfoObj = ReleaseInfo->AsObject();

		FString ReleaseNote = ReleaseInfoObj->GetStringField("releaseNote");

		if(ReleaseNote == "") { continue; }

		if(ConvertVersionString(ReleaseNote) > CurrentVersionAsNum)
		{
			PushNotification(
				LOCTEXT("TimeMachineUpdateAvailable", "There in a newer version of Time Machine available!"),
				LOCTEXT("UpdateTimeMachineNow", "Update Time Machine now."),
				TEXT("com.epicgames.launcher://ue/library")
			);
			
			break;
		}
	}
}

bool FMarketplaceChecker::ParseDataFromRequest(FHttpResponsePtr Response, TSharedPtr<FJsonObject>& ParsedDataOut) const
{
	const FString RawContent = Response.Get()->GetContentAsString();
    
	const TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(RawContent);
	
	TSharedPtr<FJsonObject> ParsedJson;
	if(FJsonSerializer::Deserialize(JsonReader, ParsedJson))
	{
		const TSharedPtr<FJsonObject> Data = ParsedJson->GetObjectField("Data");
		ParsedDataOut = Data->GetObjectField("Data");

		return true;
	}

	return false;
}

void FMarketplaceChecker::PushNotification(FText Text, FText HyperLinkText, const TCHAR* LinkUrl)
{
	FNotificationInfo Notice(Text);
	
	Notice.HyperlinkText = HyperLinkText; 
	Notice.Hyperlink = FSimpleDelegate::CreateLambda([LinkUrl]()
	{
		FPlatformProcess::LaunchURL(LinkUrl, nullptr, nullptr);
	});

	Notice.bUseThrobber = false;
    Notice.ExpireDuration = 10.0f;
    FSlateNotificationManager::Get().AddNotification(Notice);
}

int FMarketplaceChecker::ConvertVersionString(const FString& Version)
{
	return FCString::Atoi(*Version.Replace(TEXT("."), TEXT("")));
}

#undef LOCTEXT_NAMESPACE
