﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#include "TimeMachineNotesSettings.h"

UTimeMachineNotesSettings::UTimeMachineNotesSettings(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer),
    bFirstLoad(true)
{
}
