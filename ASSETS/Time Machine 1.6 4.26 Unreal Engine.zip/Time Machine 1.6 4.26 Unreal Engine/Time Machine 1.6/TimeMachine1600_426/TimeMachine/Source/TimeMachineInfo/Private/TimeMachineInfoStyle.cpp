// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachineInfoStyle.h"
#include "Framework/Application/SlateApplication.h"
#include "Projects/Public/Interfaces/IPluginManager.h"
#include "Styling/SlateStyleRegistry.h"
#include "Slate/SlateGameResources.h"
#include "SlateCore/Public/Styling/CoreStyle.h"

TSharedPtr< FSlateStyleSet > FTimeMachineInfoStyle::StyleInstance = NULL;

void FTimeMachineInfoStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FTimeMachineInfoStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FTimeMachineInfoStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("TimeMachineStyle"));
	return StyleSetName;
}

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define TTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".ttf") ), __VA_ARGS__ )
#define OTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".otf") ), __VA_ARGS__ )
#define DEFAULT_FONT(...) FCoreStyle::GetDefaultFontStyle(__VA_ARGS__)

const FVector2D Icon16x16(16.0f, 16.0f);

TSharedRef< FSlateStyleSet > FTimeMachineInfoStyle::Create()
{
	TSharedRef< FSlateStyleSet > Style = MakeShareable(new FSlateStyleSet("TimeMachineInfoStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("TimeMachine")->GetBaseDir() / TEXT("Resources"));

	//===================
	//    Release Notes Popup
	//===================

	Style->Set(TimeMachineInfoStyles::ReleaseNotesPopup::NewReleaseBang,
            FTextBlockStyle()
                .SetFont(DEFAULT_FONT("Bold", 16))
                .SetColorAndOpacity(FLinearColor(0.321f, 0.658f, 0.321f))
    );
	
	const FLinearColor PinkColor(0.898f, 0.365f, 1.0f);
	Style->Set(TimeMachineInfoStyles::ReleaseNotesPopup::GetProLinkText,
		FTextBlockStyle()
				.SetFont(DEFAULT_FONT("Bold", 14))
				.SetColorAndOpacity(PinkColor)
				.SetShadowColorAndOpacity(FColor::Transparent)
				.SetUnderlineBrush(
					IMAGE_BRUSH("Old/White", FVector2D(8.0f, 8.0f), PinkColor, ESlateBrushTileType::Both)
				)
    );
	
	return Style;
}

#undef IMAGE_BRUSH
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef TTF_FONT
#undef OTF_FONT

void FTimeMachineInfoStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FTimeMachineInfoStyle::Get()
{
	return *StyleInstance;
}

const FSlateBrush* FTimeMachineInfoStyle::GetBrush(const FName PropertyName)
{
	return Get().GetBrush(PropertyName);
}
