﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

class FReleaseNotesManager : public TSharedFromThis<FReleaseNotesManager>
{
public:
    static TSharedPtr<FReleaseNotesManager> Get();
    
    void CheckForNotice() const;
    
    void Display() const;
    
private:
    FReleaseNotesManager();
    
    
    inline void LaunchWebView(bool bAddPro, bool bAdNew, float MinHeight) const;
    
    bool ShouldSkipVersion() const;
    
    inline FString BuildNotesPath() const;

    static TSharedPtr<SWidget> BuildFooterWidget();
    
    static TSharedPtr<SWidget> BuildNewHeaderWidget();

    
    //Members
    static TSharedPtr<FReleaseNotesManager> Instance;
    
    FString PluginBaseDir;
    FString PluginVersion;
};
