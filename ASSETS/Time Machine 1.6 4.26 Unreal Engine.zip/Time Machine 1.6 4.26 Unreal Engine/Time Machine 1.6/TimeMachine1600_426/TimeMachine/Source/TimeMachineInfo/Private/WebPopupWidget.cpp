﻿#include "WebPopupWidget.h"

#include "TimeMachineInfoStyle.h"
#include "WebBrowser/Public/SWebBrowserView.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

void WebPopupWidget::Display(
	FString StartingUrl,
	FText Title,
	BuildWebPopupWidget FooterWidgetDel,
	BuildWebPopupWidget HeaderWidgetDel,
	float MinHeight)
{
	TSharedPtr<SWindow> Window = SNew(SWindow)
    					.Title(Title)
    					.SupportsMaximize(false)
    					.SupportsMinimize(false)
    					.HasCloseButton(false)
    					.bDragAnywhere(true)
    					.IsTopmostWindow(true)
    					.FocusWhenFirstShown(true)
						.AutoCenter(EAutoCenter::PreferredWorkArea)
    					.MinWidth(550.0f)
    					.MinHeight(MinHeight);

	const TSharedRef<WebPopupWidget> WebWidget = SNew(WebPopupWidget)
					.PartentWindow(Window)
					.StartingUrl(StartingUrl)
					.HeaderDel(HeaderWidgetDel)
					.FooterDel(FooterWidgetDel);

	Window->SetContent(WebWidget);
    FSlateApplication::Get().AddWindow(Window.ToSharedRef());
}

void WebPopupWidget::Construct(const FArguments& InArgs)
{
	ParentWindow = InArgs._PartentWindow;

	TSharedRef<SVerticalBox> ContentWidget = SNew(SVerticalBox);

	auto AddWidgetFunc = [ContentWidget](BuildWebPopupWidget WidgetDel)
	{
		if(WidgetDel.IsBound())
		{
			const TSharedPtr<SWidget> Widget = WidgetDel.Execute();

			if(Widget)
			{
				ContentWidget->AddSlot()
					.AutoHeight()
					.VAlign(VAlign_Bottom)
					.HAlign(HAlign_Center)
					[
						Widget.ToSharedRef()
					];
			}
		}	
	};

	AddWidgetFunc(InArgs._HeaderDel);

	ContentWidget->AddSlot()
		.AutoHeight()
		[
			SNew(SBox)
				.HeightOverride(360.0f)
			[
				SNew(SWebBrowserView)
					.ParentWindow(ParentWindow)	
					.InitialURL(InArgs._StartingUrl)
					.BackgroundColor(FColor::Black)
			]
		];
	
	AddWidgetFunc(InArgs._FooterDel);

	ContentWidget->AddSlot()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Center)
		[
			SNew(SButton)
				.Text(LOCTEXT("Ok", "Ok"))
				.ContentPadding(FMargin(80.0f, 2.0f))
				.OnClicked_Raw(this, &WebPopupWidget::OnOkClicked)
		];

	ChildSlot[ContentWidget];
}

FReply WebPopupWidget::OnOkClicked() const
{
	ParentWindow->RequestDestroyWindow();

	return FReply::Handled();
}

#undef LOCTEXT_NAMESPACE
