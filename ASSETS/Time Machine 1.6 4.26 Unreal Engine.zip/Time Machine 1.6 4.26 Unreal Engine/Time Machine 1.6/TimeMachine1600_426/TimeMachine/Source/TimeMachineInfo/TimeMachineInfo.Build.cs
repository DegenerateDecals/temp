// Copyright 2020 Christopher Venturini - All Rights Reserved.

using UnrealBuildTool;

public class TimeMachineInfo : ModuleRules
{
	public TimeMachineInfo(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bLegacyPublicIncludePaths = true;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				"TimeMachine/Private"
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
			
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				// ... add other public dependencies that you statically link with here ...
				"AnimationBlueprintEditor",
				"BehaviorTreeEditor",
				"Core",
				"CoreUObject",
				"DeveloperSettings",
				"Engine",
				"EditorStyle",
				"HTTP",
				"InputCore",
				"Json",
				"JsonUtilities",
				"Projects",
				"Slate",
				"SlateCore",
				"SSL",
				"UnrealEd",
				"WebBrowser",
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
		
	}
}
