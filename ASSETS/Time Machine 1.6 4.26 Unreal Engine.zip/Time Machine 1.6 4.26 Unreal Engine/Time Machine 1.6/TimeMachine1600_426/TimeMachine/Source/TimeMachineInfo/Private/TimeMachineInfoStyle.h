// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateStyle.h"

namespace TimeMachineInfoStyles
{
	namespace ReleaseNotesPopup 
	{
		const FName NewReleaseBang("NewReleaseBang");
		const FName GetProLinkText("GetPro");
	}
	
	
};

class FTimeMachineInfoStyle
{
public:
	

	static void Initialize();

	static void Shutdown();

	static void ReloadTextures();

	static const ISlateStyle& Get();
	
	static const FSlateBrush* GetBrush(const FName PropertyName);

	static FName GetStyleSetName();

private:

	static TSharedRef< class FSlateStyleSet > Create();

	static TSharedPtr< class FSlateStyleSet > StyleInstance;
};