﻿#include "ReleaseNotesManager.h"

#include "TimeMachine/Private/Consts.h"
#include "Runtime/Core/Public/Misc/FileHelper.h"
#include "Runtime/Core/Public/Internationalization/Culture.h"
#include "Runtime/Json/Public/Serialization/JsonSerializer.h"
#include "Runtime/Json/Public/Serialization/JsonReader.h"
#include "Runtime/Projects/Public/Interfaces/IPluginManager.h"
#include "TimeMachineNotesSettings.h"
#include "TimeMachineInfoStyle.h"
#include "WebPopupWidget.h"

namespace 
{
    const FString NOTES_ROOT_PATH = "/Resources/ReleaseNotes/";
}

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

TSharedPtr<FReleaseNotesManager> FReleaseNotesManager::Instance;

FReleaseNotesManager::FReleaseNotesManager()
{
    const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(PLUGIN_NAME);
    PluginBaseDir = FPaths::ConvertRelativePathToFull(Plugin->GetBaseDir());
    PluginVersion = Plugin->GetDescriptor().VersionName; 
}

TSharedPtr<FReleaseNotesManager> FReleaseNotesManager::Get()
{
    if(!Instance)
    {
        Instance = MakeShareable<FReleaseNotesManager>(new FReleaseNotesManager());
    }

    return Instance;
}

void FReleaseNotesManager::CheckForNotice() const
{
    auto* Settings = GetMutableDefault<UTimeMachineNotesSettings>();

    if(PluginVersion != Settings->LastReleaseNotesDisplayed)
    {
        // Optimization so we don't check if we should skip everytime
        if(!Settings->bFirstLoad && !ShouldSkipVersion())
        {
            LaunchWebView(!IS_PRO, true, 500.0f);
        }
        
        Settings->LastReleaseNotesDisplayed = PluginVersion;
        Settings->bFirstLoad = false;
        Settings->SaveConfig();
    }
}

void FReleaseNotesManager::Display() const
{
    LaunchWebView(false, false,425.0f);
}

void FReleaseNotesManager::LaunchWebView(bool bAddPro, bool bAdNew, float MinHeight) const
{
    const FText WebViewTitle = FText::Format(
        LOCTEXT("ReleaseNotesTitle", "Time Machine ({0}) Release Notes"),
        FText::FromString(PluginVersion));

    BuildWebPopupWidget HeaderDel = nullptr;
    if( bAdNew )
    {
        HeaderDel = BuildWebPopupWidget::CreateStatic(&FReleaseNotesManager::BuildNewHeaderWidget);
    }
    
    BuildWebPopupWidget FooterDel = nullptr;
    if( bAddPro )
    {
        FooterDel = BuildWebPopupWidget::CreateStatic(&FReleaseNotesManager::BuildFooterWidget);
    }

    const FCultureRef CurLang = FInternationalization::Get().GetCurrentLanguage();
    const FString LangCode = CurLang->GetName().Replace(TEXT("-"), TEXT("_")).ToLower();
    
    WebPopupWidget::Display(
            "file:///" + BuildNotesPath() + "index.html?lang=" + LangCode,
            WebViewTitle,
            FooterDel,
            HeaderDel,
            MinHeight
    );
}


bool FReleaseNotesManager::ShouldSkipVersion() const
{
    bool bSkip = false;

    const FString SkipVersPath = BuildNotesPath() + "SkipVersions.json";
    FString RawFileContents; 
    FFileHelper::LoadFileToString(RawFileContents, *SkipVersPath);

    const TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(RawFileContents);

    TSharedPtr<FJsonObject> ParsedJson;
    if(FJsonSerializer::Deserialize(JsonReader, ParsedJson))
    {
        TArray<TSharedPtr<FJsonValue>> VersionsToSkipArray = ParsedJson->GetArrayField("VersionsToSkip");

        for(const TSharedPtr<FJsonValue> Version : VersionsToSkipArray)
        {
            if(PluginVersion == Version->AsString())
            {
                bSkip = true;
                break;
            }
        }
    }
    else
    {
        bSkip = true;
    }

    return bSkip;
}

FString FReleaseNotesManager::BuildNotesPath() const
{
    return PluginBaseDir + NOTES_ROOT_PATH;
}

TSharedPtr<SWidget> FReleaseNotesManager::BuildFooterWidget() 
{
    return SNew(SVerticalBox)
               +SVerticalBox::Slot()
                    .Padding(15.0f, 7.5f)
                    .HAlign(HAlign_Left)
                    .AutoHeight()
               [
                    SNew(SHorizontalBox)
                        +SHorizontalBox::Slot()
                            .FillWidth(1.0f)
                            .HAlign(HAlign_Left)
                       [
                            SNew(SBorder)
                                .OnMouseButtonDown_Lambda([] (const FGeometry& Geo, const FPointerEvent& Event){
                                    FPlatformProcess::LaunchURL(TEXT(PRO_URL), nullptr, nullptr);
                                    return FReply::Handled();
                                })
                                .BorderBackgroundColor(FColor::Transparent)
                                .DesiredSizeScale(FVector2D(2.3f, 1.0f))
                                .ForegroundColor(FColor::Transparent)
                                
                           [
                                 SNew(STextBlock)
                                    .Justification(ETextJustify::Left) 
                                    .Cursor_Lambda([] { return TOptional<EMouseCursor::Type>(EMouseCursor::Hand ); })
                                    .TextStyle(FTimeMachineInfoStyle::Get(), TimeMachineInfoStyles::ReleaseNotesPopup::GetProLinkText)
                                    .Text(LOCTEXT("GetProBang", "Get Time Machine Pro!"))
                                    
                           ]
                       ]
               ];
}

TSharedPtr<SWidget> FReleaseNotesManager::BuildNewHeaderWidget() 
{
    return SNew(SVerticalBox)
        +SVerticalBox::Slot()
            .AutoHeight()
            .HAlign(HAlign_Left)
       [
            SNew(SHorizontalBox)
                +SHorizontalBox::Slot()
                    .Padding(15.0f, 5.0f)
                    .FillWidth(1.0f)
               [
                    SNew(STextBlock)
                        .TextStyle(FTimeMachineInfoStyle::Get(), TimeMachineInfoStyles::ReleaseNotesPopup::NewReleaseBang)
                        .MinDesiredWidth(500.0f)
                        .Justification(ETextJustify::Left)
                        .Text(LOCTEXT("NewReleaseBang", "NEW Release!"))
               ]
       ];
}

#undef LOCTEXT_NAMESPACE
