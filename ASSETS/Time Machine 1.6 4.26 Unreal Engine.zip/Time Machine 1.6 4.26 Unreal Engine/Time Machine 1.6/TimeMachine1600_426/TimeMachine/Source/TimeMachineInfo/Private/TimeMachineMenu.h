﻿#pragma once

#include "ReleaseNotesManager.h"
#include "Runtime/Projects/Public/Interfaces/IPluginManager.h"

class FTimeMachineMenu
{
public:
   FTimeMachineMenu();

   explicit FTimeMachineMenu(
      TSharedPtr<FReleaseNotesManager> ReleaseNotesManager
   );

   FTimeMachineMenu(
      TSharedPtr<FReleaseNotesManager> ReleaseNotesManager,
   	const TSharedPtr<IPlugin> TimeMachinePlugin
   );

   void BindMenu();

private:
   void BuildMenu(FMenuBuilder& MenuBuilder);

   static void HandleGetPro();
   static void HandleContactSupport();
   void HandleReleaseNotesOpen() const;
   void HandleLaunchWebsite() const;

   // Members

   TSharedPtr<FReleaseNotesManager> ReleaseNotesManager;
   FString PluginVersion;
   FString Url;
};
