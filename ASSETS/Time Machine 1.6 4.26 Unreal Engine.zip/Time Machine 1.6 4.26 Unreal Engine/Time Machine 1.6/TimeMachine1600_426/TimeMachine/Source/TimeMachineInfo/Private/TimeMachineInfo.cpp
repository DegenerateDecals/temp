﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachineInfo.h"

#include "IPluginManager.h"
#include "TimeMachineInfoStyle.h"
#include "MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "TimeMachine/Private/Consts.h"

FTimeMachineInfo::FTimeMachineInfo():
	TimeMachinePlugin(IPluginManager::Get().FindPlugin(PLUGIN_NAME)),
    MarketplaceChecker(TimeMachinePlugin->GetDescriptor().VersionName)
{
	ReleaseNotesManager = FReleaseNotesManager::Get();
}

FTimeMachineInfo::FTimeMachineInfo(
	FMarketplaceChecker MarketplaceChecker,
	const TSharedPtr<FReleaseNotesManager> ReleaseNotesManager
):
	MarketplaceChecker(MarketplaceChecker),
	ReleaseNotesManager(std::move(ReleaseNotesManager))
{
}

void FTimeMachineInfo::StartupModule()
{
	FTimeMachineInfoStyle::Initialize();
	FTimeMachineInfoStyle::ReloadTextures();
	
    Menu.BindMenu();
	
	IMainFrameModule& MainFrame = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>("MainFrame");
	MainFrame.OnMainFrameCreationFinished().AddRaw(this, &FTimeMachineInfo::OnMainFrameCreationFinished);
}

void FTimeMachineInfo::ShutdownModule()
{
	FTimeMachineInfoStyle::Shutdown();
}

void FTimeMachineInfo::OnMainFrameCreationFinished(TSharedPtr<SWindow> InRootWindow, bool bIsNewProjectWindow)
{
	ReleaseNotesManager->CheckForNotice();
    MarketplaceChecker.Check();
}

IMPLEMENT_MODULE(FTimeMachineInfo, TimeMachineInfo)
