﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "BasicAssetEditorMonitor.h"
#include "HistoryManager.h"

BasicAssetEditorMonitor::BasicAssetEditorMonitor(
		FHistoryManager* Owner,
		UObject* TrackedObj,
		IAssetEditorInstance* AssetEditor,
		FOnTrackedUiStateChange UiChangeCallback,
        FOnTrackedUiEditorClosed UiEditorClosedCallback
	):
EditorMonitor(Owner, TrackedObj, AssetEditor, UiChangeCallback, UiEditorClosedCallback)
{
}

void BasicAssetEditorMonitor::StartMonitoring()
{
	EditorMonitor::StartMonitoring();
	
	CallUiChangeCallback();
}

