﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "EditorMonitor.h"
#include "Kismet/Public/BlueprintEditor.h"

class BlueprintEditorMonitor : public EditorMonitor
{
public:
    BlueprintEditorMonitor(
		FHistoryManager* Owner,
        UObject* TrackedObj,
        IAssetEditorInstance* AssetEditor,
        FOnTrackedUiStateChange UiChangeCallback,
        FOnTrackedUiEditorClosed UiEditorClosedCallback
    );

    ~BlueprintEditorMonitor();

    virtual void StartMonitoring() override;
    
protected:
    void BindBlueprint(FBlueprintEditor* BlueprintEditor);

    UEdGraph* GetActiveBlueprintGraphObj(FBlueprintEditor* BlueprintEditor, TWeakPtr<SDockTab> ForTab);

    void OnAnyTabActivatedDocTracking(TSharedPtr<SDockTab> OldTab, TSharedPtr<SDockTab> NewTab);
    
    void OnAnyTabForegroundedDocTracking(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab> OldTab);

    void OnDocumentTabClosed(TSharedRef<SDockTab> Tab);
    
    virtual TSharedPtr<TrackedUiState> BuildUiChangeEvent() override;

    // Members
    FBlueprintEditor* CurrentBlueprintEditor;
    
	FDelegateHandle TabForegroundedHandle;
	TWeakPtr<SDockTab> CurrentBlueprintDocTab;
	FName CurrentMode;
    int DocumentTabIgnoreCount = 0;
};
