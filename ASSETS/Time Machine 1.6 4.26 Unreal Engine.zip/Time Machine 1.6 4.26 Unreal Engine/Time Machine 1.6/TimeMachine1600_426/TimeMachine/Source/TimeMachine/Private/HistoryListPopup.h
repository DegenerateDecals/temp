﻿#pragma once

#include "HistoryListWidget.h"
#include "TrackedUiState.h"

class SHistoryListPopup  
{
public:
	static void DisplayMenu(
		FText Title,
		TSharedPtr<TrackedHistoryArray> TrackedHistory,
		SHistoryListWidget::FOnHistoryItemSelected OnHistoryItemSel
	);
};
