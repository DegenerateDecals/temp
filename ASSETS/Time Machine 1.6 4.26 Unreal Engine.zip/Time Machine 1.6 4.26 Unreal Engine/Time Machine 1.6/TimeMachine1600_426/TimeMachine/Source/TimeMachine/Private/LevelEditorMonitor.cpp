﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#include "LevelEditorMonitor.h"

#include "LevelEditor.h"

LevelEditorMonitor::LevelEditorMonitor(
    FHistoryManager* Owner,
    const FOnTrackedUiStateChange& UiChangeCallback)
        :UiMonitor(Owner, UiChangeCallback)
{
}

void LevelEditorMonitor::StartMonitoring()
{
    UiMonitor::StartMonitoring();
    FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
    BindUiTab(LevelEditorModule.GetLevelEditorTab());
}

FString LevelEditorMonitor::GetName()
{
	return GWorld->GetOutermost()->GetName();
}

TSharedPtr<TrackedUiState> LevelEditorMonitor::BuildUiChangeEvent()
{
    return MakeShared<LevelEditorUiState>();
}

