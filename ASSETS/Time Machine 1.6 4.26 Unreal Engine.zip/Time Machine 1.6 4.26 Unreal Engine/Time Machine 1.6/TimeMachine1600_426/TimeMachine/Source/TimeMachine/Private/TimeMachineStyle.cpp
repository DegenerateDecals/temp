// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachineStyle.h"
#include "TimeMachine.h"
#include "Framework/Application/SlateApplication.h"
#include "Styling/SlateStyleRegistry.h"
#include "Slate/SlateGameResources.h"
#include "Interfaces/IPluginManager.h"
#include "SlateCore/Public/Styling/CoreStyle.h"

TSharedPtr< FSlateStyleSet > FTimeMachineStyle::StyleInstance = NULL;

void FTimeMachineStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FTimeMachineStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FTimeMachineStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("TimeMachineStyle"));
	return StyleSetName;
}

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define TTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".ttf") ), __VA_ARGS__ )
#define OTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".otf") ), __VA_ARGS__ )
#define DEFAULT_FONT(...) FCoreStyle::GetDefaultFontStyle(__VA_ARGS__)

const FVector2D Icon16x16(16.0f, 16.0f);

TSharedRef< FSlateStyleSet > FTimeMachineStyle::Create()
{
	TSharedRef< FSlateStyleSet > Style = MakeShareable(new FSlateStyleSet("TimeMachineStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("TimeMachine")->GetBaseDir() / TEXT("Resources"));

	//===================
	//    Well Buttons
	//===================
	
	Style->Set(TimeMachineStyles::WellButtons::BackArrow, new IMAGE_BRUSH("assign_left_16x", Icon16x16));
	Style->Set(TimeMachineStyles::WellButtons::BackArrow_Black, new IMAGE_BRUSH("assign_left_16x", Icon16x16, FLinearColor::Black));
	
	Style->Set(TimeMachineStyles::WellButtons::FwdArrow, new IMAGE_BRUSH("assign_right_16x", Icon16x16));
	Style->Set(TimeMachineStyles::WellButtons::FwdArrow_Black, new IMAGE_BRUSH("assign_right_16x", Icon16x16, FLinearColor::Black));

	Style->Set(TimeMachineStyles::WellButtons::TabWellButtons, FButtonStyle()
        .SetNormalPadding(0) 
        .SetPressedPadding(0)
        .SetNormal(FSlateColorBrush(FColor::Transparent))
        .SetHovered(FSlateColorBrush(FLinearColor(0.728f, 0.364f, 0.003f)))
    );

	return Style;
}

#undef IMAGE_BRUSH
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef TTF_FONT
#undef OTF_FONT

void FTimeMachineStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FTimeMachineStyle::Get()
{
	return *StyleInstance;
}

const FSlateBrush* FTimeMachineStyle::GetBrush(const FName PropertyName)
{
	return Get().GetBrush(PropertyName);
}
