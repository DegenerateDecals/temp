// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "HistoryListWidget.h"

#include "Algo/Reverse.h"
#include "Slate/Public/Framework/Application/SlateApplication.h"
#include "Runtime/Core/Public/Misc/TextFilter.h"
#include "Slate/Public/Widgets/Input/SSearchBox.h"
#include "Slate/Public/Widgets/Layout/SBox.h"
#include "Slate/Public/Widgets/Layout/SSeparator.h"
#include "Slate/Public/Widgets/Views/SListView.h"


#define LOCTEXT_NAMESPACE "FTimeMachineModule"

TSharedRef<SHistoryListWidget> SHistoryListWidget::CreateMenu(
	TSharedPtr<TrackedHistoryArray> TrackedHistory,
	FOnHistoryItemSelected OnHistoryItemSel,
	HistoryListWidgetCloseDel OnClose
)
{
	return SNew(SHistoryListWidget)
    		.OnHistoryItemSelected(OnHistoryItemSel)
    		.TrackedHistory(TrackedHistory)
			.OnClose(OnClose);
}

void SHistoryListWidget::Construct(const FArguments& InArgs)
{
	OrgHistory = InArgs._TrackedHistory;
	OnHistoryItemSelected = InArgs._OnHistoryItemSelected;
	OnCloseDel = InArgs._OnClose;
	
	ResolvedHistory = *OrgHistory.Get();
	Algo::Reverse(ResolvedHistory); 

	ChildSlot
		[
			SNew(SBorder)
				.Padding(5.0f)
			[
				SNew(SVerticalBox)
					+SVerticalBox::Slot()
					.AutoHeight()
					.Padding(2, 5)
					[
						SAssignNew(SearchBox, SSearchBox)
							.DelayChangeNotificationsWhileTyping(true)
							.HintText(LOCTEXT("SearchHint", "Search History"))
							.MinDesiredWidth(250.0f)
							.OnKeyDownHandler_Raw(this, &SHistoryListWidget::OnSearchBoxKeyDownEvent)
							.OnTextChanged(this, &SHistoryListWidget::OnSearchBoxChanged)
					]
					+SVerticalBox::Slot()
						.AutoHeight()
						.Padding(2, 5)
						[
							SNew(SSeparator)
								.Orientation(EOrientation::Orient_Horizontal)
								.Thickness(3.0f)
						]
					+SVerticalBox::Slot()
						.AutoHeight()
						.MaxHeight(InArgs._ListHeight)
					[
						SAssignNew(HistoryView, SListView<TSharedPtr<TrackedUiState>>)
							.HandleGamepadEvents(false)
							.IsFocusable(false)
							.ListItemsSource(&ResolvedHistory)
							.OnGenerateRow(this, &SHistoryListWidget::MakeListViewWidget)
							.OnMouseButtonClick_Raw(this, &SHistoryListWidget::OnUserClickedHistoryItem)
							.OnMouseButtonDoubleClick_Raw(this, &SHistoryListWidget::OnUserDoubleClickedHistoryItem)
							.SelectionMode(ESelectionMode::Single)
					]
					+SVerticalBox::Slot()
						.Padding(0.0f)
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.AutoHeight()
					[
						SAssignNew(EmptyTextBox, SBox)
								.HeightOverride(0)
								.HAlign(EHorizontalAlignment::HAlign_Center)
								.VAlign(EVerticalAlignment::VAlign_Center)
								.Visibility(EVisibility::Hidden)
						[
							SNew(STextBlock)
								.Font(FSlateFontInfo(TEXT("Slate/Fonts/Roboto-Italic.ttf"), 10))
								.Text(LOCTEXT("NoHistory","No history found from search"))
						]
					]
			]
		];

}

TSharedPtr<TrackedUiState> SHistoryListWidget::GetSelectedHistory()
{
	if(SelectionIndex == -1) { return nullptr; }

	return ResolvedHistory[SelectionIndex];
}

void SHistoryListWidget::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	if (!SearchBox->HasAnyUserFocusOrFocusedDescendants())
	{
		FSlateApplication::Get().SetAllUserFocus(SearchBox, EFocusCause::SetDirectly);
	}

	if (ResolvedHistory.Num() == 0)
	{
		HistoryView->SetVisibility(EVisibility::Hidden);
		EmptyTextBox->SetHeightOverride(50.0f);
		EmptyTextBox->SetVisibility(EVisibility::Visible);
	}
	else
	{
		HistoryView->SetVisibility(EVisibility::Visible);
		EmptyTextBox->SetHeightOverride(0.0f);
		EmptyTextBox->SetVisibility(EVisibility::Hidden);
	}
}

TSharedRef<ITableRow> SHistoryListWidget::MakeListViewWidget(TSharedPtr<TrackedUiState> HistoryItem, const TSharedRef<STableViewBase>& OwnerTable) const
{
	auto ItemWidget = SNew(STableRow<TSharedPtr<TrackedUiState>>, OwnerTable);

	TrackedUiState* ItemData = HistoryItem.Get();

	ItemWidget->SetContent(
		SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.Padding(2, 5)
		[
			SNew(SHorizontalBox)

			+SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(0, 0, 2, 0)

				// ADD THUMBNAIL

			+SHorizontalBox::Slot()
				.AutoWidth()
				.Padding(2.5f, 1.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.Padding(0, 0, 0, 2)
				[
					SNew(STextBlock)
						.Text(ItemData->GetTitle())
						.HighlightText(CurrentSearchEntry)
				]

				+SVerticalBox::Slot()
				[
					SNew(STextBlock)
						.Text(ItemData->GetPath())
						.ColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f, 0.70f))
						.Font(FSlateFontInfo(TEXT("Slate/Fonts/Roboto-Italic.ttf"), 8))
						.HighlightText(CurrentSearchEntry)
				]

				+SVerticalBox::Slot()
					.AutoHeight()
				[
					SNew(STextBlock)
						.Text(ItemData->GetInfo())
						.ColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f, 0.70f))
						.Font(FSlateFontInfo(TEXT("Slate/Fonts/Roboto-Italic.ttf"), 8))
						.Visibility_Lambda([ItemData]() { return (ItemData->GetInfo().IsEmpty() ? EVisibility::Hidden : EVisibility::Visible); })
						.HighlightText(CurrentSearchEntry)
				]
			]
		]
	);

	return ItemWidget;
}

FReply SHistoryListWidget::OnSearchBoxKeyDownEvent(const FGeometry& Geometry, const FKeyEvent& KeyEvent)
{
	const FKey KeyEntered = KeyEvent.GetKey();
	
	if (KeyEntered == EKeys::Escape)
	{
		OnCloseDel.ExecuteIfBound();

		return FReply::Handled();
	}

	if (ResolvedHistory.Num() == 0) { return FReply::Unhandled(); }

	if (KeyEntered == EKeys::Enter)
	{
		if (SelectionIndex >= 0)
		{
			OnUserDoubleClickedHistoryItem(ResolvedHistory[SelectionIndex]);
		}

		OnCloseDel.ExecuteIfBound();
		
		return FReply::Handled();
	}
	else if (KeyEntered == EKeys::Down || KeyEntered == EKeys::Up)
	{
		const int LastIndex = ResolvedHistory.Num() - 1;

		if (KeyEntered == EKeys::Up && SelectionIndex > 0)
		{
			SelectionIndex--;
		}
		else if (KeyEntered == EKeys::Down && SelectionIndex < LastIndex)
		{
			SelectionIndex++;
		}

		const TSharedPtr<TrackedUiState>& SelectedHist = ResolvedHistory[SelectionIndex];

		HistoryView->ClearSelection();
		HistoryView->SetItemSelection(SelectedHist, true);
		HistoryView->RequestScrollIntoView(SelectedHist);
		
		return FReply::Handled();
	}

	return FReply::Unhandled();
}

void SHistoryListWidget::OnUserDoubleClickedHistoryItem(TSharedPtr<TrackedUiState> SelectedHistoryItem) const
{
	OnHistoryItemSelected.ExecuteIfBound(SelectedHistoryItem);

	OnCloseDel.ExecuteIfBound();
}

void SHistoryListWidget::OnUserClickedHistoryItem(TSharedPtr<TrackedUiState> SelectedHistoryItem)
{
	SelectionIndex = ResolvedHistory.IndexOfByKey(SelectedHistoryItem);
}

void SHistoryListWidget::OnSearchBoxChanged(const FText& InSearchText)
{
	HistoryView->ClearSelection();
	SelectionIndex = 0;
	ResolvedHistory.Empty();
	CurrentSearchEntry = InSearchText;

	if (!InSearchText.IsEmpty())
	{
		TTextFilter<const TSharedPtr<TrackedUiState>> TextFilter(
			TTextFilter<const TSharedPtr<TrackedUiState>>::FItemToStringArray::CreateLambda([](const TSharedPtr<TrackedUiState> InData, TArray<FString>& OutBasicStrings) {
				OutBasicStrings.Add(InData->GetPath().ToString());
				OutBasicStrings.Add(InData->GetTitle().ToString());
				OutBasicStrings.Add(InData->GetInfo().ToString());
			})
		);

		TextFilter.SetRawFilterText(InSearchText);

		for (const TSharedPtr<TrackedUiState> HistItem : *OrgHistory.Get())
		{
			if (TextFilter.PassesFilter(HistItem))
			{
				ResolvedHistory.Emplace(HistItem);
			}
		}
	}
	else
	{
		ResolvedHistory = *OrgHistory.Get();
	}

	Algo::Reverse(ResolvedHistory); 

	HistoryView->RebuildList();
}

#undef LOCTEXT_NAMESPACE
