﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "AssetEditorResolver.h"
#include "Editor.h"
#include "Launch/Resources/Version.h"
#include "Editor/UnrealEd/Public/Toolkits/AssetEditorManager.h"

IAssetEditorInstance* AssetEditorResolver::GetEditorForAsset(UObject* Asset)
{
#if ENGINE_MINOR_VERSION > 23
	auto* AssetEditorSystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
#else
	auto* AssetEditorSystem = &FAssetEditorManager::Get();
#endif
	return AssetEditorSystem->FindEditorForAsset(Asset, false);
}