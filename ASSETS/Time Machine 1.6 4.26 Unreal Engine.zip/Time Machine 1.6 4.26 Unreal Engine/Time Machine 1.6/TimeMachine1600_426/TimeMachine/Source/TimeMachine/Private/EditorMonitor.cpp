﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "EditorMonitor.h"

EditorMonitor::EditorMonitor(
    FHistoryManager* Owner,
    UObject* TrackedObj,
    IAssetEditorInstance* AssetEditor,
    const FOnTrackedUiStateChange& UiChangeCallback,
    const FOnTrackedUiEditorClosed& UiEditorClosedCallback
):
    UiMonitor(Owner, UiChangeCallback),
    TrackedObj(std::move(TrackedObj)),
    AssetEditor(AssetEditor),
    UiEditorClosedCallback(UiEditorClosedCallback)
{
}

EditorMonitor::~EditorMonitor()
{
    if(TabClosedCallback.IsBound()) { TabClosedCallback.Unbind(); };
}

FString EditorMonitor::GetName()
{
    return TrackedObj->GetName();
}

void EditorMonitor::StartMonitoring()
{
    UiMonitor::StartMonitoring();

    BindEditor();
}

void EditorMonitor::BindEditor()
{
    const TSharedPtr<FTabManager> AssetTabMgr = AssetEditor->GetAssociatedTabManager();

    if (!AssetTabMgr.IsValid()) { return; }
     
    const TWeakPtr<SDockTab> NewTab =  FGlobalTabmanager::Get()->GetMajorTabForTabManager(AssetTabMgr.ToSharedRef());
    
    BindUiTab(FGlobalTabmanager::Get()->GetMajorTabForTabManager(AssetTabMgr.ToSharedRef()));   
}

void EditorMonitor::BindUiTab(TWeakPtr<SDockTab> Tab)
{
    UiMonitor::BindUiTab(Tab);
    
    TabClosedCallback = SDockTab::FOnTabClosedCallback::CreateSP(this, &EditorMonitor::OnUiTabClosed);
    UiTab.Pin()->SetOnTabClosed(TabClosedCallback);
}

TSharedPtr<TrackedUiState> EditorMonitor::BuildUiChangeEvent()
{
    return MakeShared<AssetEditorUiState>(TrackedObj);
}

void EditorMonitor::OnUiTabClosed(TSharedRef<SDockTab> ClosedTab)
{
    if(ClosedTab != UiTab) { return; }

	UE_LOG(LogTimeMachine, Verbose, TEXT("%s UI monitor tab closing"), *GetName());
    
    UiEditorClosedCallback.ExecuteIfBound(MonitorId);
}