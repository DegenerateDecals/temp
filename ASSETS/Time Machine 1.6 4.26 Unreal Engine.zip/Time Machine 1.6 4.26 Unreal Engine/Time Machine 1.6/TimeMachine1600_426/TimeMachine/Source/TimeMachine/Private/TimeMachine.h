// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "HistoryManager.h"

class FToolBarBuilder;


class FTimeMachineModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	void BindCommand(const TSharedPtr<const FUICommandInfo> InUICommandInfo, FExecuteAction ExecuteAction, FCanExecuteAction CanExecuteAction, EUIActionRepeatMode RepeatMode = EUIActionRepeatMode::RepeatDisabled ) const;

	void OnHistoryItemSelected(bool bBackHistory, TSharedPtr<TrackedUiState> HistoryState) const;

	void OnMainFrameCreationFinished(TSharedPtr<SWindow> InRootWindow, bool bIsNewProjectWindow);

	void OnMoveStateCommand(bool bMoveFwd) const;
	
	void OnMoveStateToCommand(TSharedPtr<TrackedUiState> ToState, bool bMoveFwd) const;
	
	void OnTabActivated(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab> PriorTab);

	static void HandleHistoryNavigationResult(EHistoryNavigationResult Result);
	
	// Members
	
	TSharedPtr<FHistoryManager> HistoryManager;
	TWeakPtr<SNotificationItem> NavigationIssueNavigation;
	TWeakPtr<SDockTab> LastTabActivated;
	TSharedPtr<FUICommandList> PluginCommands;
	FDelegateHandle TabForegroundedHandle;
};
