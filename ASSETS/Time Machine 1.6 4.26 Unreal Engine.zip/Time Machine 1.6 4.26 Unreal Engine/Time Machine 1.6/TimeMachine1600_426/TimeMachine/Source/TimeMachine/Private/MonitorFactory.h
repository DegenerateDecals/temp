﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "EditorMonitor.h"

class FHistoryManager;

class MonitorFactory
{
public:
   TSharedPtr<EditorMonitor> ManufactureMonitor(
        FHistoryManager* Owner,
        UObject* ForObject,
        EditorMonitor::FOnTrackedUiStateChange UiChangeCallback,
        EditorMonitor::FOnTrackedUiEditorClosed UiEditorClosedCallback
   ) const;
};
