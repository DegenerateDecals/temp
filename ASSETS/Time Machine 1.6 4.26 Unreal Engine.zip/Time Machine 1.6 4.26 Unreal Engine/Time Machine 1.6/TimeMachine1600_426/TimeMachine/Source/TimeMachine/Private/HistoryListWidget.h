// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include <stdbool.h>

#include "Slate/Public/Widgets/Views/SListView.h"
#include "TrackedUiState.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/SCompoundWidget.h"

class SBox;
class SSearchBox;

class SHistoryListWidget : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FOnHistoryItemSelected, TSharedPtr<TrackedUiState>)
	DECLARE_DELEGATE(HistoryListWidgetCloseDel);

	SLATE_BEGIN_ARGS(SHistoryListWidget):
		_ListHeight(240.0f)
	{}
		SLATE_ARGUMENT(float, ListHeight)
		SLATE_ARGUMENT(FOnHistoryItemSelected, OnHistoryItemSelected)
		SLATE_ARGUMENT(TSharedPtr<TrackedHistoryArray>, TrackedHistory)
		SLATE_ARGUMENT(HistoryListWidgetCloseDel, OnClose)
	SLATE_END_ARGS()

	static TSharedRef<SHistoryListWidget> CreateMenu(
		TSharedPtr<TrackedHistoryArray> TrackedHistory,
		FOnHistoryItemSelected OnHistoryItemSel,
		HistoryListWidgetCloseDel OnClose
	);
	
	void Construct(const FArguments& InArgs);

	TSharedPtr<TrackedUiState> GetSelectedHistory();

	virtual void Tick( const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime ) override;

protected:
	TSharedRef<ITableRow> MakeListViewWidget(TSharedPtr<TrackedUiState> HistoryItem, const TSharedRef<STableViewBase>& OwnerTable) const;
	
	FReply OnSearchBoxKeyDownEvent(const FGeometry& Geometry, const FKeyEvent& KeyEvent);

	void OnSearchBoxChanged(const FText& InSearchText);

	void OnUserDoubleClickedHistoryItem(TSharedPtr<TrackedUiState> SelectedHistoryItem) const;
	
	void OnUserClickedHistoryItem(TSharedPtr<TrackedUiState> SelectedHistoryItem);

	// Members

	FText CurrentSearchEntry;
	TSharedPtr<SBox> EmptyTextBox;
	TSharedPtr<SListView<TSharedPtr<TrackedUiState>>> HistoryView;
	TSharedPtr<TrackedHistoryArray> OrgHistory;
	TrackedHistoryArray ResolvedHistory;
	FOnHistoryItemSelected OnHistoryItemSelected;
	TSharedPtr<SSearchBox> SearchBox;
	int SelectionIndex = -1;
	HistoryListWidgetCloseDel OnCloseDel;
};
