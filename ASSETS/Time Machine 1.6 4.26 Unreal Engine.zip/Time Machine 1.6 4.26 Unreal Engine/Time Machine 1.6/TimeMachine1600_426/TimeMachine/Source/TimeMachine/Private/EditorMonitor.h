﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "UiMonitor.h"

class EditorMonitor : public UiMonitor 
{
public:
    DECLARE_DELEGATE_OneParam(FOnTrackedUiEditorClosed, const FGuid&);
    
    virtual ~EditorMonitor();
    
    friend bool operator==(const EditorMonitor& Lhs, const EditorMonitor& RHS)
    {
        return static_cast<const UiMonitor&>(Lhs) == static_cast<const UiMonitor&>(RHS)
            && Lhs.TrackedObj == RHS.TrackedObj
            && Lhs.AssetEditor == RHS.AssetEditor;
    }

    friend bool operator!=(const EditorMonitor& Lhs, const EditorMonitor& RHS)
    {
        return !(Lhs == RHS);
    }

    virtual FString GetName() override;

    virtual void StartMonitoring() override;
    
protected:

    EditorMonitor(
        FHistoryManager* Owner,
        UObject* TrackedObj,
        IAssetEditorInstance* AssetEditor,
        const FOnTrackedUiStateChange& UiChangeCallback,
        const FOnTrackedUiEditorClosed& UiEditorClosedCallback
     );
    
    void BindEditor();

    virtual void BindUiTab(TWeakPtr<SDockTab> Tab) override;
    
    virtual TSharedPtr<TrackedUiState> BuildUiChangeEvent() override;

    void OnUiTabClosed(TSharedRef<SDockTab> ClosedTab) ;
    
    ///////////////////
    ///     Members
    ///////////////////
    
    UObject* TrackedObj;
    IAssetEditorInstance* AssetEditor;
    FDelegateHandle TabForegroundedHandle;

    // Callbacks
    FOnTrackedUiEditorClosed UiEditorClosedCallback;
    SDockTab::FOnTabClosedCallback TabClosedCallback;
};

