// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachine.h"

#include "AssetToolsModule.h"
#include "Consts.h"
#include "HistoryListPopup.h"
#include "TimeMachineStyle.h"
#include "TimeMachineCommands.h"
#include "LevelEditor.h"
#include "MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "Slate/Public/Widgets/Notifications/SNotificationList.h"
#include "Slate/Public/Framework/Notifications/NotificationManager.h"
#include "HistoryTabControlsWidget.h"
#include "TimeMachineLogging.h"
#include "TimeMachineSettings.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

void FTimeMachineModule::StartupModule()
{
	FTimeMachineStyle::Initialize();
	FTimeMachineStyle::ReloadTextures();

	FTimeMachineCommands::Register();

	PluginCommands = MakeShareable(new FUICommandList);

	TabForegroundedHandle = FGlobalTabmanager::Get()->OnTabForegrounded_Subscribe(FOnActiveTabChanged::FDelegate::CreateRaw(this, &FTimeMachineModule::OnTabActivated));
		
	// TODO: Move to constructor
	auto* Settings = GetDefault<UTimeMachineSettings>();
	HistoryManager = MakeShared<FHistoryManager>(Settings->bTrackLevelEditorFocus, Settings->MaxHistory);
	
	IMainFrameModule& MainFrame = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>("MainFrame");
	MainFrame.OnMainFrameCreationFinished().AddRaw(this, &FTimeMachineModule::OnMainFrameCreationFinished);

	
	UE_LOG(LogTimeMachine, Verbose, TEXT("Time Machine started"));
}

void FTimeMachineModule::ShutdownModule()
{
	FGlobalTabmanager::Get()->OnTabForegrounded_Unsubscribe(TabForegroundedHandle);

	FTimeMachineStyle::Shutdown();

	FTimeMachineCommands::Unregister();
}

void FTimeMachineModule::BindCommand(const TSharedPtr<const FUICommandInfo> InUICommandInfo, FExecuteAction ExecuteAction, FCanExecuteAction CanExecuteAction, EUIActionRepeatMode RepeatMode) const
{
	PluginCommands->MapAction(InUICommandInfo, ExecuteAction, CanExecuteAction, RepeatMode);

	IMainFrameModule& MainFrame = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>("MainFrame");
	MainFrame.GetMainFrameCommandBindings()->MapAction(InUICommandInfo, ExecuteAction, CanExecuteAction, RepeatMode);
}


void FTimeMachineModule::OnHistoryItemSelected(bool bBackHistory, TSharedPtr<TrackedUiState> HistoryState) const
{
	if (bBackHistory)
	{
		HistoryManager->MoveStateBackTo(HistoryState);
	}
	else
	{
		HistoryManager->MoveStateForwardTo(HistoryState);
	}
}

void FTimeMachineModule::OnMainFrameCreationFinished(TSharedPtr<SWindow>, bool)
{
	HistoryManager->Init();

	// TODO: Move to constructor
	auto* Settings = GetDefault<UTimeMachineSettings>();

	// REMOVE FOR FREE
	//TODO: Add popups for a lack of history
	if(Settings->Controls == NoControls)
	{
		BindCommand(
			FTimeMachineCommands::Get().OpenBackHistoryMenu,
			FExecuteAction::CreateStatic(
				&SHistoryListPopup::DisplayMenu,
				FText::FromString("Move Back"),
				HistoryManager->GetBackHistory(),
				SHistoryListWidget::FOnHistoryItemSelected::CreateRaw(this, &FTimeMachineModule::OnMoveStateToCommand, false)
			),
			FCanExecuteAction::CreateRaw(HistoryManager.Get(), &FHistoryManager::HasBackHistory)
		);

		BindCommand(
			FTimeMachineCommands::Get().OpenForwardHistoryMenu,
			FExecuteAction::CreateStatic(
				&SHistoryListPopup::DisplayMenu,
				FText::FromString("Move Forward"),
				HistoryManager->GetForwardHistory(),
				SHistoryListWidget::FOnHistoryItemSelected::CreateRaw(this, &FTimeMachineModule::OnMoveStateToCommand, true)
			),
			FCanExecuteAction::CreateRaw(HistoryManager.Get(), &FHistoryManager::HasForwardHistory)
		);
	}
	else
	{
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
    	TSharedPtr<SDockTab> LevelEditorTab = LevelEditorModule.GetLevelEditorTab();
    	LevelEditorTab->SetLeftContent(
    		HistoryTabControlsWidget::CreateControls(
    			LevelEditorTab,
    			HistoryManager,
    			(Settings->Controls == Default)
    		)
    	);	
	}
	
	//TODO: Move to Command handler
	BindCommand(
		FTimeMachineCommands::Get().MoveBackInHistory,
		FExecuteAction::CreateRaw(this, &FTimeMachineModule::OnMoveStateCommand, false),
		FCanExecuteAction::CreateRaw(HistoryManager.Get(), &FHistoryManager::HasBackHistory)
	);

	BindCommand(
		FTimeMachineCommands::Get().MoveForwardInHistory,
		FExecuteAction::CreateRaw(this, &FTimeMachineModule::OnMoveStateCommand, true),
		FCanExecuteAction::CreateRaw(HistoryManager.Get(), &FHistoryManager::HasForwardHistory)
	);
	
	UE_LOG(LogTimeMachine, Verbose, TEXT("Time Machine load completed"));
}

void FTimeMachineModule::OnMoveStateCommand(bool bMoveFwd) const
{
	EHistoryNavigationResult MoveResult;
	
	if(bMoveFwd)
	{
		MoveResult = HistoryManager.Get()->MoveStateForward();
	}
	else
	{
		MoveResult = HistoryManager.Get()->MoveStateBack();
	}

	HandleHistoryNavigationResult(MoveResult);
}

void FTimeMachineModule::OnMoveStateToCommand(TSharedPtr<TrackedUiState> ToState, bool bMoveFwd) const
{
	EHistoryNavigationResult MoveResult;
    	
	if(bMoveFwd)
	{
		MoveResult = HistoryManager.Get()->MoveStateForwardTo(ToState);
	}
	else
	{
		MoveResult = HistoryManager.Get()->MoveStateBackTo(ToState);
	}

    	HandleHistoryNavigationResult(MoveResult);
}

void FTimeMachineModule::OnTabActivated(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab>)
{
	auto* Settings = GetDefault<UTimeMachineSettings>();

	// REMOVE FOR FREE
	if(Settings->Controls == NoControls) { return; }

	if ((NewTab->GetTabRole() != MajorTab) || (LastTabActivated == NewTab)) { return; }

	if (NewTab->GetLayoutIdentifier().TabType == "PluginsEditor") { return; }

	NewTab->SetLeftContent(
		HistoryTabControlsWidget::CreateControls(
			NewTab,
			HistoryManager,
        	(Settings->Controls == Default)
		)
	);

	LastTabActivated = NewTab;
}

void FTimeMachineModule::HandleHistoryNavigationResult(EHistoryNavigationResult Result)
{
	if(Result == EHistoryNavigationResult::Success) { return; }

	FText NotificationText;

	if(Result == EHistoryNavigationResult::AssetDoesNotExist)
	{
		NotificationText = LOCTEXT("UnableToOpenAsset", "Unable to open an asset from your history. Has it been removed?");
	}
	else if(Result == EHistoryNavigationResult::BlueprintGraphMissing)
	{
		NotificationText = LOCTEXT("UnableToNavigateToGraph", "Unable to navigate to your history's blueprint graph. Has it been removed?");
	}
	else
	{
		NotificationText = LOCTEXT("UnknownProblemInNav", "Encountered an unknown problem when navigating your history.");
	}
	
	FNotificationInfo FailedNavInfo(NotificationText);
	FailedNavInfo.bUseThrobber = false;

	FSlateNotificationManager::Get().AddNotification(FailedNavInfo);
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FTimeMachineModule, TimeMachine)