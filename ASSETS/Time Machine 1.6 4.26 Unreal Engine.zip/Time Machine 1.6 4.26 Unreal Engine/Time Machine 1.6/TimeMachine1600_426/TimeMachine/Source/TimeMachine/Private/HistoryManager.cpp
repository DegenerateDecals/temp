// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "HistoryManager.h"

#include "AssetEditorResolver.h"
#include "AssetRegistryModule.h"
#include "Editor/Kismet/Public/WorkflowOrientedApp/WorkflowUObjectDocuments.h"
#include "IAssetRegistry.h"
#include "LevelEditorMonitor.h"
#include "Launch/Resources/Version.h"
#include "Widgets/Docking/SDockTab.h"


FHistoryManager::FHistoryManager(
			 bool bTrackLevelEditorFocus,
			 uint32 MaxHistorySize,
			 MonitorFactory Factory):
		BackHistory(MakeShared<TrackedHistoryArray>()),
		ForwardHistory(MakeShared<TrackedHistoryArray>()),
		MaxHistory(MaxHistorySize),
		bRestoringState(false),
		bTrackLevelEditorFocus(bTrackLevelEditorFocus),
		MonitorFac(Factory)
{
}

void FHistoryManager::Init()
{
#if ENGINE_MINOR_VERSION > 23
	auto* AssetEditorSystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
#else
	auto* AssetEditorSystem = &FAssetEditorManager::Get();
#endif
	AssetEditorSystem->OnAssetEditorOpened().AddSP(this, &FHistoryManager::OnAssetOpened);

	if (bTrackLevelEditorFocus)
    {
    	TSharedPtr<LevelEditorMonitor> LevelMon = MakeShared<LevelEditorMonitor>(
			this,
			EditorMonitor::FOnTrackedUiStateChange::CreateRaw(
				this,
				&FHistoryManager::RegisterForwardStateChange
			)
		);

		LevelMon->StartMonitoring();

		Monitors.Emplace(LevelMon->GetId(), std::move(LevelMon));
		
		CurrentState = MakeShared<LevelEditorUiState>();
    }

	FAssetRegistryModule& AssetRegistryModule = FModuleManager::GetModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
    AssetRegistryModule.Get().OnAssetRemoved().AddRaw(this, &FHistoryManager::OnAssetRemoved);

	OnGlobalTabActivated.AddSP(this, &FHistoryManager::CallTabActivatedCallback);
}

void FHistoryManager::BindTabActivatedAction(TWeakPtr<SDockTab> Tab, FHistoryManager::OnTabActivatedCallback Action)
{
	TabToDelegateMap.Add(Tab, Action);
}

void FHistoryManager::UnbindTabActivatedAction(TWeakPtr<SDockTab> Tab)
{
	TabToDelegateMap.Remove(Tab);
}

EHistoryNavigationResult FHistoryManager::MoveStateBack()
{
	return MoveState(BackHistory, ForwardHistory, BackHistory->Num() - 1);
}

EHistoryNavigationResult FHistoryManager::MoveStateForward()
{
	return MoveState(ForwardHistory, BackHistory, ForwardHistory->Num() - 1);
}

EHistoryNavigationResult FHistoryManager::MoveStateBackTo(TSharedPtr<TrackedUiState> ToState)
{
	const int32 ToStateIndex = BackHistory->Find(ToState);

	return MoveState(BackHistory, ForwardHistory, ToStateIndex);
}

EHistoryNavigationResult FHistoryManager::MoveStateForwardTo(TSharedPtr<TrackedUiState> ToState)
{
	const int32 ToStateIndex = ForwardHistory->Find(ToState);

	return MoveState(ForwardHistory, BackHistory, ToStateIndex);
}

TSharedPtr<TrackedHistoryArray> FHistoryManager::GetBackHistory() const
{
	return BackHistory;
}

TSharedPtr<TrackedHistoryArray> FHistoryManager::GetForwardHistory() const
{
	return ForwardHistory;
}

bool FHistoryManager::HasBackHistory() const
{
	return BackHistory->Num() > 0;
}

bool FHistoryManager::HasForwardHistory() const
{
	return ForwardHistory->Num() > 0;
}

//////////////////////
/// Private Methods
//////////////////////

void FHistoryManager::OnAssetOpened(UObject* OpenedAsset)
{
	TSharedPtr<UiMonitor> AssetMonitor =
	MonitorFac.ManufactureMonitor(
			this,
			OpenedAsset,
			EditorMonitor::FOnTrackedUiStateChange::CreateSP(
				this,
				&FHistoryManager::RegisterForwardStateChange
			),
			EditorMonitor::FOnTrackedUiEditorClosed::CreateSP(
				this,
				&FHistoryManager::OnEditorClosed
			)
		);
	
	// TODO: Have the factory validate the type before construction
	// if the monitor is null, the user is opening a new map
	if(AssetMonitor)
	{
		AssetMonitor->StartMonitoring();
		Monitors.Emplace(AssetMonitor->GetId(), std::move(AssetMonitor));
	}
}

bool FHistoryManager::IsRestoringState() const
{
	return bRestoringState;
}

void FHistoryManager::OnAssetRemoved(const FAssetData& AssetData)
{
	//UE_LOG(LogTimeMachine, Verbose, TEXT("%s asset removed"), AssetData.AssetName);
	
	auto CleanUpHistoryFunc = [AssetData](TSharedPtr<TrackedHistoryArray>& HistArray) {
		auto NewArray = MakeShared<TrackedHistoryArray>();

		for (TSharedPtr<TrackedUiState>& CurState : *HistArray.Get())
		{
			if (CurState.IsValid() && CurState->GetPath().ToString() != AssetData.ObjectPath.ToString())
			{
				NewArray->Emplace(CurState);
			}
		}

		HistArray = NewArray;
	};

	CleanUpHistoryFunc(BackHistory);
	CleanUpHistoryFunc(ForwardHistory);	
}

void FHistoryManager::CallTabActivatedCallback(TWeakPtr<SDockTab> Tab)
{
	if(LastActivatedTab == Tab) { return; }
	
	UE_LOG(LogTimeMachine, Verbose, TEXT("History manager tab activated callback called"));

	OnTabActivatedCallback* Callback = TabToDelegateMap.Find(Tab);

	if (Callback)
	{
		Callback->ExecuteIfBound(Tab, ETabActivationCause::SetDirectly);
	}

	// Unreal doesn't do a good job in notifying when an asset editor is closed
	for(TTuple<const FGuid, TSharedPtr<UiMonitor>>& MonitorPair : Monitors)
	{
		if(!MonitorPair.Value->StillActive())
		{
			Monitors.Remove(MonitorPair.Key);
		}
	}

	LastActivatedTab = Tab;
}

void FHistoryManager::OnEditorClosed(const FGuid& MonitorId)
{
	UE_LOG(LogTimeMachine, Verbose, TEXT("History manager removing monitor of closed editor"));
	
	Monitors.Remove(MonitorId);
}

EHistoryNavigationResult FHistoryManager::MoveState(TSharedPtr<TrackedHistoryArray>& FromHistory, TSharedPtr<TrackedHistoryArray>& ToHistory, int32 FromIndex)
{
	UE_LOG(LogTimeMachine, Verbose, TEXT("History manager moving state"));
	
	if(FromHistory->Num() == 0) { return EHistoryNavigationResult::Failed; }

	bRestoringState = true;
	
	EHistoryNavigationResult Result = EHistoryNavigationResult::Failed;
	
	if (CurrentState.IsValid())
	{
		ToHistory->Emplace(CurrentState);
	}

	for(int Index = (FromHistory->Num() - 1); Index >= FromIndex; --Index)
	{
		TSharedPtr<TrackedUiState> State = FromHistory->Pop();

		if (Index == FromIndex)
		{
			Result = State->RestoreState();

			CurrentState = State;
		}
		else
		{
			ToHistory->Emplace(State);
		}
	}

	bRestoringState = false;
	
	return Result;
}

void FHistoryManager::RegisterForwardStateChange(const TSharedPtr<TrackedUiState> NewState)
{
	if(NewState == nullptr) { return; }

	if(CurrentState == NewState)
	{
		return;
	}
	
	UE_LOG(
		LogTimeMachine,
		Verbose,
		TEXT("History manager REGISTERING FWD STATE CHANGE for: %s"),
		*NewState->GetTitle().ToString()
	);

	if (CurrentState.IsValid())
	{
		if (BackHistory->Num() == MaxHistory)
		{
			BackHistory->RemoveAt(0, 1, true);
		}

		BackHistory->Emplace(CurrentState);
	}
	CurrentState = NewState;
	ForwardHistory->Empty();
}
