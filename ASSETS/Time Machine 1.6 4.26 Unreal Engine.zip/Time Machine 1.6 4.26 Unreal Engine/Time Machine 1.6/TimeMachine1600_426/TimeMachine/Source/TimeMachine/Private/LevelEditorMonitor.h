﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once
#include "UiMonitor.h"

class LevelEditorMonitor: public UiMonitor
{
public:
    LevelEditorMonitor(
        FHistoryManager* Owner,
        const FOnTrackedUiStateChange& UiChangeCallback
    );

    virtual void StartMonitoring() override;
    virtual FString GetName() override;
protected:
    virtual TSharedPtr<TrackedUiState> BuildUiChangeEvent() override;
};
