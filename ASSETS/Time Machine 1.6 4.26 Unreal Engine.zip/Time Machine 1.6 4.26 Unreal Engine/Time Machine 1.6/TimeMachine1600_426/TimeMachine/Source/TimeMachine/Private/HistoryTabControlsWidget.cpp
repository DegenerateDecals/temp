// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "HistoryTabControlsWidget.h"
#include "AssetToolsModule.h"
#include "HistoryListWidget.h"
#include "MainFrame/Public/Interfaces/IMainFrameModule.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "TimeMachineCommands.h"
#include "TimeMachineStyle.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

HistoryTabControlsWidget::~HistoryTabControlsWidget()
{
	if (FTimeMachineCommands::IsRegistered())
	{
		IMainFrameModule& MainFrame = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>("MainFrame");
		TSharedRef<FUICommandList> MainFrameBindings = MainFrame.GetMainFrameCommandBindings();

		if (MainFrameBindings->IsActionMapped(FTimeMachineCommands::Get().OpenBackHistoryMenu))
		{
			MainFrameBindings->UnmapAction(FTimeMachineCommands::Get().OpenBackHistoryMenu);
		}

		if (MainFrameBindings->IsActionMapped(FTimeMachineCommands::Get().OpenForwardHistoryMenu))
		{
			MainFrameBindings->UnmapAction(FTimeMachineCommands::Get().OpenForwardHistoryMenu);
		}
	}

	HistManager->UnbindTabActivatedAction(OwnerTab);
}

TSharedRef<HistoryTabControlsWidget> HistoryTabControlsWidget::CreateControls(
	TWeakPtr<SDockTab> OwnerTab,
	TSharedPtr<FHistoryManager> Manager,
	bool bShowBtnText
)
{
	return SNew(HistoryTabControlsWidget)
			.HistManager(Manager)
			.OwnerTab(OwnerTab)
			.bShowButtonText(bShowBtnText);
}

void HistoryTabControlsWidget::Construct(const FArguments& InArgs)
{
	HistManager = InArgs._HistManager;
	OwnerTab = InArgs._OwnerTab;
	bShowButtonText = InArgs._bShowButtonText;
	
	HistManager->BindTabActivatedAction(
		OwnerTab, 
		FHistoryManager::OnTabActivatedCallback::CreateRaw(this, &HistoryTabControlsWidget::OnTabActivated)
	);
	
	ChildSlot
		[
			SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				.VAlign(VAlign_Center)
				.AutoWidth()
				[
					SAssignNew(BackButton, SButton)
						.IsEnabled_Raw(HistManager.Get(), &FHistoryManager::HasBackHistory)
						.OnClicked_Lambda([this]() { HistManager->MoveStateBack(); return FReply::Handled(); })
						.IsFocusable(false)
						.ButtonStyle(FTimeMachineStyle::Get(), TimeMachineStyles::WellButtons::TabWellButtons)
						.ContentPadding(FMargin(0.0f, 5.0f))
						[
							SNew(SHorizontalBox)
							+SHorizontalBox::Slot()
								.VAlign(VAlign_Center)
								.Padding(1.5f, 0.0f, 5.0f, 0.0f)
								.AutoWidth()
								[
									SNew(SImage) 
									.Image_Lambda([this]() 
										{ 
											return BackButton->IsHovered() ? 
													FTimeMachineStyle::GetBrush(TimeMachineStyles::WellButtons::BackArrow_Black) : 
													FTimeMachineStyle::GetBrush(TimeMachineStyles::WellButtons::BackArrow);
										}
									)
								]
							+ SHorizontalBox::Slot()
								.VAlign(VAlign_Center)
								.Padding(3.0f, 0.5f, 2.5f, 0.0f)
								.AutoWidth()
								[
									SNew(STextBlock)
									.Visibility(bShowButtonText ? EVisibility::Visible : EVisibility::Collapsed)
									.Text(LOCTEXT("Back", "Back"))
									.ColorAndOpacity_Lambda([this]() { return FSlateColor(BackButton->IsHovered() ? FLinearColor::Black : FLinearColor::White); })
								]
						]
				]
				+ SHorizontalBox::Slot()
					.VAlign(VAlign_Center)
					.AutoWidth()
					[
						SAssignNew(BackMenuButton, SComboButton)
							.IsEnabled_Raw(HistManager.Get(), &FHistoryManager::HasBackHistory)
							.IsFocusable(true)
							.ContentPadding(FMargin(2.5f, 5.0f))
							.ButtonStyle(FTimeMachineStyle::Get(), TimeMachineStyles::WellButtons::TabWellButtons)
							.ForegroundColor_Lambda([&]() { return BackMenuButton->IsHovered() ? FSlateColor(FLinearColor::Black) : FSlateColor(FLinearColor::White); })
							.OnGetMenuContent(this, &HistoryTabControlsWidget::GetHistoryMenu, true)
					]
				+ SHorizontalBox::Slot()
					.VAlign(VAlign_Center)
					.AutoWidth()
					[
						SAssignNew(FwdMenuButton, SComboButton)
							.IsEnabled_Raw(HistManager.Get(), &FHistoryManager::HasForwardHistory)
							.IsFocusable(true)
							.ContentPadding(FMargin(2.5f, 5.0f))
							.ButtonStyle(FTimeMachineStyle::Get(), TimeMachineStyles::WellButtons::TabWellButtons)
							.ForegroundColor_Lambda([&]() { return FwdMenuButton->IsHovered() ? FSlateColor(FLinearColor::Black) : FSlateColor(FLinearColor::White); })
							.OnGetMenuContent(this, &HistoryTabControlsWidget::GetHistoryMenu, false)
					]
				+ SHorizontalBox::Slot()
					.VAlign(VAlign_Center)
					.Padding(0.0f)
					.AutoWidth()
					[
						SAssignNew(FwdButton, SButton)
							.IsEnabled_Raw(HistManager.Get(), &FHistoryManager::HasForwardHistory)
							.OnClicked_Lambda([this]() { HistManager->MoveStateForward(); return FReply::Handled(); })
							.IsFocusable(false)
							.ButtonStyle(FTimeMachineStyle::Get(), TimeMachineStyles::WellButtons::TabWellButtons)
							.ContentPadding(FMargin(0.0f, 5.0f))
							[
							
								SNew(SHorizontalBox)
								+SHorizontalBox::Slot()
									.VAlign(VAlign_Center)
									.Padding(2.5f, 0.5f, 3.0f, 0.0f)
									.AutoWidth()
									[
										SNew(STextBlock)
										.Visibility(bShowButtonText ? EVisibility::Visible : EVisibility::Collapsed)
										.Text(LOCTEXT("Forward", "Forward"))
										.ColorAndOpacity_Lambda([this]() { return FSlateColor(FwdButton->IsHovered() ? FLinearColor::Black : FLinearColor::White); })
									]
								+ SHorizontalBox::Slot()
									.VAlign(VAlign_Center)
									.Padding(5.0f, 0.0f, 1.5f, 0.0f)
									.AutoWidth()
									[
										SNew(SImage)
										.Image_Lambda([this]()
											{
												return FwdButton->IsHovered() ?
													FTimeMachineStyle::GetBrush(TimeMachineStyles::WellButtons::FwdArrow_Black) :
													FTimeMachineStyle::GetBrush(TimeMachineStyles::WellButtons::FwdArrow);
											}
										)
									]
							]
					]
		];
	
		BindGlobalActions();
}

TSharedRef<SWidget> HistoryTabControlsWidget::GetHistoryMenu(bool bBackHist)
{
	const TSharedPtr<TrackedHistoryArray> History = bBackHist ? HistManager->GetBackHistory() : HistManager->GetForwardHistory();

	return SHistoryListWidget::CreateMenu(
		History,
		SHistoryListWidget::FOnHistoryItemSelected::CreateRaw(this, &HistoryTabControlsWidget::OnHistoryItemSelected, bBackHist),
		SHistoryListWidget::HistoryListWidgetCloseDel::CreateLambda([this, bBackHist]() {
			
				const TSharedPtr<SComboButton> Parent = bBackHist ? BackMenuButton : FwdMenuButton;
			
				Parent->SetIsOpen(false, false);
		})
	);
}

void HistoryTabControlsWidget::BindGlobalActions()
{
	IMainFrameModule& MainFrame = FModuleManager::Get().LoadModuleChecked<IMainFrameModule>("MainFrame");
	TSharedRef<FUICommandList> MainFrameBindings = MainFrame.GetMainFrameCommandBindings();

	if (MainFrameBindings->IsActionMapped(FTimeMachineCommands::Get().OpenBackHistoryMenu))
	{
		MainFrame.GetMainFrameCommandBindings()->UnmapAction(FTimeMachineCommands::Get().OpenBackHistoryMenu);
	}

	// TODO: Cleanup with better bindings
	MainFrameBindings->MapAction(
		FTimeMachineCommands::Get().OpenBackHistoryMenu,
		FExecuteAction::CreateLambda([&]()
		{
			BackMenuButton->SetIsOpen(true, true, 0);
		}),
		FCanExecuteAction::CreateRaw(HistManager.Get(), &FHistoryManager::HasBackHistory)
	);

	if (MainFrameBindings->IsActionMapped(FTimeMachineCommands::Get().OpenForwardHistoryMenu))
	{
		MainFrame.GetMainFrameCommandBindings()->UnmapAction(FTimeMachineCommands::Get().OpenForwardHistoryMenu);
	}

	MainFrameBindings->MapAction(
		FTimeMachineCommands::Get().OpenForwardHistoryMenu,
		FExecuteAction::CreateLambda([&]()
		{
			FwdMenuButton->SetIsOpen(true, true, 0);
		}),
		FCanExecuteAction::CreateRaw(HistManager.Get(), &FHistoryManager::HasForwardHistory)
	);
}

void HistoryTabControlsWidget::OnTabActivated(TWeakPtr<SDockTab> Tab, ETabActivationCause Cause)
{
	BindGlobalActions();
}

// TODO: Handle Response
void HistoryTabControlsWidget::OnHistoryItemSelected(TSharedPtr<TrackedUiState> SelectedHistoryItem, bool bBackHist) const
{
	if (bBackHist)
	{
		HistManager->MoveStateBackTo(SelectedHistoryItem);
	}
	else
	{
		HistManager->MoveStateForwardTo(SelectedHistoryItem);
	}
}

#undef LOCTEXT_NAMESPACE
