﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#include "UiMonitor.h"


#include "AssetTypeCategories.h"
#include "HistoryManager.h"

UiMonitor::UiMonitor(
    FHistoryManager* Owner,
    const FOnTrackedUiStateChange& UiChangeCallback):
MonitorId(FGuid::NewGuid()),
bIsCurrentFocus(true),
bStateBeingRestored(false),
Manager(Owner),
UiChangeCallback(UiChangeCallback)
{
}

UiMonitor::~UiMonitor()
{
   if(TabActivatedCallback.IsBound()) { TabActivatedCallback.Unbind(); }
}

FGuid UiMonitor::GetId() const
{
    return MonitorId;
}

bool UiMonitor::StillActive() const
{
    return UiTab.IsValid();
}

void UiMonitor::StartMonitoring()
{
    GlobalTabActivatedHandle = Manager->OnGlobalTabActivated.AddSP(this, &UiMonitor::OnGlobalTabActivated);

    FGlobalTabmanager::Get()->OnTabForegrounded_Subscribe(
        FOnActiveTabChanged::FDelegate::CreateSP(
            this,
            &UiMonitor::OnAnyTabForegroundedAssetTracking
        )
    );
    
}

void UiMonitor::BindUiTab(TWeakPtr<SDockTab> Tab)
{
    UiTab = Tab;

    TabActivatedCallback = SDockTab::FOnTabActivatedCallback::CreateSP(this, &UiMonitor::OnUiTabActivated);
    
    UiTab.Pin()->SetOnTabActivated(TabActivatedCallback);

    Manager->OnGlobalTabActivated.Broadcast(UiTab);
}

ECursorLocation UiMonitor::GetCursorLocation()
{
     FSlateApplication& SlateApp = FSlateApplication::Get();

     const FWidgetPath WidgetsUnderCursor = SlateApp.LocateWindowUnderMouse( SlateApp.GetCursorPos(), SlateApp.GetInteractiveTopLevelWindows() );

     auto result = ECursorLocation::Valid;
    
     if ( WidgetsUnderCursor.IsValid() )
     {
         FArrangedChildren AllChildren = WidgetsUnderCursor.Widgets;
         
         for ( int32 Idx = 0; Idx < AllChildren.Num(); ++Idx )
         {
             const TSharedRef<SWidget> Widget = AllChildren[Idx].Widget;

             if(Widget->GetType() == "HistoryTabControlsWidget")
             {
                 result = ECursorLocation::HistoryControls;
                 break;
             }
             
             if( // Tab Close button
                 Widget->GetType() == "SDockTab"
                 && (Idx - AllChildren.Num() == 3)
                 && AllChildren[Idx + 1].Widget->GetType() == "SOverlay"
                 && AllChildren[Idx + 2].Widget->GetType() == "SHorizontalBox"
                 && AllChildren[Idx + 3].Widget->GetType() == "SButton"
             )
             {  
                result = ECursorLocation::TabCloseBtn;
                break;
             }
         }
     }

	UE_LOG(
	    LogTimeMachine,
	    Verbose,
	    TEXT("%s UI monitor checked if cursor was over history controls: %s"),
	    *GetName(),
	    result ? TEXT("True") : TEXT("False")
	);

    return result;
}

void UiMonitor::OnGlobalTabActivated(const TWeakPtr<SDockTab> ActTab)
{   
    if(ActTab == UiTab) 
    {
        bIsCurrentFocus = true;
    }
    else
    {
        bIsCurrentFocus = false;
    }

    UE_LOG(
        LogTimeMachine,
        Verbose,
        TEXT("%s UI monitor Global tab activated called  // Focused: %s "),
        *GetName(),
        bIsCurrentFocus ? TEXT("True") : TEXT("False")
    );
}

void UiMonitor::CallUiChangeCallback() 
{
    if(Manager->IsRestoringState()) { return; }

    UiChangeCallback.ExecuteIfBound(BuildUiChangeEvent());
}

void UiMonitor::OnAnyTabForegroundedAssetTracking(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab> OldTab)
{
    OnUiTabActivated(NewTab.ToSharedRef(), ETabActivationCause::SetDirectly);
}

void UiMonitor::OnUiTabActivated(TSharedRef<SDockTab> ActivatedTab, ETabActivationCause Cause)
{
    if(ActivatedTab != UiTab)  { return; }
    
    const ECursorLocation CursorLocation = GetCursorLocation();

    UE_LOG(
	    LogTimeMachine,
	    Verbose,
	    TEXT("%s UI monitor tab activated // Focused: %s | Restoring: %s | Cursor: %s"),
	    *GetName(),
	    bIsCurrentFocus ? TEXT("True") : TEXT("False"),
	    bStateBeingRestored ? TEXT("True") : TEXT("False"),
	    CursorLocation == Valid ? TEXT("Valid") : TEXT("NOT Valid")
	);

    if(!bStateBeingRestored && !bIsCurrentFocus && CursorLocation == ECursorLocation::Valid)
    {
		UE_LOG(LogTimeMachine, Verbose, TEXT("%s UI monitor triggering UI change event"), *GetName());
        
        CallUiChangeCallback();
    }

    Manager->OnGlobalTabActivated.Broadcast(UiTab);
}
