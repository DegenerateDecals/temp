﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#include "MonitorFactory.h"

#include "Consts.h"
#include "AssetEditorResolver.h"
#include "BasicAssetEditorMonitor.h"
#include "BlueprintEditorMonitor.h"
#include "WidgetBlueprintEditorMonitor.h"
#include "UMGEditor/Public/WidgetBlueprintEditor.h"

#if IS_PRO == true

namespace 
{
	const TSet<FName> BlueprintBasedEditorNames = TSet<FName>({
		"AnimationBlueprintEditor",
		"BlueprintEditor",
	});
}

#endif

TSharedPtr<EditorMonitor> MonitorFactory::ManufactureMonitor(
    FHistoryManager* Owner,
	UObject* ForObject,
	EditorMonitor::FOnTrackedUiStateChange UiChangeCallback,
	EditorMonitor::FOnTrackedUiEditorClosed UiEditorClosedCallback
) const
{
	IAssetEditorInstance* OpenedAssetEditor = AssetEditorResolver::GetEditorForAsset(ForObject);

	if (OpenedAssetEditor == nullptr) { return nullptr; }
	
#if IS_PRO == true
	
	if(ForObject->GetClass()->GetName() == "WidgetBlueprint")
	{
		return MakeShared<WidgetBlueprintEditorMonitor>(
			Owner,
			ForObject,
			OpenedAssetEditor,
			UiChangeCallback,
			UiEditorClosedCallback
		);
	}
	
	if (BlueprintBasedEditorNames.Contains(OpenedAssetEditor->GetEditorName()))
	{
		return MakeShared<BlueprintEditorMonitor>(
			Owner,
			ForObject,
			OpenedAssetEditor,
			UiChangeCallback,
			UiEditorClosedCallback
		);    
	}
	
#endif
	
    return MakeShared<BasicAssetEditorMonitor>(Owner, ForObject, OpenedAssetEditor, UiChangeCallback, UiEditorClosedCallback);    
}
