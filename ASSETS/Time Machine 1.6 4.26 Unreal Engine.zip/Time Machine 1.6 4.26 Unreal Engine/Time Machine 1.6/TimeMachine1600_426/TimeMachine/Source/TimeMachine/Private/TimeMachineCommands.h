// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "CoreMinimal.h"
#include "Framework/Commands/Commands.h"
#include "TimeMachineStyle.h"

class FTimeMachineCommands : public TCommands<FTimeMachineCommands>
{
public:

	FTimeMachineCommands()
		: TCommands<FTimeMachineCommands>(
			TEXT("TimeMachine"),
			NSLOCTEXT("Contexts", "TimeMachine", "TimeMachine Plugin"),
			NAME_None,
			FTimeMachineStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

public:
	TSharedPtr< FUICommandInfo > MoveBackInHistory;
	TSharedPtr< FUICommandInfo > MoveForwardInHistory;
	TSharedPtr< FUICommandInfo > OpenBackHistoryMenu;
	TSharedPtr< FUICommandInfo > OpenReleaseNotes;
	TSharedPtr< FUICommandInfo > OpenForwardHistoryMenu;
};
