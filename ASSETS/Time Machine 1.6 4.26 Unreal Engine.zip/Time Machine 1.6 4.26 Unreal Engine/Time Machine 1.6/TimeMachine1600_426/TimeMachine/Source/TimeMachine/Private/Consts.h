﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#ifndef TIME_MACHINE_CONSTS

#define PLUGIN_NAME "TimeMachine"
#define IS_PRO true 

#define PRO_PRODUCT_ID "3f89049c41fa4fedbe03e8afbf4ac5b3"

#if IS_PRO == true
    #define PRODUCT_ID "3f89049c41fa4fedbe03e8afbf4ac5b3"
#else
    #define PRODUCT_ID "8f9fb22542fd4415a712dc1bbbd99628"
#endif



#define PRO_URL "com.epicgames.launcher://ue/marketplace/product/3f89049c41fa4fedbe03e8afbf4ac5b3"

#define TIME_MACHINE_CONSTS

#endif
