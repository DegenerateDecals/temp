// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "Engine/DeveloperSettings.h"
#include "TimeMachineSettings.generated.h"

// DELETE with Free
UENUM()
enum ETimeMachineControls
{
	Default		UMETA(DisplayName = "Default"),
	NoText 		UMETA(DisplayName = "Arrow buttons with no text"),
	NoControls	UMETA(DisplayName = "No controls - Hotkeys only")
};

UCLASS(config=TimeMachine, defaultconfig, meta=(DisplayName="Time Machine"))
class UTimeMachineSettings : public UDeveloperSettings
{
private:
	GENERATED_UCLASS_BODY()

public:
	virtual FName GetCategoryName() const override;
#if WITH_EDITOR
	virtual FText GetSectionText() const override;
#endif

	// DELETE with Free
	UPROPERTY(config=TimeMachine, EditAnywhere, DisplayName="Control display (Pro only feature)", Category="General")
    TEnumAsByte<ETimeMachineControls> Controls;
	
	// History Tracking
	UPROPERTY(config=TimeMachine, EditAnywhere, DisplayName="Track level editor focus changes", Category="History Tracking")
	bool bTrackLevelEditorFocus;
	
	UPROPERTY(config=TimeMachine, EditAnywhere, DisplayName="The maximum number of history changes to track", Category="History Tracking")
	uint32 MaxHistory;
};

