// Copyright 2020 Christopher Venturini - All Rights Reserved.

using UnrealBuildTool;

public class TimeMachine : ModuleRules
{
	public TimeMachine(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bLegacyPublicIncludePaths = true;
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
			}
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
			
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				// ... add other public dependencies that you statically link with here ...
				"AnimationBlueprintEditor",
				"BehaviorTreeEditor",
				"Core",
				"CoreUObject",
				"DeveloperSettings",
				"Engine",
				"EditorStyle",
				"HTTP",
				"InputCore",
				"Json",
				"JsonUtilities",
				"Kismet",
				"LevelEditor",
				"Projects",
				"Slate",
				"SlateCore",
				"SSL",
				"UMGEditor",
				"UnrealEd",
				"WebBrowser",
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);
		
	}
}
