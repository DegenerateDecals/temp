﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "TimeMachineLogging.h"
#include "TrackedUiState.h"

class FHistoryManager;

enum ECursorLocation : uint8
{
    Valid,
    HistoryControls,
    TabCloseBtn
};

class UiMonitor : public TSharedFromThis<UiMonitor> 
{
public:
    DECLARE_DELEGATE_OneParam(FOnTrackedUiStateChange, const TSharedPtr<TrackedUiState>);
    
    UiMonitor(FHistoryManager* Owner, const FOnTrackedUiStateChange& UiChangeCallback);

    virtual ~UiMonitor();

    friend bool operator==(const UiMonitor& Lhs, const UiMonitor& RHS)
    {
        return Lhs.UiTab == RHS.UiTab
            && Lhs.bStateBeingRestored == RHS.bStateBeingRestored;
    }

    friend bool operator!=(const UiMonitor& Lhs, const UiMonitor& RHS)
    {
        return !(Lhs == RHS);
    }

    FGuid GetId() const;
    
    bool StillActive() const;
    
    virtual FString GetName() = 0;
    
    virtual void StartMonitoring();

protected:
    virtual void BindUiTab(TWeakPtr<SDockTab> Tab);

    ECursorLocation GetCursorLocation();

    virtual void OnGlobalTabActivated(const TWeakPtr<SDockTab> ActTab);

    void CallUiChangeCallback();

    // Handle the tab switching from workflows like opening a function on an already opened asset
    void OnAnyTabForegroundedAssetTracking(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab> OldTab);

    // Handle the user clicking 
    virtual void OnUiTabActivated(TSharedRef<SDockTab> ActivatedTab, ETabActivationCause Cause);
    
    virtual TSharedPtr<TrackedUiState> BuildUiChangeEvent() = 0;

    ///////////////////
    ///     Members
    ///////////////////
    FGuid MonitorId;
    
    TWeakPtr<SDockTab> UiTab;
    bool bIsCurrentFocus = true;
    bool bStateBeingRestored = false;

    FHistoryManager* Manager;
    FDelegateHandle ForwardStateChangeHandle;
    FDelegateHandle GlobalTabActivatedHandle;

    // Callbacks
    FOnTrackedUiStateChange UiChangeCallback;

    SDockTab::FOnTabActivatedCallback TabActivatedCallback;
};


