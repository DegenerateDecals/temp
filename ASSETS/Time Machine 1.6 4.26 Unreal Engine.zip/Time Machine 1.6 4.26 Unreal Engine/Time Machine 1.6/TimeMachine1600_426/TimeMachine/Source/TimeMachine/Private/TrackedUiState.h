// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once
#include "EdGraph/EdGraph.h"
#include "Runtime/CoreUObject/Public/UObject/ObjectKey.h"

class FTabManager;
class SDockTab;
class UiMonitor;

enum EHistoryNavigationResult : uint8 
{
	Failed,
	Success,
	AssetDoesNotExist,
	BlueprintGraphMissing,
};

// Base Abstract Class
class TrackedUiState  
{
public:
	virtual ~TrackedUiState() = default;
	virtual EHistoryNavigationResult RestoreState() = 0;
	virtual FText GetTitle() = 0;
	virtual FText GetPath() = 0;
	virtual FText GetInfo() = 0;
	virtual bool IsNavigable();

protected:
	TrackedUiState() = default;
	virtual TWeakPtr<SDockTab> GetTabFromManager(TSharedPtr<FTabManager> Manager);

	TWeakPtr<UiMonitor> RelatedMonitor;
};

using TrackedHistoryArray = TArray<TSharedPtr<TrackedUiState>>;

// For Asset Editors
class AssetEditorUiState : public TrackedUiState
{
	friend bool operator==(const AssetEditorUiState& Lhs, const AssetEditorUiState& RHS)
	{
		return Lhs.AssetKey == RHS.AssetKey;
	}

	friend bool operator!=(const AssetEditorUiState& Lhs, const AssetEditorUiState& RHS)
	{
		return !(Lhs == RHS);
	}

public:
	AssetEditorUiState(UObject* RelatedAsset):
		AssetKey(RelatedAsset)
	{
	};

	virtual EHistoryNavigationResult RestoreState() override;
	virtual FText GetTitle() override;
	virtual FText GetPath() override;
	virtual FText GetInfo() override;
	virtual bool IsNavigable() override;

protected:
	FObjectKey AssetKey;
};

class BlueprintNongraphModeUiState : public AssetEditorUiState
{
	friend bool operator==(const BlueprintNongraphModeUiState& Lhs, const BlueprintNongraphModeUiState& RHS)
	{
		return static_cast<const AssetEditorUiState&>(Lhs) == static_cast<const AssetEditorUiState&>(RHS)
			&& Lhs.Mode == RHS.Mode;
	}

	friend bool operator!=(const BlueprintNongraphModeUiState& Lhs, const BlueprintNongraphModeUiState& RHS)
	{
		return !(Lhs == RHS);
	}

public:
	BlueprintNongraphModeUiState(
    		UObject* RelatedAsset,
    		const FName& StateMode
    	):
        	AssetEditorUiState(RelatedAsset),
    		Mode(std::move(StateMode))
    	{
    	};
    	
    virtual EHistoryNavigationResult RestoreState() override;
    virtual FText GetInfo() override;
	
private:
	FName Mode;
};

class BlueprintGraphUiState : public AssetEditorUiState 
{
	friend bool operator==(const BlueprintGraphUiState& Lhs, const BlueprintGraphUiState& RHS)
	{
		return Lhs.AssetKey == RHS.AssetKey
			&& Lhs.Mode == RHS.Mode
			&& Lhs.DocId == RHS.DocId;
	}

	friend bool operator!=(const BlueprintGraphUiState& Lhs, const BlueprintGraphUiState& RHS)
	{
		return !(Lhs == RHS);
	}

public:
	BlueprintGraphUiState(
		UObject* RelatedAsset,
		FName StateMode,
		FGuid RelatedDocId
	):
    	AssetEditorUiState(RelatedAsset),
		Mode(StateMode)
	{
		DocId = FGuid(RelatedDocId);
	};

	virtual EHistoryNavigationResult RestoreState() override;
	virtual FText GetInfo() override;
	
protected:
	UEdGraph* GetGraph() const;
	FName Mode;
	FGuid DocId;
};

class BlueprintTimelineUiState : public AssetEditorUiState
{
	friend bool operator==(const BlueprintTimelineUiState& Lhs, const BlueprintTimelineUiState& RHS)
	{
		return static_cast<const AssetEditorUiState&>(Lhs) == static_cast<const AssetEditorUiState&>(RHS)
			&& Lhs.TimelineId == RHS.TimelineId;
	}

	friend bool operator!=(const BlueprintTimelineUiState& Lhs, const BlueprintTimelineUiState& RHS)
	{
		return !(Lhs == RHS);
	}

public:
	BlueprintTimelineUiState(UObject* RelatedAsset, const FGuid& TimelineId)
		: AssetEditorUiState(RelatedAsset),
		TimelineId(TimelineId)
	{
	}

	virtual EHistoryNavigationResult RestoreState() override;
	virtual FText GetInfo() override;
private:
	FGuid TimelineId;
	
	UTimelineTemplate* GetTimeline() const;
};


class BlueprintViewportState : public AssetEditorUiState 
{
public:
	BlueprintViewportState(UObject* RelatedAsset):
		AssetEditorUiState(RelatedAsset)
	{};
	
	virtual EHistoryNavigationResult RestoreState() override;
	virtual FText GetInfo() override;
};

// For the level editor
class LevelEditorUiState : public TrackedUiState
{
public:
	virtual EHistoryNavigationResult RestoreState() override;
	virtual FText GetTitle() override;
	virtual FText GetPath() override;
	virtual FText GetInfo() override;
};



