﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once
#include "Editor/UnrealEd/Public/Toolkits/AssetEditorManager.h"

class AssetEditorResolver
{
public:
    static IAssetEditorInstance* GetEditorForAsset(UObject* Asset);
};
