﻿#include "WidgetBlueprintEditorMonitor.h"

WidgetBlueprintEditorMonitor::WidgetBlueprintEditorMonitor(FHistoryManager* Owner, UObject* TrackedObj,
    IAssetEditorInstance* AssetEditor, const FOnTrackedUiStateChange& UiChangeCallback,
    const FOnTrackedUiEditorClosed& UiEditorClosedCallback)
    : BlueprintEditorMonitor(Owner, TrackedObj, AssetEditor, UiChangeCallback, UiEditorClosedCallback),
	CurrentWidgetBlueprintEditor(static_cast<FWidgetBlueprintEditor*>(AssetEditor))
{
}

void WidgetBlueprintEditorMonitor::StartMonitoring()
{
	BlueprintEditorMonitor::StartMonitoring();

	CurrentWidgetBlueprintEditor->OnEnterWidgetDesigner.AddSP(this, &WidgetBlueprintEditorMonitor::OnEnteringWidgetDesigner);
}

void WidgetBlueprintEditorMonitor::OnEnteringWidgetDesigner()
{
	BindEditor();
}
