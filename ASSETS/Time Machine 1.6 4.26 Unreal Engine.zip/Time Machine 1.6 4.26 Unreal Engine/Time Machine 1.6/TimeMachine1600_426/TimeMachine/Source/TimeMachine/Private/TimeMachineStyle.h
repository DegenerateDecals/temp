// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateStyle.h"

namespace TimeMachineStyles
{
	namespace WellButtons
	{
		const FName BackArrow("TimeMachine.BackArrow");
    	const FName BackArrow_Black("TimeMachine.BackArrow.Black");
    	
    	const FName FwdArrow("TimeMachine.FwdArrow");
    	const FName FwdArrow_Black("TimeMachine.FwdArrow.Black");
    
    	const FName TabWellButtons("TimeMachine.TabWellButtons");	
	}

};

class FTimeMachineStyle
{
public:
	

	static void Initialize();

	static void Shutdown();

	static void ReloadTextures();

	static const ISlateStyle& Get();
	
	static const FSlateBrush* GetBrush(const FName PropertyName);

	static FName GetStyleSetName();

private:

	static TSharedRef< class FSlateStyleSet > Create();

private:

	static TSharedPtr< class FSlateStyleSet > StyleInstance;
};