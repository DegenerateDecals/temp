// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "TrackedUiState.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SCompoundWidget.h"
#include "HistoryManager.h"

class HistoryTabControlsWidget : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(HistoryTabControlsWidget):
		_HistManager(),
		_OwnerTab(),
		_bShowButtonText()
	{}
		SLATE_ARGUMENT(TSharedPtr<FHistoryManager>, HistManager)
		SLATE_ARGUMENT(TWeakPtr<SDockTab>, OwnerTab)
		SLATE_ARGUMENT(bool, bShowButtonText)
	SLATE_END_ARGS()

	virtual ~HistoryTabControlsWidget();

	static TSharedRef<HistoryTabControlsWidget> CreateControls(
		TWeakPtr<SDockTab> OwnerTab,
		TSharedPtr<FHistoryManager> Manager,
		bool bShowBtnText
	);

	void Construct(const FArguments& InArgs);

private:
	void BindGlobalActions();

	TSharedRef<SWidget> GetHistoryMenu(bool bBackHist);

	void OnTabActivated(TWeakPtr<SDockTab> Tab, ETabActivationCause Cause);

	void OnHistoryItemSelected(TSharedPtr<TrackedUiState> SelectedHistoryItem, bool bBackHist) const;
	
	bool bShowButtonText = true;
	FDelegateHandle TabActivatedHandle;
	TSharedPtr<FHistoryManager> HistManager;
	TSharedPtr<SComboButton> BackMenuButton;
	TSharedPtr<SButton> BackButton;
	TSharedPtr<SComboButton> FwdMenuButton;
	TSharedPtr<SButton> FwdButton;
	TWeakPtr<SDockTab> OwnerTab;
};
