// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

#include "MonitorFactory.h"
#include "TrackedUiState.h"

enum ETabActivationCause : unsigned char;

class FHistoryManager : public TSharedFromThis<FHistoryManager>
{
public:
	DECLARE_DELEGATE_TwoParams(OnTabActivatedCallback, TWeakPtr<SDockTab>, ETabActivationCause)
    DECLARE_MULTICAST_DELEGATE_OneParam(FOnGobalTabActivated, const TWeakPtr<SDockTab>);
	
	FHistoryManager(bool bTrackLevelEditorFocus, uint32 MaxHistorySize, MonitorFactory Factory = MonitorFactory());

	void Init();

	void BindTabActivatedAction(TWeakPtr<SDockTab> Tab, OnTabActivatedCallback Action);
	
	void UnbindTabActivatedAction(TWeakPtr<SDockTab> Tab);

	EHistoryNavigationResult MoveStateBack();

	EHistoryNavigationResult MoveStateBackTo(TSharedPtr<TrackedUiState> ToState);

	EHistoryNavigationResult MoveStateForward();

	EHistoryNavigationResult MoveStateForwardTo(TSharedPtr<TrackedUiState> ToState);

	TSharedPtr<TrackedHistoryArray> GetBackHistory() const;
	
	TSharedPtr<TrackedHistoryArray> GetForwardHistory() const;

	bool HasBackHistory() const;

	bool HasForwardHistory() const;

	void OnAssetOpened(UObject* OpenedAsset);

	bool IsRestoringState() const;
	
	FOnGobalTabActivated OnGlobalTabActivated;
private:
	void OnAssetRemoved(const FAssetData& AssetData);
	
	void CallTabActivatedCallback(TWeakPtr<SDockTab> Tab);

	void OnEditorClosed(const FGuid& MonitorId);
	
	EHistoryNavigationResult MoveState(TSharedPtr<TrackedHistoryArray>& FromHistory, TSharedPtr<TrackedHistoryArray>& ToHistory, int32 FromIndex);

	void RegisterForwardStateChange(const TSharedPtr<TrackedUiState> NewState);

	// Members
	TSharedPtr<TrackedHistoryArray> BackHistory;
	TSharedPtr<TrackedUiState> CurrentState;
	TSharedPtr<TrackedHistoryArray> ForwardHistory;

	uint32 MaxHistory;
	uint32 ModeChangeIgnoreCount;
	bool bRestoringState;
	bool bTrackLevelEditorFocus;
	
	MonitorFactory MonitorFac;
	TMap<const FGuid, TSharedPtr<UiMonitor>> Monitors;
	
	TWeakPtr<SDockTab> LastActivatedTab;
	TMap<TWeakPtr<SDockTab>, OnTabActivatedCallback> TabToDelegateMap;
};
