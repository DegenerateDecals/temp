// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachineSettings.h"

UTimeMachineSettings::UTimeMachineSettings(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer),
	  Controls(Default),
	  bTrackLevelEditorFocus(true),
	  MaxHistory(200)
{
}

FName UTimeMachineSettings::GetCategoryName() const
{
	return TEXT("Plugins");
}

FText UTimeMachineSettings::GetSectionText() const
{
	return NSLOCTEXT("TimeMachine", "TimeMachineSettingsSection", "Time Machine");
}
