﻿#include "HistoryListPopup.h"


#include "SButton.h"
#include "SlateApplication.h"
#include "SWindow.h"

void SHistoryListPopup::DisplayMenu(
	FText Title,
	TSharedPtr<TrackedHistoryArray> TrackedHistory,
    SHistoryListWidget::FOnHistoryItemSelected OnHistoryItemSel
)
{
	TSharedPtr<SWindow> Window = SNew(SWindow)
						.Title(Title)
						.SupportsMaximize(false)
						.SupportsMinimize(false)
						.HasCloseButton(true)
						.bDragAnywhere(false)
						.IsTopmostWindow(true)
						.FocusWhenFirstShown(true)
						.AutoCenter(EAutoCenter::PreferredWorkArea)
						.MinWidth(300.0f)
						.MinHeight(300.0f);

	const auto CloseDel = SHistoryListWidget::HistoryListWidgetCloseDel::CreateLambda([Window]()
	{
		Window->RequestDestroyWindow();
	});
	
	const auto HistoryListWidget = SNew(SHistoryListWidget)
								.TrackedHistory(TrackedHistory)
								.OnHistoryItemSelected(OnHistoryItemSel)
								.OnClose(CloseDel);
	
	Window->SetContent(HistoryListWidget);
	FSlateApplication::Get().AddWindow(Window.ToSharedRef());
}


