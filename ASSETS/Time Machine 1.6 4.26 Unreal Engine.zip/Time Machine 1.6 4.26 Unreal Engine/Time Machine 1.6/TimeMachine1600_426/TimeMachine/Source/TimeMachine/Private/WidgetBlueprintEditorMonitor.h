﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "BlueprintEditorMonitor.h"
#include "WidgetBlueprintEditor.h"

class WidgetBlueprintEditorMonitor : public BlueprintEditorMonitor
{
public:
    WidgetBlueprintEditorMonitor(FHistoryManager* Owner, UObject* TrackedObj, IAssetEditorInstance* AssetEditor,
        const FOnTrackedUiStateChange& UiChangeCallback, const FOnTrackedUiEditorClosed& UiEditorClosedCallback);

   virtual void StartMonitoring() override;
    
private:
    void OnEnteringWidgetDesigner();
    
    FWidgetBlueprintEditor* CurrentWidgetBlueprintEditor;
};
