﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#pragma once

DECLARE_LOG_CATEGORY_CLASS(LogTimeMachine, Verbose, All);

