// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TrackedUiState.h"
#include "Launch/Resources/Version.h"
#include "AssetEditorResolver.h"
#include "BlueprintEditor.h"
#include "BlueprintEditorModes.h"
#include "Editor/Kismet/Public/BlueprintEditorTabs.h"
#include "Editor/Kismet/Public/WorkflowOrientedApp/WorkflowUObjectDocuments.h"
#include "Editor/LevelEditor/Public/LevelEditor.h"
#include "Engine/TimelineTemplate.h"
#include "MainFrame/Public/Interfaces/IMainFrameModule.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

/**********************
	TrackedUiState Abstract Class
***********************/

TWeakPtr<SDockTab> TrackedUiState::GetTabFromManager(TSharedPtr<FTabManager> Manager)
{
	return FGlobalTabmanager::Get()->GetMajorTabForTabManager(Manager.ToSharedRef());
}

bool TrackedUiState::IsNavigable()
{
	return true;
}

/**********************
	AssetEditorUiState
***********************/

EHistoryNavigationResult AssetEditorUiState::RestoreState()
{
	UObject* Asset = AssetKey.ResolveObjectPtr();
	
	if (Asset == nullptr) { return EHistoryNavigationResult::AssetDoesNotExist; }
	
#if ENGINE_MINOR_VERSION > 23
	auto* AssetEditorSystem = GEditor->GetEditorSubsystem<UAssetEditorSubsystem>();
#else
	auto* AssetEditorSystem = &FAssetEditorManager::Get();
#endif
	IAssetEditorInstance* AssetEditor = AssetEditorSystem->FindEditorForAsset(Asset, true);

	if (AssetEditor == nullptr)
	{
		AssetEditorSystem->OpenEditorForAsset(Asset);
		AssetEditor = AssetEditorSystem->FindEditorForAsset(Asset, true);
	}

	const TWeakPtr<SDockTab> RestoredTab = GetTabFromManager(AssetEditor->GetAssociatedTabManager());
	RestoredTab.Pin()->ActivateInParent(ETabActivationCause::UserClickedOnTab);
	
	return EHistoryNavigationResult::Success;
}

FText AssetEditorUiState::GetTitle()
{
	UObject* Asset = AssetKey.ResolveObjectPtr();
	return FText::FromString(Asset->GetName());
}

FText AssetEditorUiState::GetPath()
{
	UObject* Asset = AssetKey.ResolveObjectPtr();
	return FText::FromString(Asset->GetPathName());
}

FText AssetEditorUiState::GetInfo()
{
	return FText();
}

bool AssetEditorUiState::IsNavigable()
{
	UObject* Asset = AssetKey.ResolveObjectPtr();
	return (Asset != nullptr);
}

/**********************
	BlueprintNongraphModeUiState
***********************/

EHistoryNavigationResult BlueprintNongraphModeUiState::RestoreState()
{
	const EHistoryNavigationResult ParentResult = AssetEditorUiState::RestoreState();
    
	if(ParentResult != Success) { return ParentResult; }

	UObject* Asset = AssetKey.ResolveObjectPtr();
	
	IAssetEditorInstance* Editor = AssetEditorResolver::GetEditorForAsset(Asset);
	FBlueprintEditor* BlueprintEditor = static_cast<FBlueprintEditor*>(Editor);

	BlueprintEditor->SetCurrentMode(Mode);
	return Success;
}

FText BlueprintNongraphModeUiState::GetInfo()
{
	if (Mode == "DesignerName")
    {
    	return LOCTEXT("BlueprintInfoDesignerEditor", "Designer Editor");
    }
	
	return LOCTEXT("BlueprintInfoDefaultEditor", "Default Editor");
}

/**********************
	BlueprintGraphUiState
***********************/

/*
 * Protected Functions
 */

EHistoryNavigationResult BlueprintGraphUiState::RestoreState()
{
	const EHistoryNavigationResult ParentResult = AssetEditorUiState::RestoreState();

	if(ParentResult != Success) { return ParentResult; }

	UObject* Asset = AssetKey.ResolveObjectPtr();
	
	IAssetEditorInstance* Editor = AssetEditorResolver::GetEditorForAsset(Asset);
	FBlueprintEditor* BlueprintEditor = static_cast<FBlueprintEditor*>(Editor);

	UEdGraph* OrgGraph = GetGraph();

	if(OrgGraph == nullptr)
	{
		return BlueprintGraphMissing;
	}
	
	BlueprintEditor->SetCurrentMode(Mode);
	
	const TSharedRef<FTabPayload_UObject> GraphPayLoad = FTabPayload_UObject::Make(OrgGraph);

	TSharedPtr<FDocumentTracker> BlueprintDocMgr = BlueprintEditor->DocumentManager;
	TArray<TSharedPtr<SDockTab>> GraphTabs;
	BlueprintDocMgr->FindMatchingTabs(GraphPayLoad, GraphTabs);

	if(GraphTabs.Num() == 0)
	{
		if(BlueprintEditor->GetCurrentMode() == "DesignerName")
		{
			BlueprintEditor->JumpToHyperlink(OrgGraph, false);
			BlueprintEditor->GetTabManager()->GetOwnerTab()->ActivateInParent(UserClickedOnTab);
		}
		else
		{
			BlueprintDocMgr->OpenDocument(GraphPayLoad, FDocumentTracker::NavigatingCurrentDocument);
		}
	}
	else
	{
		GraphTabs[0].Get()->DrawAttention();
		GraphTabs[0].Get()->ActivateInParent(UserClickedOnTab);
	}

	
	return Success;
}

FText BlueprintGraphUiState::GetInfo()
{
	UEdGraph* Graph = GetGraph();

	if(Graph == nullptr)
	{
		return LOCTEXT("BlueprintInfoGraphDeleted", "Graph Deleted");
	}
	
	return FText::Format(LOCTEXT("BlueprintInfoGraph", "Graph: {0}"), FText::FromName(Graph->GetFName()));
}

/*
 * Protected Functions
 */

UEdGraph* BlueprintGraphUiState::GetGraph() const
{
	if(!DocId.IsValid()) { return nullptr; }
	
	UObject* Asset = AssetKey.ResolveObjectPtr();

	if(Asset == nullptr) { return nullptr; }
	
	auto* Blueprint = Cast<UBlueprint>(Asset);

	TArray<UEdGraph*> AllGraphs;
	Blueprint->GetAllGraphs(AllGraphs);

	for(UEdGraph* CurGraph: AllGraphs)
	{
		if(CurGraph->GraphGuid == DocId)
		{
			return CurGraph;
		}
	}

	return nullptr;
}

EHistoryNavigationResult BlueprintTimelineUiState::RestoreState()
{
	const EHistoryNavigationResult ParentResult = AssetEditorUiState::RestoreState();
	
	if(ParentResult != EHistoryNavigationResult::Success) { return ParentResult; }

	UTimelineTemplate* Timeline = GetTimeline();

	if(Timeline == nullptr) { return EHistoryNavigationResult::Failed; }
	
	UObject* Asset = AssetKey.ResolveObjectPtr();
	IAssetEditorInstance* Editor = AssetEditorResolver::GetEditorForAsset(Asset);
    FBlueprintEditor* BlueprintEditor = static_cast<FBlueprintEditor*>(Editor);
    			
    TSharedPtr<FDocumentTracker> BlueprintDocMgr = BlueprintEditor->DocumentManager;
    BlueprintEditor->OpenDocument(Timeline, FDocumentTracker::EOpenDocumentCause::OpenNewDocument);
	
	return EHistoryNavigationResult::Success;
}

FText BlueprintTimelineUiState::GetInfo()
{
	UTimelineTemplate* Timeline = GetTimeline();

	return FText::Format(LOCTEXT("BlueprintInfo", "Timeline: {0}"), FText::FromName(Timeline->GetFName()));
}

UTimelineTemplate* BlueprintTimelineUiState::GetTimeline() const
{
	// TODO: Find a way to share functionality with blueprint graph
	UObject* Asset = AssetKey.ResolveObjectPtr();

	auto* Blueprint = Cast<UBlueprint>(Asset);

	if(Blueprint == nullptr) { return nullptr; }

	for (UTimelineTemplate* CurTimeline: Blueprint->Timelines)
	{
		if(CurTimeline->TimelineGuid == TimelineId)
		{
			return CurTimeline;
		}
	}

	return nullptr;
}


/**********************
	BlueprintViewportState
***********************/


EHistoryNavigationResult BlueprintViewportState::RestoreState()
{
	const EHistoryNavigationResult ParentResult = AssetEditorUiState::RestoreState();
    
	if(ParentResult != EHistoryNavigationResult::Success) { return ParentResult; }

	UObject* Asset = AssetKey.ResolveObjectPtr();
	
	IAssetEditorInstance* Editor = AssetEditorResolver::GetEditorForAsset(Asset);
	FBlueprintEditor* BlueprintEditor = static_cast<FBlueprintEditor*>(Editor);

	BlueprintEditor->GetTabManager()->InvokeTab(FBlueprintEditorTabs::SCSViewportID);
	
	return EHistoryNavigationResult::Success;
}

FText BlueprintViewportState::GetInfo()
{
	return LOCTEXT("Viewport", "Viewport");
}

/**********************
	LevelEditorUiState
***********************/

EHistoryNavigationResult LevelEditorUiState::RestoreState()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>("LevelEditor");
	TSharedPtr<ILevelEditor> LevelEditor = LevelEditorModule.GetFirstLevelEditor();

	if (!LevelEditor.IsValid()) { return EHistoryNavigationResult::Failed; }
	
	LevelEditor->BringToFront();
	
	return EHistoryNavigationResult::Success;
}

FText LevelEditorUiState::GetTitle()
{
	return LOCTEXT("LevelEditor", "Level Editor");
}

FText LevelEditorUiState::GetPath()
{
	return FText::FromString(GWorld->GetOutermost()->GetName());
}

FText LevelEditorUiState::GetInfo()
{
	return FText::FromString("");
}

#undef LOCTEXT_NAMESPACE
