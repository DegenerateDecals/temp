﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.
#pragma once

#include "EditorMonitor.h"

class BasicAssetEditorMonitor: public EditorMonitor
{
public:
    BasicAssetEditorMonitor(
		FHistoryManager* Owner,
        UObject* TrackedObj,
        IAssetEditorInstance* AssetEditor,
		FOnTrackedUiStateChange UiChangeCallback,
        FOnTrackedUiEditorClosed UiEditorClosedCallback 
    );

    virtual void StartMonitoring() override;
};
