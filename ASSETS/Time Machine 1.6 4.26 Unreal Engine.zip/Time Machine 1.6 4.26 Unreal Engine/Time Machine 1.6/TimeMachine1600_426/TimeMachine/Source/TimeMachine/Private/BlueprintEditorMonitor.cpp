﻿// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "BlueprintEditorMonitor.h"

#include "AssetEditorResolver.h"
#include "BlueprintEditorModes.h"
#include "Editor/Kismet/Public/BlueprintEditor.h"
#include "Editor/Kismet/Public/BlueprintEditorTabs.h"
#include "Editor/Kismet/Public/SSCSEditor.h"
#include "Editor/Kismet/Public/WorkflowOrientedApp/WorkflowUObjectDocuments.h"
#include "HistoryManager.h"
#include "WidgetBlueprintEditor.h"
#include "Engine/TimelineTemplate.h"


BlueprintEditorMonitor::BlueprintEditorMonitor(
		FHistoryManager* Owner,
		UObject* TrackedObj,
		IAssetEditorInstance* AssetEditor,
		FOnTrackedUiStateChange UiChangeCallback,
        FOnTrackedUiEditorClosed UiEditorClosedCallback
	):
	EditorMonitor(Owner, TrackedObj, AssetEditor, UiChangeCallback, UiEditorClosedCallback),
	CurrentBlueprintEditor(static_cast<FBlueprintEditor*>(AssetEditor))
{
}

BlueprintEditorMonitor::~BlueprintEditorMonitor()
{
	FGlobalTabmanager::Get()->OnTabForegrounded_Unsubscribe(TabForegroundedHandle);
}

void BlueprintEditorMonitor::StartMonitoring()
{
	EditorMonitor::StartMonitoring();

	CurrentMode = CurrentBlueprintEditor->GetCurrentMode();
	
	BindBlueprint(CurrentBlueprintEditor);
    	
    CallUiChangeCallback();

	FGlobalTabmanager::Get()->OnTabForegrounded_Subscribe(
            FOnActiveTabChanged::FDelegate::CreateSP(
                this,
                &BlueprintEditorMonitor::OnAnyTabForegroundedDocTracking
            )
        );
	
	FGlobalTabmanager::Get()->OnActiveTabChanged_Subscribe(
		FOnActiveTabChanged::FDelegate::CreateSP(
			this,
			&BlueprintEditorMonitor::OnAnyTabActivatedDocTracking
		)
	);
}

void BlueprintEditorMonitor::BindBlueprint(FBlueprintEditor* BlueprintEditor)
{
	UE_LOG(LogTimeMachine, Verbose, TEXT("Binding Blueprint"));
	
    const TSharedPtr<FDocumentTracker> BlueprintDocMgr = BlueprintEditor->DocumentManager;
    CurrentBlueprintDocTab = BlueprintDocMgr->GetActiveTab();
	
	TArray<TSharedPtr<SDockTab>> AllDocTabs = BlueprintDocMgr->GetAllDocumentTabs();	

	for (TSharedPtr<SDockTab> CurDocTab : AllDocTabs)
	{
		CurDocTab->SetOnTabClosed(
			SDockTab::FOnTabClosedCallback::CreateSP(
				this,
				&BlueprintEditorMonitor::OnDocumentTabClosed
			)
		);
	}
}

UEdGraph* BlueprintEditorMonitor::GetActiveBlueprintGraphObj(FBlueprintEditor* BlueprintEditor, TWeakPtr<SDockTab> ForTab)
{
	TSharedPtr<FDocumentTracker> BlueprintDocMgr = BlueprintEditor->DocumentManager;
    	
	UBlueprint* Blueprint = BlueprintEditor->GetBlueprintObj();

	if(Blueprint == nullptr) { return nullptr; }
	
	UE_LOG(LogTimeMachine, Verbose,
		TEXT("%s Blueprint Monitor - Searching %s"),
		*GetName(),
		*Blueprint->GetFriendlyName()
	);

	TArray<UEdGraph*> AllBluePrtGraphs;
	Blueprint->GetAllGraphs(AllBluePrtGraphs);
	
	for (UEdGraph* CurGraphObj : AllBluePrtGraphs)
	{	
		TSharedRef<FTabPayload_UObject> GraphPayLoad = FTabPayload_UObject::Make(CurGraphObj);
		
		TArray<TSharedPtr<SDockTab>> GraphTabs;

		BlueprintDocMgr->FindMatchingTabs(GraphPayLoad, GraphTabs);

		for(TSharedPtr<SDockTab> GraphTab : GraphTabs)
		{
			if(GraphTab != ForTab) { continue; };

			return CurGraphObj;
		}
	}

	UE_LOG(LogTimeMachine, Verbose, TEXT("%s Blueprint Monitor - No Active Blueprint Graph Found"), *GetName());
	return nullptr;
}


void BlueprintEditorMonitor::OnAnyTabActivatedDocTracking(TSharedPtr<SDockTab> OldTab, TSharedPtr<SDockTab> NewTab)
{
	//TODO: Move into its own tab delegate action 
	const FName NewMode = CurrentBlueprintEditor->GetCurrentMode();
    if(NewMode != CurrentMode) 
    {
    	BindEditor();
    
    	CurrentMode == NewMode;
    }

	if(NewTab == nullptr || NewTab->GetTabRole() != DocumentTab || NewTab == CurrentBlueprintDocTab) { return; }

	if (DocumentTabIgnoreCount > 0) { --DocumentTabIgnoreCount; return; }	

	bool bValid = false;
	if(NewTab.Get()->GetContent()->GetType() == "SSCSEditorViewPort")
	{
		const TSharedPtr<SDockTab> ViewportTab = CurrentBlueprintEditor->GetTabManager()->FindExistingLiveTab(FBlueprintEditorTabs::SCSViewportID);

		if(ViewportTab == NewTab)
		{
			bValid = true; 
		}
	}
	else
	{
		const TSharedPtr<FDocumentTracker> BlueprintDocMgr = CurrentBlueprintEditor->DocumentManager;
		TArray<TSharedPtr<SDockTab>> AllDocTabs = BlueprintDocMgr->GetAllDocumentTabs();
		for(TSharedPtr<SDockTab>& DocTab : AllDocTabs)
		{
			if(DocTab == NewTab)
			{
				bValid = true;
				break;
			}	
		}
	}

	if(!bValid) { return; }

	NewTab->SetOnTabClosed(SDockTab::FOnTabClosedCallback::CreateSP(this, &BlueprintEditorMonitor::OnDocumentTabClosed));
	CurrentBlueprintDocTab = NewTab;
	
	if(!Manager->IsRestoringState())
    {
		CallUiChangeCallback();
    }
}

void BlueprintEditorMonitor::OnAnyTabForegroundedDocTracking(TSharedPtr<SDockTab> NewTab, TSharedPtr<SDockTab> OldTab)
{
	OnAnyTabActivatedDocTracking(OldTab, NewTab);
}

void BlueprintEditorMonitor::OnDocumentTabClosed(TSharedRef<SDockTab> Tab)
{
	UE_LOG(LogTimeMachine, Verbose, TEXT("Document Tab Closed"));
	
	DocumentTabIgnoreCount = 2;
}

TSharedPtr<TrackedUiState> BlueprintEditorMonitor::BuildUiChangeEvent()
{
	// TODO: Move to Factory
	const FName Mode = CurrentBlueprintEditor->GetCurrentMode();

	if(
		(Mode == FName("DesignerName"))
		|| (Mode == FName("InterfaceName") && !CurrentBlueprintDocTab.IsValid())
		|| (Mode == FBlueprintEditorApplicationModes::BlueprintDefaultsMode)
	)
	{
		return MakeShared<BlueprintNongraphModeUiState>(TrackedObj, Mode);
	}
	
	const FName ContentType = CurrentBlueprintDocTab.Pin()->GetContent()->GetType();
	
	if(ContentType == "SSCSEditorViewPort")
	{
    	return MakeShared<BlueprintViewportState>(TrackedObj);	
	}
	
	if (ContentType == "STimelineEditor")
	{
		// TODO: Find better way to get the Timeline other than through the tab label 
		const FString TimelineName = CurrentBlueprintDocTab.Pin()->GetTabLabel().ToString();
		
		UTimelineTemplate* TimelineTemplate = nullptr;

		for(UTimelineTemplate* CurTimeline: CurrentBlueprintEditor->GetBlueprintObj()->Timelines)
		{
			if(CurTimeline->GetFName().ToString() != TimelineName) { continue; }

			TimelineTemplate = CurTimeline;
		}

    	return MakeShared<BlueprintTimelineUiState>(TrackedObj, TimelineTemplate->TimelineGuid);	
	}
	
	UEdGraph* ActiveGraphObj = GetActiveBlueprintGraphObj(CurrentBlueprintEditor, CurrentBlueprintDocTab);
	return MakeShared<BlueprintGraphUiState>(TrackedObj, Mode, ActiveGraphObj->GraphGuid);
}
