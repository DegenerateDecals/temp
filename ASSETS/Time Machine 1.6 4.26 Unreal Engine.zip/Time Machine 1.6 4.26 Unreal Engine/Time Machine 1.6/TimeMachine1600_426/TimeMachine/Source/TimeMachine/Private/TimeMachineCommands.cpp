// Copyright 2020 Christopher Venturini - All Rights Reserved.

#include "TimeMachineCommands.h"

#define LOCTEXT_NAMESPACE "FTimeMachineModule"

void FTimeMachineCommands::RegisterCommands()
{
	UI_COMMAND(MoveBackInHistory, "Back", "Move back in history", EUserInterfaceActionType::Button, FInputChord(EKeys::Comma, false, true, false, false));
	UI_COMMAND(MoveForwardInHistory, "Forward", "Move forward in history", EUserInterfaceActionType::Button, FInputChord(EKeys::Period, false, true, false, false));

	UI_COMMAND(OpenBackHistoryMenu, "OpenBackMenu", "Open back in history menu", EUserInterfaceActionType::Button, FInputChord(EKeys::Comma, false, true, true, false));
	UI_COMMAND(OpenForwardHistoryMenu, "OpenForwardMenu", "Open forwward in history menu", EUserInterfaceActionType::Button, FInputChord(EKeys::Period, false, true, true, false));

	UI_COMMAND(OpenReleaseNotes, "OpenReleaseNotes", "Open Time Machine release notes", EUserInterfaceActionType::Button, FInputChord());
}

#undef LOCTEXT_NAMESPACE
