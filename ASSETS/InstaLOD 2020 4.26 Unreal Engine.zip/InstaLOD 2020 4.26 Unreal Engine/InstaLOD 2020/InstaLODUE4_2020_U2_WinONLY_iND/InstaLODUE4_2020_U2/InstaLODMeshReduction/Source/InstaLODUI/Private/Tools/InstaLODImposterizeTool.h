/**
 * InstaLODImposterizeTool.h (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODImposterizeTool.h
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#pragma once

#include "CoreMinimal.h"
#include "Tools/InstaLODBakeBaseTool.h"
#include "InstaLODImposterizeTool.generated.h"

UENUM()
enum class EInstaLODImposterizeType : uint8
{
	InstaLOD_AABB						UMETA(DisplayName = "AABB"),
	InstaLOD_Billboard					UMETA(DisplayName = "Billboard"),
	InstaLOD_HybridBillboardCloud		UMETA(DisplayName = "Hybrid Billboard Cloud"),
	InstaLOD_Flipbook					UMETA(DisplayName = "Flipbook")
};

UCLASS(Config=InstaLOD)
class INSTALODUI_API UInstaLODImposterizeTool : public UInstaLODBakeBaseTool
{
	GENERATED_BODY()

	/// VARIABLES ///

	/************************************************************************/
	/* Settings                                                             */
	/************************************************************************/

public:

	/** Determines the type of the imposter. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Type"), Category = "Settings")
	EInstaLODImposterizeType ImposterizeType = EInstaLODImposterizeType::InstaLOD_Billboard;

	/** The minimum distance between two UV shells in pixels. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Gutter Size In Pixels", ClampMin = 1, ClampMax = 64), Category = "Settings")
	int32 GutterSizeInPixels = 2;

	/************************************************************************/
	/* Billboard Settings                                                   */
	/************************************************************************/

	/** The amount of quads to spawn for the XY axis of the input geometry AABB. Additional quads will be rotated by 180 deg/count along the Y axis. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "XY Axis Quads", ClampMin = 0, ClampMax = 16), Category = "Billboard Settings")
	int32 XYAxisQuads_Billboard = 0;

	/** The amount of quads to spawn for the XZ axis of the input geometry AABB. Additional quads will be rotated by 180 deg/count along the Z axis. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "XZ Axis Quads", ClampMin = 0, ClampMax = 16), Category = "Billboard Settings")
	int32 XZAxisQuads_Billboard = 1;

	/** The amount of quads to spawn for the YZ axis of the input geometry AABB. Additional quads will be rotated by 180 deg/count along the Z axis. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "YZ Axis Quads", ClampMin = 0, ClampMax = 16), Category = "Billboard Settings")
	int32 YZAxisQuads_Billboard = 1;

	/** If enabled, quads will generate polygons for each side of a quad. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Two Sided Quads"), Category = "Billboard Settings")
	bool bTwoSidedQuads_Billboard = true;

	/** Subdivisions along the U axis for billboard imposters. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Subdivisions U", ClampMin = 1, ClampMax = 16), Category = "Billboard Settings")
	int32 SubdivisionsU = 1;

	/** Subdivisions along the V axis for billboard imposters. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Subdivisions V", ClampMin = 1, ClampMax = 16), Category = "Billboard Settings")
	int32 SubdivisionsV = 1;

	/************************************************************************/
	/* AABB Settings                                                        */
	/************************************************************************/

	/** AABB imposter faces will be displaced along the face normal by the specified value in world space units. This is useful to create hay or headges with overhanging faces. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Displacement", ClampMin = -50, ClampMax = 50), Category = "AABB Settings")
	int32 AABB_Displacement = 0;

	/************************************************************************/
	/* Hybrid Billboard Cloud Settings                                      */
	/************************************************************************/

	/** The maximum amount of faces to spawn for cloud imposter. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Maximum Face Count", ClampMin = 4, ClampMax = 10000), Category = "Hybrid Billboard Cloud Settings")
	int32 MaximumFaceCount = 700;

	/** The amount of faces in percentage of the 'Maximum Face Count' to allocate for the polygon part of hybrid billboard cloud imposters. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Hybrid Mesh Face Factor", UIMin = 0.0f, UIMax = 50.0f, ClampMin = 0.0f, ClampMax = 50.0f), Category = "Hybrid Billboard Cloud Settings")
	float HybridMeshFaceFactor = 50.0f;

	/** Spawn XY axis quads. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "XY Axis Quads"), Category = "Hybrid Billboard Cloud Settings")
	bool bXYAxisQuads = false;

	/** Spawn XZ axis quads. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "XZ Axis Quads"), Category = "Hybrid Billboard Cloud Settings")
	bool bXZAxisQuads = false;

	/** Spawn YZ axis quads. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "YZ Axis Quads"), Category = "Hybrid Billboard Cloud Settings")
	bool bYZAxisQuads = true;

	/** If enabled, quads will generate polgons for each side of a quad. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Two Sided Quads"), Category = "Hybrid Billboard Cloud Settings")
	bool bTwoSidedQuads_Hybrid = true;

	/** Material names matching the specified suffix will be used for polygonal mesh output when creating a hybrid billboard cloud imposter. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Hybrid Cloud Poly Material Suffix"), Category = "Hybrid Billboard Cloud Settings")
	FString HybridCloudPolyMaterialSuffix = "_cloudpoly";

	/************************************************************************/
	/* Flipbook	Settings							                        */
	/************************************************************************/

	/** The amount of flipbook frames to generate for each rotation axis. NOTE: by default flipbook's top left frame is projected along the negative Z axis. */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Flipbook Frames Per Axis", ClampMin = 1, ClampMax = 64), Category = "Flipbook Settings")
	int32 FlipbookFramesPerAxis = 8;

	/************************************************************************/
	/* Alpha Cutout Settings												*/
	/************************************************************************/

	/** Enable AlphaCutOut */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Enable"), Category = "Alpha Cutout (Preview)")
	bool bIsAlphaCutOutEnabled = false;

	/** Enable Subdivision */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Subdivide"), Category = "Alpha Cutout (Preview)")
	bool bIsAlphaCutOutSubdivideEnabled = false;

	/** Resolution for Subdivision */
	UPROPERTY(Config, EditAnywhere, meta = (DisplayName = "Resolution", ClampMin = 1, ClampMax = 64), Category = "Alpha Cutout (Preview)")
	int32 AlphaCutOutResolution = 16;

	/************************************************************************/
	/* INTERNAL USE                                                         */
	/************************************************************************/
	
	InstaLOD::IImposterizeOperation *Operation;
	InstaLOD::IInstaLODMeshExtended *AuxMesh;
	InstaLOD::ImposterizeResult OperationResult;
	

	/// FUNCTIONS ///

public:
	
	UInstaLODImposterizeTool();
	
	/************************************************************************/
	/* Getter / Setter                                                      */
	/************************************************************************/

	FORCEINLINE EInstaLODImposterizeType GetType() const { return ImposterizeType; }

	/** Start - UInstaLODBaseTool Interface */
	virtual void OnMeshOperationExecute(bool bIsAsynchronous) override;
	virtual void DeallocMeshOperation() override;
	virtual bool IsMeshOperationSuccessful() const override;
	virtual InstaLOD::IInstaLODMaterial* GetBakeMaterial() override;
	virtual bool IsMaterialDataRequired() const override {
		return true;
	}
	virtual bool IsFreezingTransformsForMultiSelection() const override {
		return true;
	}
	virtual bool IsWorldTransformRequired() const override {
		return true;
	}
	bool IsFlipbookImposter() const {
		return GetType() == EInstaLODImposterizeType::InstaLOD_Flipbook;
	}
	uint32 GetFlipbookFramesPerAxisCount() const {
		return FlipbookFramesPerAxis;
	}
	virtual void FinalizeBakeMaterial(class UMaterialInstanceConstant* Material) const override;
	
	virtual bool CanAppendMeshToInput(FInstaLODMeshComponent& Component, InstaLOD::IInstaLODMesh *Mesh, TArray<UMaterialInterface*>* UniqueMaterials) override;
	
	virtual FText GetFriendlyName() const override;
	virtual int32 GetOrderId() const override;
	virtual void ResetSettings() override;
	/** End - UInstaLODBaseTool Interface */	

protected:
	virtual bool IsMeshOperationExecutable(FText* OutErrorText) const override;


	InstaLOD::ImposterizeSettings GetImposterizeSettings();
};

