/**
 * InstaLODUtilities.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODUtilities.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "Utilities/InstaLODUtilities.h"
#include "InstaLODUIPCH.h"

#include "InstaLODModule.h"
#include "Tools/InstaLODBaseTool.h"

#include "RawMesh.h"
#include "IContentBrowserSingleton.h"
#include "ContentBrowserModule.h"
#include "AssetToolsModule.h"
#include "IAssetTools.h"

#include "MaterialUtilities.h"
#include "MeshMergeUtilities/Private/MeshMergeUtilities.h"

#include "MaterialOptions.h"
#include "IMaterialBakingModule.h"
#include "MeshMergeUtilities/Private/MeshMergeHelpers.h"
#include "MaterialBakingStructures.h"
#include "MeshMergeData.h"
#include "ObjectTools.h"
#include "UObject/UObjectGlobals.h"
#include "MeshDescriptionOperations.h" 

#include "StaticMeshOperations.h"
#include "StaticMeshAttributes.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"
 
#define TEXT_IF_UE419(x)	TEXT(x) 

#include "Rendering/SkeletalMeshModel.h"
#include "Rendering/SkeletalMeshLODModel.h" 

namespace InstaLODVectorHelper
{
	static inline InstaLOD::InstaVec3F FVectorToInstaVec(const FVector& Vector)
	{
		InstaLOD::InstaVec3F OutVector;
		OutVector.X = Vector.X;
		OutVector.Y = Vector.Y;
		OutVector.Z = Vector.Z;
		return OutVector;
	}

	static inline FVector InstaVecToFVector(const InstaLOD::InstaVec3F& Vector)
	{
		return FVector(Vector.X, Vector.Y, Vector.Z);
	}
}

class FInstaLODMeshMergeUtilities : public FMeshMergeUtilities
{
public:	
	void CreateMaterialData(IInstaLOD* InstaLOD, TArray<InstaLODMergeData>& MergeData, InstaLOD::IInstaLODMaterialData *MaterialData, const struct FMaterialProxySettings& InMaterialProxySettings, TArray<UMaterialInterface*>& OutMaterials) const
	{
		check(InstaLOD);
		check(MaterialData);

		if (MergeData.Num() == 0)
		{
			UE_LOG(LogInstaLOD, Log, TEXT("No merge data specified."));
			return;
		}

		// setup our progress indicator
		FScopedSlowTask SlowTask(100.f, (NSLOCTEXT("InstaLODUI", "CreateMaterialData", "Creating Material Data")));
		SlowTask.MakeDialog();

		// progress state 10/100
		SlowTask.EnterProgressFrame(10.0f, NSLOCTEXT("InstaLODUI", "CreateMaterialData_GatheringData", "Gathering Data"));
		SlowTask.MakeDialog();
		
		TMultiMap<uint32 /*mesh index*/, TPair<uint32 /*original section index*/, uint32 /*unique section index*/>> MeshToSectionsMultiMap;
		// track a set of all unique sections in all meshes
		TArray<FSectionInfo> UniqueSections;
		// also track all meshes that are used by a section
		TMultiMap<uint32 /*section index*/, uint32 /*mesh index*/> UniqueSectionToMeshesMultiMap;
		TArray<FRawMesh*> RawMeshData;
		TMap<FRawMesh*, FMeshDescription*> RawMeshDescriptionData;

		for (const InstaLODMergeData& InstaLODMergeData : MergeData)
		{
			const int32 BaseLODIndex = 0;
			const bool bPropagateVertexColours = true;
			FRawMesh* RawMesh = new FRawMesh();
			FMeshDescription* RawMeshDescription = new FMeshDescription();
			FStaticMeshAttributes(*RawMeshDescription).Register();

			TArray<FSectionInfo> Sections;

			// we convert our InstaLOD Mesh back into a raw mesh
			// this way we can operate both on skelteal and static meshes in a unified way
			InstaLOD->ConvertInstaLODMeshToRawMesh(InstaLODMergeData.InstaLODMesh, *RawMesh);

			TMap<int32, FName> TempMaterialMap;
			InstaLOD->ConvertInstaLODMeshToMeshDescription(InstaLODMergeData.InstaLODMesh, TempMaterialMap,  *RawMeshDescription);
			RawMeshDescriptionData.Add(RawMesh, RawMeshDescription);

			// check if it's a Static Mesh or Skeletal Mesh
			if (InstaLODMergeData.Component->StaticMeshComponent.IsValid())
			{
				FMeshMergeHelpers::ExtractSections(InstaLODMergeData.Component->StaticMeshComponent.Get(), BaseLODIndex, Sections);
			}
			else if (InstaLODMergeData.Component->SkeletalMeshComponent.IsValid())
			{
				FMeshMergeHelpers::ExtractSections(InstaLODMergeData.Component->SkeletalMeshComponent.Get(), BaseLODIndex, Sections);
				IInstaLOD::UE4_SkeletalMeshResource *const Resource = InstaLODMergeData.Component->SkeletalMeshComponent->SkeletalMesh->GetImportedModel();

				checkf(Resource->LODModels.IsValidIndex(BaseLODIndex), TEXT("Invalid LOD Index"));
				for (int32 i=0; i<Sections.Num(); i++)
				{
					Sections[i].MaterialIndex = Resource->LODModels[BaseLODIndex].Sections[i].MaterialIndex;
				}
			}
			const int32 MeshIndex = RawMeshData.Num();
			RawMeshData.Add(RawMesh);

			// add mesh->sections and section->meshes relations
			for (int32 SectionIndex=0; SectionIndex<Sections.Num(); SectionIndex++)
			{
				FSectionInfo& Section = Sections[SectionIndex];

				const int32 UniqueSectionIndex = UniqueSections.AddUnique(Section);
				MeshToSectionsMultiMap.Add(MeshIndex, TPair<uint32, uint32>(UniqueSectionIndex, SectionIndex));
				UniqueSectionToMeshesMultiMap.Add(UniqueSectionIndex, MeshIndex);
			}
		}

		// add material->sections relations
		TArray<UMaterialInterface*> UniqueMaterials;
		TMultiMap<uint32, uint32> UniqueMaterialToSectionsMultiMap;
		for (int32 SectionIndex=0; SectionIndex<UniqueSections.Num(); SectionIndex++)
		{
			FSectionInfo& Section = UniqueSections[SectionIndex];
			const int32 UniqueMaterialIndex = UniqueMaterials.AddUnique(Section.Material);
			UniqueMaterialToSectionsMultiMap.Add(UniqueMaterialIndex, SectionIndex);
		}

		// setup bake material properties
		UMaterialOptions* Options = PopulateMaterialOptions(InMaterialProxySettings);
		TArray<EMaterialProperty> MaterialProperties;
		for (const FPropertyEntry& Entry : Options->Properties)
		{
			if (Entry.Property != MP_MAX)
			{
				MaterialProperties.Add(Entry.Property);
			}
		}

		// prepare mesh and material settings for material flattening process
		TArray<FMeshData> GlobalMeshSettings;
		TArray<FMaterialData> GlobalMaterialSettings;
		TMultiMap<uint32, TPair<uint32, uint32>> OutputMaterialsMap;
		TSet<UMaterialInterface*> MaterialsRequiringFullbake;

		for (int32 MaterialIndex=0; MaterialIndex<UniqueMaterials.Num(); MaterialIndex++)
		{
			UMaterialInterface *const Material = UniqueMaterials[MaterialIndex];

			// analyze if this material requires mesh data for baking
			int32 NumTexCoords = 0;
			bool bUseVertexData = false;
			FMaterialUtilities::AnalyzeMaterial(Material, MaterialProperties, NumTexCoords, bUseVertexData);

			if (NumTexCoords > 1 || bUseVertexData)
				MaterialsRequiringFullbake.Add(Material);
		}

		// if a mesh requires a bake for a specific material, we have to enable baking for all
		// materials on that mesh
		for (int32 MeshIndex=0; MeshIndex<RawMeshData.Num(); MeshIndex++)
		{
			TArray<TPair<uint32, uint32>> UniqueToMeshSectionIndices;
			MeshToSectionsMultiMap.MultiFind(MeshIndex, UniqueToMeshSectionIndices);

			if (UniqueToMeshSectionIndices.Num() <= 1)
				continue;

			bool bRequireBakeForAll = false;
			bool bMaterialsRequireBake = false;

			for (int32 FindIndex=0; FindIndex<UniqueToMeshSectionIndices.Num(); FindIndex++)
			{
				FSectionInfo& UniqueSection = UniqueSections[UniqueToMeshSectionIndices[FindIndex].Key];
				const bool bCurrentMaterialRequiresBake = MaterialsRequiringFullbake.Contains(UniqueSection.Material);

				if (FindIndex == 0)
				{
					bMaterialsRequireBake = bCurrentMaterialRequiresBake;
				}
				else if (bMaterialsRequireBake != bCurrentMaterialRequiresBake)
				{
					bRequireBakeForAll = true;
					break;
				}
			}

			if (!bRequireBakeForAll)
				continue;

			// we have to enable bake for all materials on this mesh
			for (int32 FindIndex=0; FindIndex<UniqueToMeshSectionIndices.Num(); FindIndex++)
			{
				FSectionInfo& UniqueSection = UniqueSections[UniqueToMeshSectionIndices[FindIndex].Key];
				MaterialsRequiringFullbake.Add(UniqueSection.Material);
			}

			// now we have to restart the loop at 0 - it is possible that an already processed mesh requires
			// baking for all it's materials
			MeshIndex = -1;
		}
		
		for (int32 MaterialIndex=0; MaterialIndex<UniqueMaterials.Num(); MaterialIndex++)
		{
			UMaterialInterface *const Material = UniqueMaterials[MaterialIndex];

			TArray<uint32> MaterialSectionIndices;
			UniqueMaterialToSectionsMultiMap.MultiFind(MaterialIndex, MaterialSectionIndices);

			FMaterialData MaterialSettings;
			MaterialSettings.Material = Material;

			for (const FPropertyEntry& Entry : Options->Properties)
			{
				if (!Entry.bUseConstantValue && Material->IsPropertyActive(Entry.Property) && Entry.Property != MP_MAX)
				{
					MaterialSettings.PropertySizes.Add(Entry.Property, Entry.bUseCustomSize ? Entry.CustomSize : Options->TextureSize);
				}
			}

			// if we need mesh or vertex data, we have to prepare/generate additional data
			// otherwise we can just evaluate the material graph and get the flatten texture
			if (MaterialsRequiringFullbake.Contains(Material))
			{
				// iterate through all unique sections
				for (uint32 SectionIndex : MaterialSectionIndices)
				{
					// iterate through all meshes that use this unique sections
					TArray<uint32> MeshIndices;
					UniqueSectionToMeshesMultiMap.MultiFind(SectionIndex, MeshIndices);

					for (uint32 MeshIndex : MeshIndices)
					{
						FMeshData MeshSettings;
						TMap<int32, FName> MaterialMap;
						FRawMesh *const RawMesh = RawMeshData[MeshIndex];
						const UStaticMeshComponent *const StaticMeshComponent = MergeData[MeshIndex].Component->StaticMeshComponent.Get();
						const UStaticMesh *const StaticMesh = StaticMeshComponent != nullptr ? StaticMeshComponent->GetStaticMesh() : nullptr;

						// if we already have lightmap uvs generated or the lightmap coordinate index != 0 and available we can reuse those instead of having to generate new ones
						if (StaticMesh != nullptr && (StaticMesh->GetSourceModel(0).BuildSettings.bGenerateLightmapUVs ||
							(StaticMesh->LightMapCoordinateIndex != 0 && RawMesh->WedgeTexCoords[StaticMesh->LightMapCoordinateIndex].Num() != 0)))
						{
							MeshSettings.CustomTextureCoordinates = RawMesh->WedgeTexCoords[StaticMeshComponent->GetStaticMesh()->LightMapCoordinateIndex];
							ScaleTextureCoordinatesToBox(FBox2D(FVector2D::ZeroVector, FVector2D(1, 1)), MeshSettings.CustomTextureCoordinates);
						}
						else
						{
							// generate new non overlapping UVs
							IMeshUtilities& MeshUtilities = FModuleManager::GetModuleChecked<IMeshUtilities>("MeshUtilities");
							MeshUtilities.GenerateUniqueUVsForStaticMesh(*RawMesh, Options->TextureSize.GetMax(), MeshSettings.CustomTextureCoordinates);
							ScaleTextureCoordinatesToBox(FBox2D(FVector2D::ZeroVector, FVector2D(1, 1)), MeshSettings.CustomTextureCoordinates);

						}

						FStaticMeshOperations::ConvertFromRawMesh(*RawMesh, *RawMeshDescriptionData[RawMesh], MaterialMap);
						MeshSettings.RawMeshDescription = RawMeshDescriptionData[RawMesh];

						MeshSettings.TextureCoordinateBox = FBox2D(MeshSettings.CustomTextureCoordinates);

						// get the unqiue to mesh sections mappings
						TArray<TPair<uint32, uint32>> UniqueToMeshSectionIndices;
						MeshToSectionsMultiMap.MultiFind(MeshIndex, UniqueToMeshSectionIndices);

						// add the original section index
						for (const TPair<uint32, uint32> IndexPair : UniqueToMeshSectionIndices)
						{
							if (IndexPair.Key == SectionIndex)
							{
								MeshSettings.MaterialIndices.Add(IndexPair.Value);
							}
						}

						// setup lightmap data if available
						if (StaticMeshComponent != nullptr && StaticMeshComponent->LODData.IsValidIndex(0))
						{
							const FStaticMeshComponentLODInfo& ComponentLODInfo = StaticMeshComponent->LODData[0];
							const FMeshMapBuildData *const MeshMapBuildData = StaticMeshComponent->GetMeshMapBuildData(ComponentLODInfo);
							if (MeshMapBuildData)
							{
								MeshSettings.LightMap = MeshMapBuildData->LightMap;
								MeshSettings.LightMapIndex = StaticMeshComponent->GetStaticMesh()->LightMapCoordinateIndex;
							}
						}

						// add mapping from mesh section index to bake output material
						for (int32 MeshSectionIndex : MeshSettings.MaterialIndices)
						{
							OutputMaterialsMap.Add(MeshIndex, TPair<uint32, uint32>(MeshSectionIndex, /*BakeOutput MaterialIndex*/GlobalMeshSettings.Num()));
						}

						GlobalMeshSettings.Add(MeshSettings);
						GlobalMaterialSettings.Add(MaterialSettings);
					}
				}
			}
			else
			{
				// we can just bake out this material without any mesh information!
				FMeshData MeshSettings;
				MeshSettings.RawMeshDescription = nullptr;
				MeshSettings.TextureCoordinateBox = FBox2D(FVector2D(0.0f, 0.0f), FVector2D(1.0f, 1.0f));
				MeshSettings.TextureCoordinateIndex = 0;

				// iterate through all unique sections
				for (const uint32 UniqueSectionIndex : MaterialSectionIndices)
				{
					// iterate through all meshes that use this unique sections
					TArray<uint32> MeshIndices;
					UniqueSectionToMeshesMultiMap.MultiFind(UniqueSectionIndex, MeshIndices);

					for (const uint32 MeshIndex : MeshIndices)
					{
						// add remapping entry for each section, that matches this unique section, to the bake output material index
						TArray<TPair<uint32, uint32>> UniqueToMeshSectionIndices;
						MeshToSectionsMultiMap.MultiFind(MeshIndex, UniqueToMeshSectionIndices);

						for (const TPair<uint32, uint32> IndexPair : UniqueToMeshSectionIndices)
						{
							if (IndexPair.Key != UniqueSectionIndex)
								continue;

							OutputMaterialsMap.Add(MeshIndex, TPair<uint32, uint32>(/*MeshSectionIndex*/IndexPair.Value, /*BakeOutput MaterialIndex*/GlobalMeshSettings.Num()));
						}
					}
				}

				GlobalMeshSettings.Add(MeshSettings);
				GlobalMaterialSettings.Add(MaterialSettings);
			}
		}
		check(GlobalMeshSettings.Num() == GlobalMaterialSettings.Num());

		// progress state 20/100
		SlowTask.EnterProgressFrame(10.0f, NSLOCTEXT("InstaLODUI", "CreateMaterialData_FlatteningMaterialData", "Flattening Material Data"));
		SlowTask.MakeDialog();

		// bake all unique materials
		TArray<FBakeOutput> BakeOutputs;
		{
			IMaterialBakingModule& Module = FModuleManager::Get().LoadModuleChecked<IMaterialBakingModule>("MaterialBaking");

			const float progressStep = 50.0f / float(GlobalMeshSettings.Num());

			for (int32 Index=0; Index<GlobalMeshSettings.Num(); Index++)
			{
				TArray<FBakeOutput> TempBakeOutputs;

				Module.BakeMaterials(TArray<FMaterialData*>({ &GlobalMaterialSettings[Index] }),
					TArray<FMeshData*>({ &GlobalMeshSettings[Index] }), TempBakeOutputs);

				BakeOutputs.Append(TempBakeOutputs);

				// progress state 70/100 (post loop)
				SlowTask.EnterProgressFrame(progressStep, FText::FromString(FString::Printf(TEXT("Flattening Material (%i/%i)"), Index + 1, GlobalMeshSettings.Num())));
				SlowTask.MakeDialog();
			}
		}

		// progress state 80/100
		SlowTask.EnterProgressFrame(10.0f, NSLOCTEXT("InstaLODUI", "CreateMaterialData_UpdatingMeshData", "Updating Mesh Data"));
		SlowTask.MakeDialog();

		// append constant properties
		TArray<FColor> ConstantData;
		FIntPoint ConstantSize(1, 1);
		for (const FPropertyEntry& Entry : Options->Properties)
		{
			if (Entry.bUseConstantValue && Entry.Property != MP_MAX)
			{
				ConstantData.SetNum(1, false);
				ConstantData[0] = FLinearColor(Entry.ConstantValue, Entry.ConstantValue, Entry.ConstantValue).ToFColor(true);
				for (FBakeOutput& Ouput : BakeOutputs)
				{
					Ouput.PropertyData.Add(Entry.Property, ConstantData);
					Ouput.PropertySizes.Add(Entry.Property, ConstantSize);
				}
			}
		}

		// update face material indices to match new baked material indices
		for (int32 MeshIndex=0; MeshIndex<RawMeshData.Num(); ++MeshIndex)
		{
			FRawMesh& RawMesh = *RawMeshData[MeshIndex];

			TArray<TPair<uint32, uint32>> SectionAndOutputIndices;
			OutputMaterialsMap.MultiFind(MeshIndex, SectionAndOutputIndices);

			TMap<int32, int32> Remap;
			for (const TPair<uint32, uint32>& IndexPair : SectionAndOutputIndices)
			{
				Remap.Add(/*SectionIndex*/IndexPair.Key, /*UniqueMaterialIndex*/IndexPair.Value);
			}

			for (int32& FaceMaterialIndex : RawMesh.FaceMaterialIndices)
			{
				check(Remap.Contains(FaceMaterialIndex));
				FaceMaterialIndex = Remap[FaceMaterialIndex];
			}
		}

		// apply the updated raw mesh data back to the InstaLOD mesh
		for (int32 Index=0; Index<RawMeshData.Num(); ++Index)
		{
			TArray<FVector2D> NewUVs;
			FRawMesh *const ModifiedRawMesh = RawMeshData[Index];
			FMeshDescription *const ModifiedMeshDescription = RawMeshDescriptionData[ModifiedRawMesh];

			check(ModifiedMeshDescription);

			FMeshData *const MeshData = GlobalMeshSettings.FindByPredicate([&](const FMeshData& Entry)
			{
				return Entry.RawMeshDescription == ModifiedMeshDescription && (Entry.CustomTextureCoordinates.Num() || Entry.TextureCoordinateIndex != 0);
			});

			if (MeshData != nullptr)
			{
				NewUVs = MeshData->CustomTextureCoordinates.Num() ? MeshData->CustomTextureCoordinates : ModifiedRawMesh->WedgeTexCoords[MeshData->TextureCoordinateIndex];
			}

			InstaLOD::IInstaLODMesh* InstaLODMesh = MergeData[Index].InstaLODMesh;

			// update texcoords
			if (NewUVs.Num() > 0)
			{
				uint64 WedgeCount = 0;
				InstaLOD::InstaVec2F* InstaLODWedgeTexCoords0 = InstaLODMesh->GetWedgeTexCoords(0, &WedgeCount);
				check(WedgeCount == NewUVs.Num());
				for (int32 WedgeIndex=0; WedgeIndex<WedgeCount; WedgeIndex++)
				{
					InstaLODWedgeTexCoords0[WedgeIndex].X = NewUVs[WedgeIndex].X;
					InstaLODWedgeTexCoords0[WedgeIndex].Y = NewUVs[WedgeIndex].Y;
				}
			}

			// update face material indices
			{
				uint64 FaceCount = 0;
				int32* InstaLODFaceMaterialIndices = InstaLODMesh->GetFaceMaterialIndices(&FaceCount);
				check(FaceCount == ModifiedRawMesh->FaceMaterialIndices.Num());
				for (int32 FaceIndex=0; FaceIndex<FaceCount; FaceIndex++)
				{
					InstaLODFaceMaterialIndices[FaceIndex] = ModifiedRawMesh->FaceMaterialIndices[FaceIndex];
				}
			}

			RawMeshDescriptionData[ModifiedRawMesh] = nullptr;
			RawMeshData[Index] = nullptr;

			delete ModifiedMeshDescription;
			delete ModifiedRawMesh;
		}

		// write unqiue materials
		OutMaterials.Empty();
		for (int32 SettingsIndex=0; SettingsIndex<GlobalMaterialSettings.Num(); SettingsIndex++)
		{
			OutMaterials.Add(GlobalMaterialSettings[SettingsIndex].Material);
		}

		// progress state 90/100
		SlowTask.EnterProgressFrame(10.0f, NSLOCTEXT("InstaLODUI", "CreateMaterialData_FinalizingMaterialData", "Finalizing Material Data"));
		SlowTask.MakeDialog();

		TArray<FFlattenMaterial> FlattenedMaterials;
		TransferOutputToFlatMaterials(GlobalMaterialSettings, BakeOutputs, FlattenedMaterials);

		InstaLOD->ConvertFlattenMaterialsToInstaLODMaterialData(FlattenedMaterials, MaterialData, InMaterialProxySettings);
	}
};

void UInstaLODUtilities::CreateMaterialData(class IInstaLOD* InstaLOD, TArray<InstaLODMergeData>& MergeData, class InstaLOD::IInstaLODMaterialData *MaterialData, const struct FMaterialProxySettings& InMaterialProxySettings, TArray<UMaterialInterface*>& OutMaterials)
{
	// NOTE: we need to avoid calling the constructor of FMeshMergeUtilities
	// otherwise it will rebind delegates to the base class and breaking the proxy job processing.
	// The C cast is a hack, but we're taking care as to not modify the class members or vtable so it should pass
	const IMeshMergeUtilities& Module = FModuleManager::Get().LoadModuleChecked<IMeshMergeModule>("MeshMergeUtilities").GetUtilities();
	((FInstaLODMeshMergeUtilities*)&Module)->CreateMaterialData(InstaLOD, MergeData, MaterialData, InMaterialProxySettings, OutMaterials);
}

bool UInstaLODUtilities::WriteInstaLODMessagesToLog(IInstaLOD* InstaLOD)
{
	check(InstaLOD);
	
	char InstaLog[8192];
	
	if (InstaLOD->GetInstaLOD()->GetMessageLog(InstaLog, sizeof(InstaLog), NULL) == 0)
		return false;
	
	UE_LOG(LogInstaLOD, Error, TEXT("%s"), UTF8_TO_TCHAR(InstaLog));
	
	return true;
}

void UInstaLODUtilities::AppendMeshComponentToInstaLODMesh(IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex)
{
	check(InstaLOD);
	check(OutInstaLODMesh);
	
	if (InstaLOD)
	{
		InstaLOD::IInstaLODMesh* InstaLODMesh = InstaLOD->AllocInstaLODMesh();

		UInstaLODUtilities::GetInstaLODMeshFromMeshComponent(InstaLOD, MeshComponent, InstaLODMesh, BaseLODIndex);

		InstaLOD::IInstaLODMeshExtended* ExtendedMesh = InstaLOD->GetInstaLOD()->CastToInstaLODMeshExtended(OutInstaLODMesh);

		if (ExtendedMesh && InstaLODMesh)
		{
			ExtendedMesh->AppendMesh(InstaLODMesh);
		}
	}
}

UMaterialInstanceConstant* UInstaLODUtilities::CreateFlattenMaterialInstance(const FFlattenMaterial& FlattenMaterial, const FMaterialProxySettings& InMaterialProxySettings, const FString& SaveObjectPath, TArray<UObject*>& OutAssetsToSync, bool bIsFlipbookMaterial)
{
	const FString AssetBasePath = FPackageName::GetLongPackagePath(SaveObjectPath) + TEXT("/");
	const FString AssetBaseName = FPackageName::GetShortName(SaveObjectPath);
	UPackage* InOuter = nullptr;
	
	UMaterial* BaseMaterial = nullptr;
	
	if (bIsFlipbookMaterial)
	{
		BaseMaterial = LoadObject<UMaterial>(NULL, TEXT("/InstaLODMeshReduction/InstaLODFlattenFlipbookMaterial.InstaLODFlattenFlipbookMaterial"), NULL, LOAD_None, NULL);
	}
	else
	{
		BaseMaterial = LoadObject<UMaterial>(NULL, TEXT("/InstaLODMeshReduction/InstaLODFlattenMaterial.InstaLODFlattenMaterial"), NULL, LOAD_None, NULL);
	}
	check(BaseMaterial);
	
	UMaterialInstanceConstant* OutMaterial = FMaterialUtilities::CreateInstancedMaterial(BaseMaterial, nullptr, AssetBasePath + AssetBaseName, RF_Public | RF_Standalone);
	OutAssetsToSync.Add(OutMaterial);
	
	OutMaterial->BasePropertyOverrides.TwoSided = FlattenMaterial.bTwoSided;
	OutMaterial->BasePropertyOverrides.bOverride_TwoSided = FlattenMaterial.bTwoSided != false;
	OutMaterial->BasePropertyOverrides.DitheredLODTransition = FlattenMaterial.bDitheredLODTransition;
	OutMaterial->BasePropertyOverrides.bOverride_DitheredLODTransition = FlattenMaterial.bDitheredLODTransition != false;
	
	if (InMaterialProxySettings.BlendMode != BLEND_Opaque)
	{
		OutMaterial->BasePropertyOverrides.bOverride_BlendMode = true;
		OutMaterial->BasePropertyOverrides.BlendMode = InMaterialProxySettings.BlendMode;
	}
	
	bool bPackMetallic, bPackSpecular, bPackRoughness;
	int32 NumSamples = 0;
	FIntPoint PackedSize;
	const bool bPackTextures = ProxyMaterialUtilities::CalculatePackedTextureData(FlattenMaterial, bPackMetallic, bPackSpecular, bPackRoughness, NumSamples, PackedSize);
	
	const bool bSRGB = true;
	const bool bRGB = false;
	
	FStaticParameterSet NewStaticParameterSet;
	
	// load textures and set switches accordingly
	if (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Diffuse).Num() > 0 &&
		!(FlattenMaterial.IsPropertyConstant(EFlattenMaterialProperties::Diffuse) &&
		  FlattenMaterial.GetPropertySamples(EFlattenMaterialProperties::Diffuse)[0] == FColor::Black))
	{
		TEXTURE_MACRO_VECTOR(Diffuse, TC_Default, bSRGB);
		
		// NOTE: we have to patch the parameter names for the new flatten base material
		FLinearColor Value;
		if (OutMaterial->GetVectorParameterValue(TEXT_IF_UE419("DiffuseConst"), Value))
		{
			OutMaterial->SetVectorParameterValueEditorOnly(TEXT_IF_UE419("BaseColorConst"), Value);
		}
		else
		{
			UTexture *BaseColorTexture = nullptr;
			
			OutMaterial->GetTextureParameterValue(TEXT_IF_UE419("DiffuseTexture"), BaseColorTexture);
			check(BaseColorTexture);
			
			FStaticSwitchParameter& LastParameter = NewStaticParameterSet.StaticSwitchParameters.Last(); 
			LastParameter.ParameterInfo.Name = TEXT_IF_UE419("UseBaseColor"); 
			OutMaterial->SetTextureParameterValueEditorOnly(TEXT_IF_UE419("BaseColorTexture"), BaseColorTexture);
		}
	}
	
	if (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Normal).Num() > 1)
	{
		TEXTURE_MACRO_BASE(Normal, TC_Normalmap, bRGB)
	}
	
	// determine whether or not specific material properties are packed together into one texture (requires at least two to match (number of samples and texture size) in order to be packed
	if (!bPackMetallic && (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Metallic).Num() > 0 || !InMaterialProxySettings.bMetallicMap))
	{
		TEXTURE_MACRO_SCALAR(Metallic, TC_Default, bSRGB);
	}
	
	if (!bPackRoughness && (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Roughness).Num() > 0 || !InMaterialProxySettings.bRoughnessMap))
	{
		TEXTURE_MACRO_SCALAR(Roughness, TC_Default, bSRGB);
	}
	
	if (!bPackSpecular && (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Specular).Num() > 0 || !InMaterialProxySettings.bSpecularMap))
	{
		TEXTURE_MACRO_SCALAR(Specular, TC_Default, bSRGB);
	}
	
	const bool bNonSRGB = false;
	
	if (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Opacity).Num() > 0 || !InMaterialProxySettings.bOpacityMap)
	{
		TEXTURE_MACRO_SCALAR(Opacity, TC_Grayscale, bNonSRGB);
	}
	
	if (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::OpacityMask).Num() > 0 || !InMaterialProxySettings.bOpacityMaskMap)
	{
		TEXTURE_MACRO_SCALAR(OpacityMask, TC_Grayscale, bNonSRGB);
	}
	
	if (FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::AmbientOcclusion).Num() > 0 || !InMaterialProxySettings.bAmbientOcclusionMap)
	{
		TEXTURE_MACRO_SCALAR(AmbientOcclusion, TC_Grayscale, bNonSRGB);
	}
	
	// handle the packed texture if applicable
	if (bPackTextures)
	{
		TArray<FColor> MergedTexture;
		MergedTexture.AddZeroed(NumSamples);
		
		// merge properties into one texture using the separate colour channels
		const EFlattenMaterialProperties Properties[3] = { EFlattenMaterialProperties::Metallic , EFlattenMaterialProperties::Roughness, EFlattenMaterialProperties::Specular};
		
		// property that is not part of the pack (because of a different size), will see is reserve pack space fill with black color.
		const bool PropertyShouldBePack[3] = { bPackMetallic , bPackRoughness , bPackSpecular };
		
		// red mask (all properties are rendered into the red channel)
		FColor NonAlphaRed = FColor::Red;
		NonAlphaRed.A = 0;
		const uint32 ColorMask = NonAlphaRed.DWColor();
		const uint32 Shift[3] = { 0, 8, 16 };
		for (int32 PropertyIndex=0; PropertyIndex<3; ++PropertyIndex)
		{
			const EFlattenMaterialProperties Property = Properties[PropertyIndex];
			const bool HasProperty = PropertyShouldBePack[PropertyIndex] && FlattenMaterial.DoesPropertyContainData(Property) && !FlattenMaterial.IsPropertyConstant(Property);
			
			if (HasProperty)
			{
				const TArray<FColor>& PropertySamples = FlattenMaterial.GetPropertySamples(Property);
				// OR masked values (samples initialized to zero, so no random data)
				for (int32 SampleIndex=0; SampleIndex<NumSamples; ++SampleIndex)
				{
					// black adds the alpha + red channel value shifted into the correct output channel
					MergedTexture[SampleIndex].DWColor() |= (FColor::Black.DWColor() + ((PropertySamples[SampleIndex].DWColor() & ColorMask) >> Shift[PropertyIndex]));
				}
			}
		}
		
		// create texture using the merged property data
		UTexture2D* PackedTexture = FMaterialUtilities::CreateTexture(InOuter, AssetBasePath + TEXT("T_") + AssetBaseName + TEXT("_MRS"),
																	  PackedSize, MergedTexture, TC_Default, TEXTUREGROUP_HierarchicalLOD, RF_Public | RF_Standalone, bSRGB);
		check(PackedTexture);
		OutAssetsToSync.Add(PackedTexture);
		
		// setup switches for whether or not properties will be packed into one texture
		NewStaticParameterSet.StaticSwitchParameters.Add(FStaticSwitchParameter(TEXT_IF_UE419("PackMetallic"), bPackMetallic, true, FGuid()));
		NewStaticParameterSet.StaticSwitchParameters.Add(FStaticSwitchParameter(TEXT_IF_UE419("PackSpecular"), bPackSpecular, true, FGuid()));
		NewStaticParameterSet.StaticSwitchParameters.Add(FStaticSwitchParameter(TEXT_IF_UE419("PackRoughness"), bPackRoughness, true, FGuid()));
		
		// set up switch and texture values
		OutMaterial->SetTextureParameterValueEditorOnly(TEXT_IF_UE419("PackedTexture"), PackedTexture);
	}
	
	// emissive is a special case due to the scaling variable
	if (FlattenMaterial.GetPropertySamples(EFlattenMaterialProperties::Emissive).Num() > 0 &&
		!(FlattenMaterial.GetPropertySize(EFlattenMaterialProperties::Emissive).Num() == 1 && FlattenMaterial.GetPropertySamples(EFlattenMaterialProperties::Emissive)[0] == FColor::Black))
	{
		TEXTURE_MACRO_VECTOR_LINEAR(Emissive, TC_Default, bRGB);
		
		// NOTE: we have to patch the parameter names for the new flatten base material
		FLinearColor Value;
		if (OutMaterial->GetVectorParameterValue(TEXT_IF_UE419("EmissiveConst"), Value))
		{
			OutMaterial->SetVectorParameterValueEditorOnly(TEXT_IF_UE419("EmissiveColorConst"), Value);
		}
		else
		{
			UTexture *BaseColorTexture = nullptr;
			
			OutMaterial->GetTextureParameterValue(TEXT_IF_UE419("EmissiveTexture"), BaseColorTexture);
			check(BaseColorTexture);
			
			FStaticSwitchParameter& LastParameter = NewStaticParameterSet.StaticSwitchParameters.Last(); 
			LastParameter.ParameterInfo.Name = TEXT_IF_UE419("UseEmissiveColor"); 
			
			OutMaterial->SetTextureParameterValueEditorOnly(TEXT_IF_UE419("EmissiveColorTexture"), BaseColorTexture);
		}
		
		if (FlattenMaterial.EmissiveScale != 1.0f)
		{
			OutMaterial->SetScalarParameterValueEditorOnly(TEXT_IF_UE419("EmissiveScale"), FlattenMaterial.EmissiveScale);
		}
	}
	
	// force initializing the static permutations according to the switches we have set
	OutMaterial->UpdateStaticPermutation(NewStaticParameterSet);
	OutMaterial->InitStaticPermutation();
	
	OutMaterial->PostEditChange();
	
	return OutMaterial;
}

void UInstaLODUtilities::GetInstaLODMeshFromMeshComponent(IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex, bool IsStaticMeshInWorldSpaceRequired)
{
	check(InstaLOD);
	check(OutInstaLODMesh);
	
	if (MeshComponent->StaticMeshComponent.IsValid())
	{
		UInstaLODUtilities::GetInstaLODMeshFromStaticMeshComponent(InstaLOD, MeshComponent->StaticMeshComponent.Get(), OutInstaLODMesh, BaseLODIndex, IsStaticMeshInWorldSpaceRequired);
	}
	else if (MeshComponent->SkeletalMeshComponent.IsValid())
	{
		UInstaLODUtilities::GetInstaLODMeshFromSkeletalMeshComponent(InstaLOD, MeshComponent->SkeletalMeshComponent.Get(), OutInstaLODMesh, BaseLODIndex);
	}
	else
	{
		UE_LOG(LogInstaLOD, Error, TEXT("MeshComponent without valid StaticMesh or SkeletalMesh."));
	}
}

void UInstaLODUtilities::RetrieveMesh(UStaticMeshComponent *const StaticMeshComponent, int32 LODIndex, FMeshDescription& OutMeshDescription, bool bPropagateVertexColours, bool bInWorldSpace)
{
	const UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh();
	const FStaticMeshSourceModel& StaticMeshModel = StaticMesh->GetSourceModel(LODIndex);
	// Imported meshes will have a valid mesh description
	const bool bImportedMesh = StaticMesh->IsMeshDescriptionValid(LODIndex);

	// Export the raw mesh data using static mesh render data
	FMeshMergeHelpers::ExportStaticMeshLOD(StaticMesh->RenderData->LODResources[LODIndex], OutMeshDescription, StaticMesh->StaticMaterials);

	// Make sure the raw mesh is not irreparably malformed.
	if (OutMeshDescription.VertexInstances().Num() <= 0)
	{
		return;
	}

	// Use build settings from base mesh for LOD entries that was generated inside Editor.
	const FMeshBuildSettings& BuildSettings = bImportedMesh ? StaticMeshModel.BuildSettings : StaticMesh->GetSourceModel(0).BuildSettings;

	// Transform raw mesh to world space
	FTransform ComponentToWorldTransform = StaticMeshComponent->GetComponentTransform();

	// If specified propagate painted vertex colors into our raw mesh
	if (bPropagateVertexColours)
	{
		FMeshMergeHelpers::PropagatePaintedColorsToRawMesh(StaticMeshComponent, LODIndex, OutMeshDescription);
	}

	if (bInWorldSpace)
	{
		// Transform raw mesh vertex data by the Static Mesh Component's component to world transformation	
		FMeshMergeHelpers::TransformRawMeshVertexData(ComponentToWorldTransform, OutMeshDescription);
	}

	if (OutMeshDescription.VertexInstances().Num() <= 0)
	{
		return;
	}

	// Figure out if we should recompute normals and tangents. By default generated LODs should not recompute normals	
	EComputeNTBsFlags TangentOptions = EComputeNTBsFlags::BlendOverlappingNormals;
	if (BuildSettings.bRemoveDegenerates)
	{
		// If removing degenerate triangles, ignore them when computing tangents.
		TangentOptions |= EComputeNTBsFlags::IgnoreDegenerateTriangles;
	}
	 
	if(BuildSettings.bUseMikkTSpace)
	{
		TangentOptions |= EComputeNTBsFlags::UseMikkTSpace;
	}

	// NOTE: if the function actually recalulcates the normals, it will do so by using the polygon normals 
	if(BuildSettings.bRecomputeNormals)
	{
		TangentOptions |= EComputeNTBsFlags::Normals;
		
		TPolygonAttributesRef<FVector> PolygonNormals = OutMeshDescription.PolygonAttributes().GetAttributesRef<FVector>(MeshAttribute::Polygon::Normal);
		bool bRecreateFaceNormals = false;

		// make sure valid polygon normals are set
		if(PolygonNormals.GetNumElements() != OutMeshDescription.Polygons().Num())
		{
			bRecreateFaceNormals = true;
		}
		else 
		{	
			// check validity of face normals
			const float Threshold = 0.1f;
			for (const FPolygonID& PolygonID : OutMeshDescription.Polygons().GetElementIDs())
			{
				if(PolygonNormals[PolygonID].ContainsNaN() || PolygonNormals[PolygonID].IsNearlyZero(Threshold))
				{
					bRecreateFaceNormals = true;
					break;
				}
			}
		}

		if(bRecreateFaceNormals)
		{
			FStaticMeshOperations::ComputePolygonTangentsAndNormals(OutMeshDescription, 0.0f);
		}
	}

	FStaticMeshOperations::RecomputeNormalsAndTangentsIfNeeded(OutMeshDescription, (EComputeNTBsFlags) TangentOptions);
}

void UInstaLODUtilities::GetInstaLODMeshFromStaticMeshComponent(IInstaLOD* InstaLOD, UStaticMeshComponent* StaticMeshComponent, InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex, bool bWorldSpace)
{
	check(InstaLOD);
	check(StaticMeshComponent);
	check(OutInstaLODMesh);

	// load the MeshDescription and convert it to an InstaLOD Mesh
	FMeshDescription NewMeshDescription;

	FStaticMeshAttributes MeshAttributes(NewMeshDescription);
	MeshAttributes.Register();

	// NOTE: Register mesh attributes doesn't register polygon attributes for normals
	// to avoid an assert in Unreals internal normal recalculation we register them by hand
	NewMeshDescription.PolygonAttributes().RegisterAttribute<FVector>(MeshAttribute::Polygon::Normal, 1, FVector::ZeroVector, EMeshAttributeFlags::Transient);
	NewMeshDescription.PolygonAttributes().RegisterAttribute<FVector>(MeshAttribute::Polygon::Tangent, 1, FVector::ZeroVector, EMeshAttributeFlags::Transient);
	NewMeshDescription.PolygonAttributes().RegisterAttribute<FVector>(MeshAttribute::Polygon::Binormal, 1, FVector::ZeroVector, EMeshAttributeFlags::Transient);

	UStaticMesh *const StaticMesh = StaticMeshComponent->GetStaticMesh();

	BaseLODIndex = FMath::Clamp(BaseLODIndex, 0, StaticMesh->GetNumSourceModels() - 1);
	FMeshBuildSettings BuildSettings = StaticMesh->GetSourceModel(BaseLODIndex).BuildSettings;

	// retrieve data
	{
		UInstaLODUtilities::RetrieveMesh(StaticMeshComponent, BaseLODIndex, NewMeshDescription, true, bWorldSpace);
	}

	// fallback to LOD 0 
	if (NewMeshDescription.IsEmpty())
	{
		UInstaLODUtilities::RetrieveMesh(StaticMeshComponent, 0, NewMeshDescription, true, bWorldSpace);
		BuildSettings = StaticMesh->GetSourceModel(0).BuildSettings;
	}

	if (NewMeshDescription.IsEmpty())
	{
		OutInstaLODMesh->Clear();
		return;
	}
	
	// if necessary, recompute tangent basis
	{
		// NOTE: check if there are any normals/tangents or binormal signs set in the MeshDescription
		TVertexInstanceAttributesRef<FVector> VertexInstanceNormals = MeshAttributes.GetVertexInstanceNormals();
		TVertexInstanceAttributesRef<FVector> VertexInstanceTangents = MeshAttributes.GetVertexInstanceTangents();
		TVertexInstanceAttributesRef<float> VertexInstanceBinormalSigns = MeshAttributes.GetVertexInstanceBinormalSigns();

		const bool bRecomputeNormals = BuildSettings.bRecomputeNormals || VertexInstanceNormals.GetNumElements() == 0;
		const bool bRecomputeTangents = BuildSettings.bRecomputeTangents || VertexInstanceTangents.GetNumElements() == 0 || VertexInstanceBinormalSigns.GetNumElements() == 0;

		if (bRecomputeNormals || bRecomputeTangents)
		{
			FStaticMeshOperations::ComputePolygonTangentsAndNormals(NewMeshDescription, 0.0f);
			EComputeNTBsFlags NormalFlags = EComputeNTBsFlags::UseMikkTSpace | EComputeNTBsFlags::BlendOverlappingNormals | EComputeNTBsFlags::Tangents ;
			
			if (bRecomputeNormals)
			{
				NormalFlags |= EComputeNTBsFlags::Normals;
			}
			FStaticMeshOperations::ComputeTangentsAndNormals(NewMeshDescription, NormalFlags);
		}
	}

	InstaLOD->ConvertMeshDescriptionToInstaLODMesh(NewMeshDescription, OutInstaLODMesh);
}

void UInstaLODUtilities::GetInstaLODMeshFromSkeletalMeshComponent(IInstaLOD* InstaLOD, USkeletalMeshComponent* SkeletalMeshComponent, InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex, UAnimSequence *const BakePose)
{
	check(InstaLOD);
	check(SkeletalMeshComponent);
	check(OutInstaLODMesh);
	
	USkeletalMesh *const SkeletalMesh = SkeletalMeshComponent->SkeletalMesh;
	check(SkeletalMesh);
	 
	if (BaseLODIndex < 0 || BaseLODIndex > SkeletalMesh->GetLODInfoArray().Num()) 
	{
		// FIXME: handle error
		return;
	}

	UE4_SkeletalBakePoseData BakePoseData;

	if(BakePose != nullptr)
	{
		BakePoseData.BakePoseAnimation = BakePose;
		BakePoseData.ReferenceSkeleton = &SkeletalMesh->RefSkeleton;
		BakePoseData.SkeletalMesh = SkeletalMesh;
	}
	 
	IInstaLOD::UE4_SkeletalMeshResource *const SkeletalMeshResource = SkeletalMesh->GetImportedModel();
	InstaLOD->ConvertSkeletalLODModelToInstaLODMesh(SkeletalMeshResource->LODModels[0], OutInstaLODMesh, BakePose != nullptr ? &BakePoseData : nullptr);
}

void UInstaLODUtilities::TransformInstaLODMesh(InstaLOD::IInstaLODMesh* InstaLODMesh, const FTransform& Transform, bool LocalToWorld)
{
	check(InstaLODMesh);
	check(InstaLODMesh->IsValid());
	
	uint64 VertexCount, WedgeCount;
	
	InstaLOD::InstaVec3F *const Vertices = InstaLODMesh->GetVertexPositions(&VertexCount);
	InstaLOD::InstaVec3F *const WedgeNormals = InstaLODMesh->GetWedgeNormals(&WedgeCount);
	InstaLOD::InstaVec3F *const WedgeBinormals = InstaLODMesh->GetWedgeBinormals(nullptr);
	InstaLOD::InstaVec3F *const WedgeTangents = InstaLODMesh->GetWedgeTangents(nullptr);
	
	if (LocalToWorld)
	{
		for(uint64 VertexIndex=0; VertexIndex<VertexCount; VertexIndex++)
		{
			Vertices[VertexIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.TransformPosition(InstaLODVectorHelper::InstaVecToFVector(Vertices[VertexIndex])));
		}

		for(uint64 WedgeIndex=0; WedgeIndex<WedgeCount; WedgeIndex++)
		{
			WedgeNormals[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.TransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeNormals[WedgeIndex])).GetSafeNormal());
			WedgeBinormals[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.TransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeBinormals[WedgeIndex])).GetSafeNormal());
			WedgeTangents[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.TransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeTangents[WedgeIndex])).GetSafeNormal());
		}
	}
	else
	{
		for(uint64 VertexIndex=0; VertexIndex<VertexCount; VertexIndex++)
		{
			Vertices[VertexIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.InverseTransformPosition(InstaLODVectorHelper::InstaVecToFVector(Vertices[VertexIndex])));
		}
		
		for(uint64 WedgeIndex=0; WedgeIndex<WedgeCount; WedgeIndex++)
		{
			WedgeNormals[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.InverseTransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeNormals[WedgeIndex])).GetSafeNormal());
			WedgeBinormals[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.InverseTransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeBinormals[WedgeIndex])).GetSafeNormal());
			WedgeTangents[WedgeIndex] = InstaLODVectorHelper::FVectorToInstaVec(Transform.InverseTransformVector(InstaLODVectorHelper::InstaVecToFVector(WedgeTangents[WedgeIndex])).GetSafeNormal());
		}
	}
	
	// handle mirrored transforms
	if (Transform.GetDeterminant() < 0.0f)
	{
		static_cast<InstaLOD::IInstaLODMeshExtended*>(InstaLODMesh)->ReverseFaceDirections(/*flipNormals*/false);
	}
}

UTexture* UInstaLODUtilities::ConvertInstaLODTexturePageToTexture(InstaLOD::IInstaLODTexturePage* InstaLODTexturePage, const FString& SaveObjectPath)
{
	check(InstaLODTexturePage);
	
	const FString AssetBaseName = FPackageName::GetShortName(SaveObjectPath);
	const FString AssetBasePath = FPackageName::GetLongPackagePath(SaveObjectPath) + TEXT("/");
	
	TextureCompressionSettings TextureCompression = TC_Default;
	const bool bIsSRGB = false;
	const bool bDither = false;
	
	TArray<FColor> PixelData;
	PixelData.SetNumUninitialized(InstaLODTexturePage->GetWidth() * InstaLODTexturePage->GetHeight());
	
	
	// NOTE: texture data always needs to be 8bpp RGBA
	// if (InstaLODTexturePage->GetComponentType() != InstaLOD::IInstaLODTexturePage::ComponentTypeUInt8 ||
	//	InstaLODTexturePage->GetPixelType() != InstaLOD::IInstaLODTexturePage::PixelTypeRGBA)
	{
		if (bDither)
			InstaLODTexturePage->Dither(InstaLOD::IInstaLODTexturePage::ComponentTypeUInt8);
		
		const uint32 Width = InstaLODTexturePage->GetWidth();
		const uint32 Height = InstaLODTexturePage->GetHeight();
		
		FColor *OutData = PixelData.GetData();
		
		for (uint32 Y=0; Y<Height; Y++)
		{
			for(uint32 X=0; X<Width; X++)
			{
				const InstaLOD::InstaColorRGBAF32 Color = InstaLODTexturePage->SampleFloat(X, Y);
				*OutData++ = FLinearColor(Color.R, Color.G, Color.B, Color.A).ToFColor(false);
			}
		}
	}
	
	if (InstaLODTexturePage->GetType() == InstaLOD::IInstaLODTexturePage::TypeDisplacementMap ||
		InstaLODTexturePage->GetType() == InstaLOD::IInstaLODTexturePage::TypeCurvatureMap ||
		InstaLODTexturePage->GetType() == InstaLOD::IInstaLODTexturePage::TypeThicknessMap)
	{
		TextureCompression = TC_Grayscale;
	}
	else if (InstaLODTexturePage->GetType() == InstaLOD::IInstaLODTexturePage::TypeBentNormals ||
		InstaLODTexturePage->GetType() == InstaLOD::IInstaLODTexturePage::TypeNormalMapObjectSpace)
	{
		TextureCompression = TC_Normalmap;
	}
	
	UTexture2D *const Texture = FMaterialUtilities::CreateTexture(nullptr, AssetBasePath + AssetBaseName,
																  FIntPoint(InstaLODTexturePage->GetWidth(), InstaLODTexturePage->GetHeight()),
																  PixelData,
																  TextureCompression,
																  TEXTUREGROUP_HierarchicalLOD, RF_Public | RF_Standalone,
																  bIsSRGB);
	
	
	if (Texture == nullptr)
		return nullptr;
	
	Texture->PostEditChange();
	return Texture;
}

void UInstaLODUtilities::InsertLODToMeshComponent(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial)
{
	// check if it's a Static Mesh or Skeletal Mesh
	if (MeshComponent->StaticMeshComponent.IsValid())
	{
		UInstaLODUtilities::InsertLODToStaticMesh(InstaLOD, MeshComponent->StaticMeshComponent->GetStaticMesh(), InstaLODMesh, TargetLODIndex, NewMaterial);
	}
	else if (MeshComponent->SkeletalMeshComponent.IsValid())
	{
		UInstaLODUtilities::InsertLODToSkeletalMesh(InstaLOD, MeshComponent->SkeletalMeshComponent->SkeletalMesh, InstaLODMesh, TargetLODIndex, NewMaterial);
	}
}

void UInstaLODUtilities::InsertLODToStaticMesh(IInstaLOD* InstaLOD, UStaticMesh* StaticMesh, InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial)
{
	check(InstaLOD);
	check(StaticMesh);
	check(InstaLODMesh);

	FMeshSectionInfoMap SectionInfoMap = StaticMesh->GetSectionInfoMap();

	// no TargetLODIndex Specified, so we assume the user wants to add to the existing LODs
	if (TargetLODIndex < 0)
	{
		TargetLODIndex = StaticMesh->GetNumSourceModels();
	}

	const int32 BaseLOD = 0;

	if (StaticMesh->LODGroup != NAME_None)
	{
		UE_LOG(LogInstaLOD, Log, TEXT("Changing LODGroup for mesh from '%s' to 'None'."), *StaticMesh->LODGroup.ToString());
		StaticMesh->GenerateLodsInPackage();

		// NOTE: GenerateLodsInPackage does not properly copy the BuildSettings from LOD0 to the LODs
		// now baked into the package, so we have to fix this
		for (int32 Index=1; Index<StaticMesh->GetNumSourceModels(); Index++)
		{
			StaticMesh->GetSourceModel(Index).BuildSettings = StaticMesh->GetSourceModel(BaseLOD).BuildSettings;
		}
	}

	FStaticMeshSourceModel* SourceModel = nullptr;
	if (TargetLODIndex >= 0 && TargetLODIndex < StaticMesh->GetNumSourceModels())
	{
		// override Existing
		SourceModel = &StaticMesh->GetSourceModel(TargetLODIndex);
	}
	else
	{
		// add new LOD
		SourceModel = new (StaticMesh->GetSourceModels()) FStaticMeshSourceModel();
	}

	// convert the mesh back
	SourceModel->MeshDescription = MakeUnique<FMeshDescription>();
	FMeshDescription& NewMeshDescription = *SourceModel->MeshDescription.Get();
	FStaticMeshAttributes(NewMeshDescription).Register();
	TMap<int32, FName> MaterialMapOut;
	TMap<FName, int32> MaterialMapIn;

	// if we want to insert a new material, we have to update the face mat indices
	if (NewMaterial != nullptr)
	{
		const int32 NewMaterialIndex = StaticMesh->StaticMaterials.Num();
		FStaticMaterial NewStaticMaterial(NewMaterial);
		StaticMesh->StaticMaterials.Add(NewStaticMaterial);

		uint64 MaterialIndexCount = 0;
		InstaLOD::InstaMaterialID *const materialIndices = InstaLODMesh->GetFaceMaterialIndices(&MaterialIndexCount);

		// replace material indices in InstaLODMesh, with new index
		for (uint32 i=0; i<MaterialIndexCount; i++)
		{
			materialIndices[i] = InstaLOD::InstaMaterialID(NewMaterialIndex);
		}

		MaterialMapOut.Add(NewMaterialIndex, NewStaticMaterial.MaterialSlotName);
		MaterialMapIn.Add(NewStaticMaterial.MaterialSlotName, NewMaterialIndex);
	}

	InstaLOD->ConvertInstaLODMeshToMeshDescription(InstaLODMesh, MaterialMapOut, NewMeshDescription);

	if (NewMaterial == nullptr)
	{
		// we don't need the slot name as the polygongroupid correspondents to the materialindex
		const FPolygonGroupArray::TElementIDs& PolygonGroupIDs = NewMeshDescription.PolygonGroups().GetElementIDs();
		for (const FPolygonGroupID& PolygonGroupID : PolygonGroupIDs)
		{
			MaterialMapOut.Add(PolygonGroupID.GetValue(), FName());
		}
	}

	// save to bulk
	if (SourceModel->MeshDescription.IsValid())
	{
		SourceModel->MeshDescriptionBulkData = MakeUnique<FMeshDescriptionBulkData>();
		SourceModel->MeshDescriptionBulkData->SaveMeshDescription(NewMeshDescription);

		// NOTE: this may be removed in future updates
		SourceModel->RawMeshBulkData->Empty();
		FRawMesh NewRawMesh;
		FStaticMeshOperations::ConvertToRawMesh(NewMeshDescription, NewRawMesh, MaterialMapIn);
		SourceModel->RawMeshBulkData->SaveRawMesh(NewRawMesh);
	}
	
	SourceModel->BuildSettings = StaticMesh->GetSourceModel(BaseLOD).BuildSettings;

	SourceModel->BuildSettings.bRecomputeNormals = false;
	SourceModel->BuildSettings.bRecomputeTangents = false;
	SourceModel->BuildSettings.bRemoveDegenerates = false;
	SourceModel->BuildSettings.BuildScale3D = FVector(1, 1, 1);

	// rebuild section info map
	if (NewMaterial != nullptr || SectionInfoMap.Map.Num() == 0)
	{
		TArray<int32> UniqueMaterialIndices;
		TArray<int32> MaterialIndices;
		MaterialMapOut.GetKeys(MaterialIndices);

		for (int32 MaterialIndex : MaterialIndices)
		{
			UniqueMaterialIndices.AddUnique(MaterialIndex);
		}

		FMeshSectionInfoMap OriginalSectionInfoMap = StaticMesh->GetOriginalSectionInfoMap();

		if (OriginalSectionInfoMap.Map.Num() == 0)
		{
			int32 SectionIndex = 0;
			for (int32 UniqueMaterialIndex : UniqueMaterialIndices)
			{
				SectionInfoMap.Set(TargetLODIndex, SectionIndex, FMeshSectionInfo(UniqueMaterialIndex));
				SectionIndex++;
			}
		}
		else
		{
			int32 SectionIndex = 0;
			for (int32 UniqueMaterialIndex : UniqueMaterialIndices)
			{
				if (OriginalSectionInfoMap.IsValidSection(0, UniqueMaterialIndex))
				{
					const FMeshSectionInfo SectionInfo = OriginalSectionInfoMap.Get(0, UniqueMaterialIndex);
					SectionInfoMap.Set(TargetLODIndex, SectionIndex, FMeshSectionInfo(SectionInfo.MaterialIndex));
				}
				else
				{
					SectionInfoMap.Set(TargetLODIndex, SectionIndex, FMeshSectionInfo(UniqueMaterialIndex));
				}
				SectionIndex++;
			}
		}
	}
	else
	{
		TArray<int32> UniqueMaterialIndices;
		TArray<int32> MaterialIndices;
		MaterialMapOut.GetKeys(MaterialIndices);

		for (int32 MaterialIndex : MaterialIndices)
		{
			UniqueMaterialIndices.AddUnique(MaterialIndex);
		}

		for (int32 SectionIndex=0; SectionIndex<UniqueMaterialIndices.Num(); SectionIndex++)
		{
			if (SectionInfoMap.IsValidSection(BaseLOD, UniqueMaterialIndices[SectionIndex]))
			{
				FMeshSectionInfo SectionInfo = SectionInfoMap.Get(TargetLODIndex, UniqueMaterialIndices[SectionIndex]);
				if (SectionInfoMap.IsValidSection(TargetLODIndex, SectionIndex))
				{
					FMeshSectionInfo OriginalLODSectionInfo = SectionInfoMap.Get(TargetLODIndex, SectionIndex);
					if (OriginalLODSectionInfo.MaterialIndex == SectionInfo.MaterialIndex)
					{
						SectionInfo.bCastShadow = OriginalLODSectionInfo.bCastShadow;
						SectionInfo.bEnableCollision = OriginalLODSectionInfo.bEnableCollision;
					}
				}
				StaticMesh->GetSectionInfoMap().Set(TargetLODIndex, SectionIndex, SectionInfo);
			}
		}
	}

	StaticMesh->GetSectionInfoMap().CopyFrom(SectionInfoMap);

	// On index 0 the original map needs to be reset to the current
	if (TargetLODIndex == 0)
	{
		StaticMesh->GetOriginalSectionInfoMap().CopyFrom(SectionInfoMap);
	}
	StaticMesh->ImportVersion = EImportStaticMeshVersion::LastVersion;
	StaticMesh->Build();
	StaticMesh->PostEditChange();
	StaticMesh->MarkPackageDirty();
}

void UInstaLODUtilities::InsertLODToSkeletalMesh(IInstaLOD* InstaLOD, USkeletalMesh* SkeletalMesh, InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial)
{
	if (InstaLOD && SkeletalMesh)
	{
		// release resources, otherwise we crash on delete of the LODModel if LODIndex is already used
		SkeletalMesh->ReleaseResources();
		SkeletalMesh->ReleaseResourcesFence.Wait();
		
		// get default resource 
		IInstaLOD::UE4_SkeletalMeshResource *const SkeletalMeshResource = SkeletalMesh->GetImportedModel(); 

		// no TargetLODIndex Specified, so we assume the user wants to add to the existing LODs
		// also make sure we only add to existing LODs and don't allow more than + 1
		if (TargetLODIndex < 0 || TargetLODIndex > SkeletalMeshResource->LODModels.Num())
		{
			TargetLODIndex = SkeletalMeshResource->LODModels.Num();
		}
		
		// NOTE: we are either inserting or replacing the model in this index
		// all meshes that have this LOD index as baseModel can't rely that this 
		// mesh is the actual source, we just replace the source mesh with base index 0 
		if(TargetLODIndex != SkeletalMeshResource->LODModels.Num())
		{
			for(int32 LODInfoIndex=0; LODInfoIndex<SkeletalMeshResource->LODModels.Num(); LODInfoIndex++)
			{
				if(LODInfoIndex == TargetLODIndex)
					continue;

				FSkeletalMeshLODInfo *const LODInfo = SkeletalMesh->GetLODInfo(LODInfoIndex);
				check(LODInfo);
				
				if(LODInfo->ReductionSettings.BaseLOD != TargetLODIndex)
					continue;

				LODInfo->ReductionSettings.BaseLOD = 0;
			}
		}

		// we need the base LOD index to copy settings from
		const int32 BaseLOD = FMath::Max(TargetLODIndex - 1, 0);

		if (!SkeletalMesh->GetLODInfoArray().IsValidIndex(TargetLODIndex))
		{
			SkeletalMesh->AddLODInfo();
		}
		
		IInstaLOD::UE4_StaticLODModel *const OutputLODModel = new IInstaLOD::UE4_StaticLODModel();

		if (!SkeletalMeshResource->LODModels.IsValidIndex(TargetLODIndex))
		{
			SkeletalMeshResource->LODModels.Add(OutputLODModel);
		}
		else
		{
			if (SkeletalMeshResource->LODModels.GetData()[TargetLODIndex] != nullptr)
			{
				// unbind cloth if bound to lod at index
				InstaLOD->UnbindClothAtLODIndex(SkeletalMesh, TargetLODIndex);

				// delete the previous Model
				delete SkeletalMeshResource->LODModels.GetData()[TargetLODIndex]; 
			}
			
			SkeletalMeshResource->LODModels.GetData()[TargetLODIndex] = OutputLODModel;
		}
		
		// copy settings from BaseLOD
		SkeletalMesh->GetLODInfoArray()[TargetLODIndex] = SkeletalMesh->GetLODInfoArray()[BaseLOD];

		// NOTE: the new Reduction settings have optimization percentage set to 0 to avoid regeneration
		FSkeletalMeshOptimizationSettings DefaultOptimizationSettings = FSkeletalMeshOptimizationSettings();
		DefaultOptimizationSettings.NumOfTrianglesPercentage = 1.0f;
		DefaultOptimizationSettings.NumOfVertPercentage = 1.0f;
		SkeletalMesh->GetLODInfoArray()[TargetLODIndex].ReductionSettings = DefaultOptimizationSettings;

		if (SkeletalMesh->GetLODInfoArray()[TargetLODIndex].ScreenSize.Default <= 0.0f)
		{
			// some meshes have 0.0 as screensize, use 0.5 in these cases as we're typically LOD1
			SkeletalMesh->GetLODInfoArray()[TargetLODIndex].ScreenSize = FPerPlatformFloat(0.5f);
		}
		else
		{
			// NOTE: use half the screen size of our base LOD
			SkeletalMesh->GetLODInfoArray()[TargetLODIndex].ScreenSize = FPerPlatformFloat(SkeletalMesh->GetLODInfoArray()[TargetLODIndex].ScreenSize.Default * 0.5f);
		} 

		// if we have a custom material we have to insert it and update the face indices
		// to make the process easier, we do this on the InstaLODMesh before building the skeletal mesh
		if (NewMaterial != nullptr)
		{
			const int32 NewMaterialIndex = SkeletalMesh->Materials.Num();
			SkeletalMesh->Materials.Add(FSkeletalMaterial(NewMaterial));
			
			uint64 FaceCount;
			int32 *const FaceMaterials = InstaLODMesh->GetFaceMaterialIndices(&FaceCount);
			for (uint64 FaceIndex=0; FaceIndex<FaceCount; FaceIndex++)
			{
				FaceMaterials[FaceIndex] = NewMaterialIndex;
			}
		}

		// convert the InstaLODMesh back and use the previously created LODModel that we already added to the TargetLODIndex
		InstaLOD->ConvertInstaLODMeshToSkeletalLODModel(InstaLODMesh, SkeletalMesh, *OutputLODModel);

		// mark the Mesh and LOD (not as simplified to avoid regeneration)
		SkeletalMesh->GetLODInfoArray()[TargetLODIndex].bHasBeenSimplified = false; 
		SkeletalMesh->bHasBeenSimplified = true;

		OutputLODModel->SyncronizeUserSectionsDataArray();

		// reinit the resources after we cleaned them up earlier in the process
		SkeletalMesh->PostEditChange();
		SkeletalMesh->InitResources();

		// calculate the required bones
		SkeletalMesh->CalculateRequiredBones(*OutputLODModel, SkeletalMesh->RefSkeleton, nullptr);
		SkeletalMesh->MarkPackageDirty();
	}
}

void UInstaLODUtilities::UpdateMeshOfMeshComponent(TSharedPtr<FInstaLODMeshComponent> MeshComponent, UObject* NewMesh, bool bRemoveOverrideMaterials)
{
	if (NewMesh == nullptr)
		return;

	if (MeshComponent->StaticMeshComponent.IsValid())
	{
		UStaticMesh* NewStaticMesh = Cast<UStaticMesh>(NewMesh);
		check(NewStaticMesh);
		
		MeshComponent->StaticMeshComponent->SetStaticMesh(NewStaticMesh);
	}
	else if (MeshComponent->SkeletalMeshComponent.IsValid())
	{
		USkeletalMesh* NewSkeletalMesh = Cast<USkeletalMesh>(NewMesh);
		check(NewSkeletalMesh);
		
		MeshComponent->SkeletalMeshComponent->SetSkeletalMesh(NewSkeletalMesh);
	}
	
	// remove all override materials
	if (bRemoveOverrideMaterials)
	{
		UMeshComponent *const MeshComponentBase = Cast<UMeshComponent>(MeshComponent->GetComponent());
		check(MeshComponentBase);
		
		MeshComponentBase->EmptyOverrideMaterials();
		MeshComponentBase->PostEditChange();
	}
}

UObject* UInstaLODUtilities::SaveInstaLODMeshToDuplicateAsset(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, InstaLOD::IInstaLODMesh* InstaLODMesh, const FString& SaveObjectPath, bool clearMaterialAndSectionInfo)
{
	FAssetToolsModule& AssetTools = FAssetToolsModule::GetModule();
	
	const FString AssetBasePath = FPackageName::GetLongPackagePath(SaveObjectPath);
	const FString AssetBaseName = FPackageName::GetShortName(SaveObjectPath);
	
	UObject* OriginalAsset = nullptr;
	UObject* DuplicatedAsset = nullptr;

	if (MeshComponent->StaticMeshComponent.IsValid())
	{
		OriginalAsset = MeshComponent->StaticMeshComponent->GetStaticMesh();
		DuplicatedAsset = AssetTools.Get().DuplicateAsset(AssetBaseName, AssetBasePath, OriginalAsset);
		
		if (DuplicatedAsset == nullptr)
			return nullptr;
		
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(DuplicatedAsset);

		// we want to make sure that we remove all existing LODs, as this new Mesh should only contain the LOD 0
		UInstaLODUtilities::RemoveAllLODsFromStaticMesh(StaticMesh);

		// if a new material is generated the section info map should be cleared beforehand
		if (clearMaterialAndSectionInfo)
		{
			StaticMesh->GetOriginalSectionInfoMap().Clear();
			StaticMesh->GetSectionInfoMap().Clear();
			StaticMesh->StaticMaterials.Empty();
		}
		else
		{
			// NOTE: we need the original section info map to rebuild the section to material index mapping
			StaticMesh->GetOriginalSectionInfoMap().CopyFrom(StaticMesh->GetSectionInfoMap());
			StaticMesh->GetSectionInfoMap().Clear();
		}
		UInstaLODUtilities::InsertLODToStaticMesh(InstaLOD, StaticMesh, InstaLODMesh, 0, nullptr);
	}
	else if (MeshComponent->SkeletalMeshComponent.IsValid())
	{
		OriginalAsset = MeshComponent->SkeletalMeshComponent->SkeletalMesh;
		DuplicatedAsset = AssetTools.Get().DuplicateAsset(AssetBaseName, AssetBasePath, OriginalAsset);
		
		if (DuplicatedAsset == nullptr)
			return nullptr;
		
		USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(DuplicatedAsset);

		// we want to make sure that we remove all existing LODs, as this new Mesh should only contain the LOD 0
		UInstaLODUtilities::RemoveAllLODsFromSkeletalMesh(SkeletalMesh);

		// insert the InstaLODMesh to LODIndex 0
		UInstaLODUtilities::InsertLODToSkeletalMesh(InstaLOD, SkeletalMesh, InstaLODMesh, 0, nullptr);
	}

	return DuplicatedAsset;
}

InstaLOD::IInstaLODMesh* UInstaLODUtilities::CreatePlane(class IInstaLOD* InstaLOD, const float Width)
{
	check(InstaLOD);
	using namespace InstaLOD;
	
	const int32 PositionCount = 4;
	const int32 WedgeCount = 6;
	const int32 FaceCount = 2;
	const float Extent = Width * 0.5f;
	
	IInstaLODMesh *const InstaMesh = InstaLOD->AllocInstaLODMesh();
	InstaMesh->SetMeshFormatType(InstaLOD::MeshFormat::DirectX);
	InstaMesh->SetFrontFaceWindingOrder(InstaLOD::IInstaLODMesh::WindingOrderClockwise);
	InstaMesh->ResizeVertexPositions(PositionCount);
	InstaMesh->ResizeWedgeNormals(WedgeCount);
	InstaMesh->ResizeWedgeTexCoords(0, WedgeCount);
	InstaMesh->ResizeWedgeIndices(WedgeCount);
	InstaMesh->ResizeWedgeTangents(WedgeCount);
	InstaMesh->ResizeWedgeBinormals(WedgeCount);
	InstaMesh->ResizeFaceSmoothingGroups(FaceCount);
	InstaMesh->ResizeFaceSubMeshIndices(FaceCount);
	InstaMesh->ResizeFaceMaterialIndices(FaceCount);
	
	InstaVec3F *const VertexPositions = InstaMesh->GetVertexPositions(nullptr);
	InstaVec3F *const WedgeNormals = InstaMesh->GetWedgeNormals(nullptr);
	InstaVec2F *const WedgeTexCoords = InstaMesh->GetWedgeTexCoords(0, nullptr);
	uint32 *const WedgeIndices = InstaMesh->GetWedgeIndices(nullptr);
	uint32 *const FaceSmoothingGroups = InstaMesh->GetFaceSmoothingGroups(nullptr);
	uint32 *const FaceSubmeshIndices = InstaMesh->GetFaceSubMeshIndices(nullptr);
	InstaMaterialID *const FaceMaterialIndices = InstaMesh->GetFaceMaterialIndices(nullptr);
	
	VertexPositions[0] = InstaVec3F(-Extent, Extent, 0);
	VertexPositions[1] = InstaVec3F(Extent, Extent, 0);
	VertexPositions[2] = InstaVec3F(-Extent, -Extent, 0);
	VertexPositions[3] = InstaVec3F(Extent, -Extent, 0);
	
	const InstaVec3F UpVector = InstaVec3F(0, 0, 1.0f);
	WedgeNormals[0] = UpVector;
	WedgeNormals[1] = UpVector;
	WedgeNormals[2] = UpVector;
	WedgeNormals[3] = UpVector;
	WedgeNormals[4] = UpVector;
	WedgeNormals[5] = UpVector;
	
	WedgeTexCoords[0] = InstaVec2F(0, 1.0f);
	WedgeTexCoords[1] = InstaVec2F(1.0f, 1.0f);
	WedgeTexCoords[2] = InstaVec2F(0, 0);
	WedgeTexCoords[3] = InstaVec2F(0, 0);
	WedgeTexCoords[4] = InstaVec2F(1.0f, 1.0f);
	WedgeTexCoords[5] = InstaVec2F(1.0f, 0);
	
	WedgeIndices[0] = 0u;
	WedgeIndices[1] = 1u;
	WedgeIndices[2] = 2u;
	WedgeIndices[3] = 2u;
	WedgeIndices[4] = 1u;
	WedgeIndices[5] = 3u;
	
	FaceSubmeshIndices[0] = 0u;
	FaceSubmeshIndices[1] = 0u;
	
	FaceSmoothingGroups[0] = 0u;
	FaceSmoothingGroups[1] = 0u;

	FaceMaterialIndices[0] = 0;
	FaceMaterialIndices[1] = 0;

	InstaLOD->GetInstaLOD()->CastToInstaLODMeshExtended(InstaMesh)->CalculateTangentsWithMikkTSpace(0);
	
	return InstaMesh;
}

UObject* UInstaLODUtilities::SaveInstaLODMeshToStaticMeshAsset(class IInstaLOD* InstaLOD, class InstaLOD::IInstaLODMesh* InstaLODMesh, const FString& SaveObjectPath)
{
	const FString AssetBaseName = FPackageName::GetShortName(SaveObjectPath);
	const FString AssetBasePath = FPackageName::GetLongPackagePath(SaveObjectPath) + TEXT("/");
	
	const FString PackageName = AssetBasePath + AssetBaseName;
	UPackage* Package = CreatePackage(*PackageName);
	Package->FullyLoad();
	
	if (!UPackage::IsEmptyPackage(Package))
	{
		// NOTE: we have to delete the old object in the package or UE4 will crash if the type is different from the one we're creating
		UObject* ExistingObject = FindObject<UObject>(Package, *AssetBaseName);
		
		if (ExistingObject != nullptr)
		{
			TArray<UObject*> DeleteObjects;
			DeleteObjects.Add(ExistingObject);
			
			// delete previous object
			if (!ObjectTools::ForceDeleteObjects(DeleteObjects, true))
			{
				// FIXME: error message
				return NULL;
			}
			
			// trigger GC to ensure it's fully removed
			CollectGarbage( GARBAGE_COLLECTION_KEEPFLAGS );
			
			// reload the package
			Package = CreatePackage(*PackageName);
			Package->FullyLoad();
		}
	}
	Package->Modify();
	
	UStaticMesh* StaticMesh = NewObject<UStaticMesh>(Package, FName(*AssetBaseName), RF_Public | RF_Standalone);
	StaticMesh->InitResources();
	
	// assign new lighting guid
	StaticMesh->LightingGuid = FGuid::NewGuid();
	StaticMesh->LightMapCoordinateIndex = 1;
	
	FStaticMeshSourceModel* SourceModel = new (StaticMesh->GetSourceModels()) FStaticMeshSourceModel();

	SourceModel->BuildSettings.bRecomputeNormals = false;
	SourceModel->BuildSettings.bRecomputeTangents = false;
	SourceModel->BuildSettings.bRemoveDegenerates = false;
	SourceModel->BuildSettings.bUseHighPrecisionTangentBasis = false;
	SourceModel->BuildSettings.bUseFullPrecisionUVs = false;
	
	// insert the InstaLODMesh to LODIndex 0
	UInstaLODUtilities::InsertLODToStaticMesh(InstaLOD, StaticMesh, InstaLODMesh, 0, nullptr);
	
	StaticMesh->ImportVersion = EImportStaticMeshVersion::LastVersion;
	StaticMesh->Build();
	StaticMesh->PostEditChange();
	
	return StaticMesh;
}

void UInstaLODUtilities::RemoveAllLODsFromStaticMesh(class UStaticMesh* StaticMesh)
{
	if (StaticMesh == nullptr)
		return;

	for (int32 i=StaticMesh->GetNumSourceModels() - 1; i>0; --i)
	{
		StaticMesh->GetSourceModels().RemoveAt(i);
	}
}

void UInstaLODUtilities::RemoveAllLODsFromSkeletalMesh(class USkeletalMesh* SkeletalMesh)
{
	if (SkeletalMesh == nullptr)
		return;
	
	IInstaLOD::UE4_SkeletalMeshResource *const SkeletalMeshResource = SkeletalMesh->GetImportedModel(); 
	check(SkeletalMeshResource);
	
	SkeletalMesh->ReleaseResources();
	SkeletalMesh->ReleaseResourcesFence.Wait();
	
	// block until this is done
	FlushRenderingCommands();
	
	while(SkeletalMeshResource->LODModels.Num() > 1)
	{
		SkeletalMeshResource->LODModels.RemoveAt(1);
	}
	
	while(SkeletalMesh->GetLODInfoArray().Num() > 1)
	{
		SkeletalMesh->GetLODInfoArray().RemoveAt(1);
	}

	SkeletalMesh->PostEditChange();
	SkeletalMesh->InitResources();
}

FString UInstaLODUtilities::OpenSaveDialog(const FText& DialogTitle, const FString& DefaultPackageName, const FString &AssetNamePrefix, bool bMultiSave)
{
	const FString DefaultPath = FPackageName::GetLongPackagePath(DefaultPackageName);
	const FString DefaultName = FPackageName::GetShortName(DefaultPackageName);

	FSaveAssetDialogConfig SaveAssetDialogConfig;
	SaveAssetDialogConfig.DialogTitleOverride = DialogTitle;
	SaveAssetDialogConfig.DefaultPath = DefaultPath;
	SaveAssetDialogConfig.DefaultAssetName = AssetNamePrefix + DefaultName;
	SaveAssetDialogConfig.ExistingAssetPolicy = bMultiSave ? ESaveAssetDialogExistingAssetPolicy::Disallow : ESaveAssetDialogExistingAssetPolicy::AllowButWarn;

	FContentBrowserModule& ContentBrowserModule = FModuleManager::LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
	FString Path = ContentBrowserModule.Get().CreateModalSaveAssetDialog(SaveAssetDialogConfig);

	if (!Path.IsEmpty())
	{
		return FPackageName::ObjectPathToPackageName(Path);
	}

	return Path;
}
