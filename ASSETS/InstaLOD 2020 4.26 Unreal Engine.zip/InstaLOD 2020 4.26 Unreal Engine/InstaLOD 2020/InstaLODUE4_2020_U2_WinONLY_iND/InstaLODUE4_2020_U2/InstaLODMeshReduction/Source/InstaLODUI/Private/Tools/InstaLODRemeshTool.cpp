/**
 * InstaLODRemeshTool.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODRemeshTool.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODRemeshTool.h"
#include "InstaLODUIPCH.h"

#include "RawMesh.h"
#include "IContentBrowserSingleton.h"
#include "Interfaces/IPluginManager.h"
#include "AssetRegistryModule.h"
#include "ContentBrowserModule.h"
#include "RawMesh.h"

#include "Utilities/InstaLODUtilities.h"
#include "Slate/InstaLODWindow.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"

UInstaLODRemeshTool::UInstaLODRemeshTool() : Super(),
Operation(nullptr),
OperationResult()
{
	// initialize state
	SetActiveSettingsIndex(SettingsCheckBoxIndex, false);
}

void UInstaLODRemeshTool::SetActiveSettingsIndex(int32 NewIndex, bool bForceSave)
{
	SettingsCheckBoxIndex = NewIndex;

	// updated the used method based on the index
	switch (SettingsCheckBoxIndex)
	{
	case 0:
		bUseFaceCountTarget = true;
		bUseMaximumTriangles = false;
		bUseScreenSizeInPixels = false;
		break;
	case 1:
		bUseFaceCountTarget = false;
		bUseMaximumTriangles = true;
		bUseScreenSizeInPixels = false;
		break;
	case 2:
		bUseFaceCountTarget = false;
		bUseMaximumTriangles = false;
		bUseScreenSizeInPixels = true;
		break;
	default:
		bUseFaceCountTarget = true;
		bUseMaximumTriangles = false;
		bUseScreenSizeInPixels = false;
		break;
	}

	if (bForceSave)
	{
		SaveConfig();
	}
}

void UInstaLODRemeshTool::OnMeshOperationExecute(bool bIsAsynchronous)
{
	// --------------------------
	// can be run on child thread
	// --------------------------
	check(Operation == nullptr);

	InstaLOD::pfnRemeshProgressCallback ProgressCallback  = [](class InstaLOD::IRemeshingOperation *, InstaLOD::IInstaLODMesh*, const float ProgressInPercent)
	{
		if (!IsInGameThread())
		{
			AsyncTask(ENamedThreads::GameThread, [ProgressInPercent]() { GWarn->UpdateProgress(ProgressInPercent * 100, 100); });
		}
		else
		{
			GWarn->UpdateProgress(ProgressInPercent * 100, 100);
		}
	}; 

	// alloc mesh operation
	Operation = GetInstaLODInterface()->GetInstaLOD()->AllocRemeshingOperation();
	Operation->SetProgressCallback(ProgressCallback);
	Operation->SetMaterialData(MaterialData);
	Operation->AddMesh(InputMesh);

	// update reduction selection
	SetActiveSettingsIndex(GetActiveSettingsIndex(), false);

	// execute
	OperationResult = Operation->Execute(OutputMesh, GetRemeshingSettings());
}

bool UInstaLODRemeshTool::IsMeshOperationSuccessful() const
{
	return Operation != nullptr && OperationResult.Success;
}

void UInstaLODRemeshTool::DeallocMeshOperation()
{
	check(Operation);
	GetInstaLODInterface()->GetInstaLOD()->DeallocRemeshingOperation(Operation);
	Operation = nullptr;
}

InstaLOD::IInstaLODMaterial* UInstaLODRemeshTool::GetBakeMaterial()
{
	if (!IsMeshOperationSuccessful())
		return nullptr;

	return OperationResult.BakeMaterial;
}

FText UInstaLODRemeshTool::GetFriendlyName() const
{
	return NSLOCTEXT("InstaLODUI", "RemeshToolFriendlyName", "RE");
}

int32 UInstaLODRemeshTool::GetOrderId() const
{
	return 2;
}

void UInstaLODRemeshTool::ResetSettings()
{
	RemeshMode = EInstaLODRemeshMode::InstaLOD_Reconstruct;
	FuzzyFaceCountTarget = EInstaLODRemeshFaceCount::InstaLOD_Normal;
	MaximumTriangles = 4;
	ScreenSizeInPixels = 300;
	PixelMergeDistance = 2;
	bAutomaticTextureSize = false;
	
	RemeshResolution = EInstaLODRemeshResolution::InstaLOD_Normal;
	bIgnoreBackfaces = false;
	HardAngleThreshold = 70.0f;
	WeldingDistance = 0.0f;
	GutterSizeInPixels = 2;
	UnwrapStrategy = EInstaLODRemeshUnwrapStrategy::InstaLOD_Auto;
	UnwrapStretchImportance = EInstaLODImportance::InstaLOD_Normal;
	SetActiveSettingsIndex(0, false);

	// Reset Parent which ultimately ends in a SaveConfig() call to reset everything
	Super::ResetSettings();
}

InstaLOD::RemeshingSettings UInstaLODRemeshTool::GetRemeshingSettings()
{
	InstaLOD::RemeshingSettings Settings;

	Settings.SurfaceMode = (InstaLOD::RemeshSurfaceMode::Type)RemeshMode;
	if (bUseFaceCountTarget)
	{
		Settings.FaceCountTarget = (InstaLOD::RemeshFaceCountTarget::Type)FuzzyFaceCountTarget;
	}
	else if (bUseMaximumTriangles)
	{
		Settings.MaximumTriangles = MaximumTriangles;
	}
	else if (bUseScreenSizeInPixels)
	{
		Settings.ScreenSizeInPixels = ScreenSizeInPixels;
		Settings.ScreenSizePixelMergeDistance = PixelMergeDistance;
		Settings.ScreenSizeInPixelsAutomaticTextureSize = bAutomaticTextureSize;
	}

	// Surface Construction
	switch (RemeshResolution)
	{
	case EInstaLODRemeshResolution::InstaLOD_Lowest:
		Settings.Resolution = 100;
		break;
	case EInstaLODRemeshResolution::InstaLOD_Low:
		Settings.Resolution = 150;
		break;
	case EInstaLODRemeshResolution::InstaLOD_Normal:
		Settings.Resolution = 256;
		break;
	case EInstaLODRemeshResolution::InstaLOD_High:
		Settings.Resolution = 512;
		break;
	case EInstaLODRemeshResolution::InstaLOD_VeryHigh:
		Settings.Resolution = 1024;
		break;
	case EInstaLODRemeshResolution::InstaLOD_Extreme:
		Settings.Resolution = 2048;
	}
	Settings.SurfaceConstructionIgnoreBackface = bIgnoreBackfaces;
	Settings.HardAngleThreshold = HardAngleThreshold;
	Settings.WeldDistance = WeldingDistance;
	Settings.GutterSizeInPixels = GutterSizeInPixels;
	Settings.UnwrapStrategy = (InstaLOD::UnwrapStrategy::Type)UnwrapStrategy;
	Settings.StretchImportance = (InstaLOD::MeshFeatureImportance::Type)UnwrapStretchImportance;
	
	Settings.AlphaMaskThreshold = AlphaMaskThreshold;
	Settings.BakeOutput = GetBakeOutputSettings();


	return Settings;
}

#undef LOCTEXT_NAMESPACE
