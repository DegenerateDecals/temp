/**
 * InstaLODBakeBaseTool.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODBakeBaseTool.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODBakeBaseTool.h"
#include "InstaLODUIPCH.h"

void UInstaLODBakeBaseTool::ResetSettings()
{
#if 0
	SourceMeshUVSetIndex = 0;
#endif
	SuperSampling = EInstaLODSuperSampling::InstaLOD_X2;
	bSolidifyTexturePages = true;
	AlphaMaskThreshold = 0.5f;
	MaterialSettings = FInstaLODMaterialSettings();
	
	bBakeTexturePageNormalObjectSpace = false;
	bBakeTexturePageMeshID = false;
	bBakeTexturePageVertexColor = false;
	bBakeTexturePageAmbientOcclusion = false;
	bBakeTexturePageBentNormals = false;
	bBakeTexturePageThickness = false;
	bBakeTexturePageDisplacement = false;
	bBakeTexturePagePosition = false;
	bBakeTexturePageCurvature = false;
	bBakeTexturePageOpacity = false;
	
	// Reset Parent which ultimately ends in a SaveConfig() call to reset everything
	Super::ResetSettings();
}


InstaLOD::BakeOutputSettings UInstaLODBakeBaseTool::GetBakeOutputSettings() const
{
	InstaLOD::BakeOutputSettings BakeOutput;
	
	// UE4 specific settings
	BakeOutput.TangentSpaceFormat = InstaLOD::MeshFormat::DirectX;
	BakeOutput.ComputeBinormalPerFragment = true;
	BakeOutput.NormalizeTangentSpacePerFragment = false;
	
	// convert our settings to InstaLOD
	BakeOutput.SuperSampling = (InstaLOD::SuperSampling::Type)SuperSampling;
	BakeOutput.SolidifyTexturePages = bSolidifyTexturePages;
#if 0
	BakeOutput.SourceMeshUVChannelIndex = SourceMeshUVSetIndex;
#else
	BakeOutput.SourceMeshUVChannelIndex = 0;
#endif
	BakeOutput.TextureFilter = (InstaLOD::TextureFilter::Type)MaterialSettings.TextureFilter;
	
    BakeOutput.TexturePageNormalTangentSpace = true;
	BakeOutput.TexturePageNormalObjectSpace = bBakeTexturePageNormalObjectSpace;
	BakeOutput.TexturePageMeshID = bBakeTexturePageMeshID;
	BakeOutput.TexturePageVertexColor = bBakeTexturePageVertexColor;
	BakeOutput.TexturePageAmbientOcclusion = bBakeTexturePageAmbientOcclusion;
	BakeOutput.TexturePageBentNormals = bBakeTexturePageBentNormals;
	BakeOutput.TexturePageThickness = bBakeTexturePageThickness;
	BakeOutput.TexturePageDisplacement = bBakeTexturePageDisplacement;
	BakeOutput.TexturePagePosition = bBakeTexturePagePosition;
	BakeOutput.TexturePageCurvature = bBakeTexturePageCurvature;
	BakeOutput.TexturePageTransfer = false;
	BakeOutput.TexturePageOpacity = bBakeTexturePageOpacity;
	
	return BakeOutput;
}

FMaterialProxySettings UInstaLODBakeBaseTool::GetMaterialProxySettings() const
{
	FMaterialProxySettings MaterialProxySettings;

	MaterialProxySettings.TextureSize = MaterialSettings.TextureSize;
	MaterialProxySettings.TextureSizingType = (ETextureSizingType)MaterialSettings.TextureSizingType;
	MaterialProxySettings.BlendMode = MaterialSettings.BlendMode;
	
	MaterialProxySettings.bNormalMap = MaterialSettings.bNormalMap;
	MaterialProxySettings.MetallicConstant = MaterialSettings.MetallicConstant;
	MaterialProxySettings.bMetallicMap = MaterialSettings.bMetallicMap;
	MaterialProxySettings.RoughnessConstant = MaterialSettings.RoughnessConstant;
	MaterialProxySettings.bRoughnessMap = MaterialSettings.bRoughnessMap;
	MaterialProxySettings.SpecularConstant = MaterialSettings.SpecularConstant;
	MaterialProxySettings.bSpecularMap = MaterialSettings.bSpecularMap;
	MaterialProxySettings.bEmissiveMap = MaterialSettings.bEmissiveMap;
	MaterialProxySettings.bOpacityMap = MaterialSettings.bOpacityMap;
	MaterialProxySettings.bOpacityMaskMap = MaterialSettings.bOpacityMaskMap;
	MaterialProxySettings.bAmbientOcclusionMap = MaterialSettings.bAmbientOcclusionMap;
	MaterialProxySettings.AmbientOcclusionConstant = MaterialSettings.AmbientOcclusionConstant;
	
	MaterialProxySettings.DiffuseTextureSize = MaterialSettings.DiffuseTextureSize;
	MaterialProxySettings.NormalTextureSize = MaterialSettings.NormalTextureSize;
	MaterialProxySettings.MetallicTextureSize = MaterialSettings.MetallicTextureSize;
	MaterialProxySettings.RoughnessTextureSize = MaterialSettings.RoughnessTextureSize;
	MaterialProxySettings.EmissiveTextureSize = MaterialSettings.EmissiveTextureSize;
	MaterialProxySettings.OpacityTextureSize = MaterialSettings.OpacityTextureSize;
	MaterialProxySettings.OpacityMaskTextureSize = MaterialSettings.OpacityMaskTextureSize;
	MaterialProxySettings.AmbientOcclusionTextureSize = MaterialSettings.AmbientOcclusionTextureSize;
	
	return MaterialProxySettings;
}
