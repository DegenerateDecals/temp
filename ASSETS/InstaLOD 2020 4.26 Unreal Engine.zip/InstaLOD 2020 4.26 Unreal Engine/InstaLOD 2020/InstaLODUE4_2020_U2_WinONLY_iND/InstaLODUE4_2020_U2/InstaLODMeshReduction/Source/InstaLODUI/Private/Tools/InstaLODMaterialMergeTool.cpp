/**
 * InstaLODMaterialMergeTool.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODMaterialMergeTool.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODMaterialMergeTool.h"
#include "InstaLODUIPCH.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"

UInstaLODMaterialMergeTool::UInstaLODMaterialMergeTool() :
Operation(nullptr),
OperationResult()
{
}

FText UInstaLODMaterialMergeTool::GetFriendlyName() const
{
	return NSLOCTEXT("InstaLODUI", "MaterialMergeToolFriendlyName", "MM");
}

int32 UInstaLODMaterialMergeTool::GetOrderId() const
{
	return 4;
}


void UInstaLODMaterialMergeTool::OnMeshOperationExecute(bool bIsAsynchronous)
{
	// --------------------------
	// can be run on child thread
	// --------------------------
	check(Operation == nullptr);
	
	InstaLOD::pfnMeshMergeProgressCallback ProgressCallback = [](InstaLOD::IMeshMergeOperation2 *, InstaLOD::IInstaLODMesh* , const float ProgressInPercent)
	{
		if (!IsInGameThread())
		{
			AsyncTask(ENamedThreads::GameThread, [ProgressInPercent]()  { GWarn->UpdateProgress(ProgressInPercent * 100, 100);  });
		}
		else
		{
			GWarn->UpdateProgress(ProgressInPercent * 100, 100);
		}
	};
	
	// alloc mesh operation
	Operation = GetInstaLODInterface()->GetInstaLOD()->AllocMeshMergeOperation();
	Operation->SetProgressCallback(ProgressCallback);
	
	Operation->SetMaterialData(MaterialData);
	Operation->AddMesh(InputMesh);
	
	// execute
	OperationResult = Operation->Execute(OutputMesh, GetMaterialMergeSettings());
}

InstaLOD::IInstaLODMaterial* UInstaLODMaterialMergeTool::GetBakeMaterial()
{
	if (!IsMeshOperationSuccessful())
		return nullptr;
	
	return OperationResult.MergeMaterial;
}

bool UInstaLODMaterialMergeTool::IsMeshOperationSuccessful() const
{
	return Operation != nullptr && OperationResult.Success;
}

void UInstaLODMaterialMergeTool::DeallocMeshOperation()
{
	check(Operation);
	GetInstaLODInterface()->GetInstaLOD()->DeallocMeshMergeOperation(Operation);
	Operation = nullptr;
}

void UInstaLODMaterialMergeTool::ResetSettings()
{
#if 0
	MaterialMergeMode = EInstaLODMaterialMergeMode::InstaLOD_AutoRepack;
#endif
	GutterSizeInPixels = 2;
	SuperSampling = EInstaLODSuperSampling::InstaLOD_X2;
	ShellRotation = EInstaLODShellRotation::InstaLOD_Arbitrary;
	UVImportance = EInstaLODImportance::InstaLOD_Normal;
	GeometricImportance = EInstaLODImportance::InstaLOD_Normal;
	TextureImportance = EInstaLODImportance::InstaLOD_Normal;
	VisualImportance = EInstaLODImportance::InstaLOD_Normal;
		
	MaterialSettings = FInstaLODMaterialSettings();
	
	// Reset Parent which ultimately ends in a SaveConfig() call to reset everything
	Super::ResetSettings();
}

InstaLOD::MeshMergeSettings UInstaLODMaterialMergeTool::GetMaterialMergeSettings()
{
	InstaLOD::MeshMergeSettings Settings;
	
#if 0
	Settings.Mode = (InstaLOD::MeshMergeMode::Type)MaterialMergeMode;
#else
	Settings.Mode = InstaLOD::MeshMergeMode::AutoRepack;
#endif
	
	Settings.TextureFilter = (InstaLOD::TextureFilter::Type)MaterialSettings.TextureFilter; 
	Settings.SolidifyTexturePages = true;
	Settings.StackDuplicateShells = true;
	Settings.InsertNormalSplits = true;
	Settings.ComputeBinormalPerFragment = true;
	Settings.NormalizeTangentSpacePerFragment = false;
	Settings.GutterSizeInPixels = GutterSizeInPixels;
	Settings.ShellRotation = (InstaLOD::UVPackShellRotation::Type)ShellRotation;
	Settings.UVImportance = (InstaLOD::MeshFeatureImportance::Type)UVImportance;
	Settings.GeometricImportance = (InstaLOD::MeshFeatureImportance::Type)GeometricImportance;
	Settings.TextureImportance = (InstaLOD::MeshFeatureImportance::Type)TextureImportance;
	Settings.VisualImportance = (InstaLOD::MeshFeatureImportance::Type)VisualImportance;
	
	return Settings;
}

FMaterialProxySettings UInstaLODMaterialMergeTool::GetMaterialProxySettings() const
{
	FMaterialProxySettings MaterialProxySettings;
	
	MaterialProxySettings.TextureSize = MaterialSettings.TextureSize;
	MaterialProxySettings.TextureSizingType = (ETextureSizingType)(int)MaterialSettings.TextureSizingType;
	MaterialProxySettings.BlendMode = MaterialSettings.BlendMode;
	
	MaterialProxySettings.bNormalMap = MaterialSettings.bNormalMap;
	MaterialProxySettings.MetallicConstant = MaterialSettings.MetallicConstant;
	MaterialProxySettings.bMetallicMap = MaterialSettings.bMetallicMap;
	MaterialProxySettings.RoughnessConstant = MaterialSettings.RoughnessConstant;
	MaterialProxySettings.bRoughnessMap = MaterialSettings.bRoughnessMap;
	MaterialProxySettings.SpecularConstant = MaterialSettings.SpecularConstant;
	MaterialProxySettings.bSpecularMap = MaterialSettings.bSpecularMap;
	MaterialProxySettings.bEmissiveMap = MaterialSettings.bEmissiveMap;
	MaterialProxySettings.bOpacityMap = MaterialSettings.bOpacityMap;
	MaterialProxySettings.bOpacityMaskMap = MaterialSettings.bOpacityMaskMap;
	MaterialProxySettings.bAmbientOcclusionMap = MaterialSettings.bAmbientOcclusionMap;
	MaterialProxySettings.AmbientOcclusionConstant = MaterialSettings.AmbientOcclusionConstant;
	
	MaterialProxySettings.DiffuseTextureSize = MaterialSettings.DiffuseTextureSize;
	MaterialProxySettings.NormalTextureSize = MaterialSettings.NormalTextureSize;
	MaterialProxySettings.MetallicTextureSize = MaterialSettings.MetallicTextureSize;
	MaterialProxySettings.RoughnessTextureSize = MaterialSettings.RoughnessTextureSize;
	MaterialProxySettings.EmissiveTextureSize = MaterialSettings.EmissiveTextureSize;
	MaterialProxySettings.OpacityTextureSize = MaterialSettings.OpacityTextureSize;
	MaterialProxySettings.OpacityMaskTextureSize = MaterialSettings.OpacityMaskTextureSize;
	MaterialProxySettings.AmbientOcclusionTextureSize = MaterialSettings.AmbientOcclusionTextureSize;
	
	return MaterialProxySettings;
}

#undef LOCTEXT_NAMESPACE
