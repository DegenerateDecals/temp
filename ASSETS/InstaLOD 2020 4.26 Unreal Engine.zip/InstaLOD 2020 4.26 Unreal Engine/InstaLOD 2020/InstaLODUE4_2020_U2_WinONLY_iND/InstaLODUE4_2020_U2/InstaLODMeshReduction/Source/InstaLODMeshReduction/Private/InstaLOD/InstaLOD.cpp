/**
 * InstaLOD.cpp (InstaLOD)
 *
 * Copyright 2016-2020 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLOD.cpp
 * @copyright 2016-2020 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODMeshReductionPCH.h"
#include "InstaLOD/InstaLOD.h"

#include "Editor/AnimationModifiers/Public/AnimationBlueprintLibrary.h"

#include "ComponentReregisterContext.h"

#include "InstaLOD/InstaLODAPI.h"

#include "Slate/InstaLODPluginStyle.h"
#include "InstaLODPluginCommands.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "Framework/Notifications/NotificationManager.h"
#include "MaterialUtilities.h"

#include "ClothingAsset.h"
#include "MeshBoneReduction.h"

#include "StaticMeshOperations.h"
#include "StaticMeshAttributes.h"
#include "MeshAttributes.h"
#include "MeshDescription.h"
#include "MeshDescriptionOperations.h"

#include "RawMesh.h"
 
#include "MeshMergeData.h" 

#include "StaticMeshEditorModule.h"

#include "Rendering/SkeletalMeshModel.h"
#include "Rendering/SkeletalMeshLODModel.h"
#include "InstaLOD/InstaLODMeshExtended.h"


#define LOCTEXT_NAMESPACE "InstaLOD"

static TAutoConsoleVariable<int32> CVarOverrideSmoothingGroups(TEXT("InstaLOD.OverrideSmoothingGroups"), 1, TEXT("Overrides the smoothing groups of the source mesh. Use 0 to use smoothing groups of input mesh."));
static TAutoConsoleVariable<int32> CVarAlgorithmStrategy(TEXT("InstaLOD.AlgorithmStrategy"), InstaLOD::AlgorithmStrategy::Smart_v2, TEXT("The currently used algorithm strategy."));
static TAutoConsoleVariable<float> CVarDefaultMaximumError(TEXT("InstaLOD.DefaultMaximumError"), 0.0f, TEXT("Default maximum error. Active when per LOD 'Max Deviation' is set to 0."));
static TAutoConsoleVariable<float> CVarDecimatedErrorFactor(TEXT("InstaLOD.DecimatedErrorFactor"), 8.0f, TEXT("Deviation factor used for screen size calculation."));
static TAutoConsoleVariable<int32> CVarLockBoundaries(TEXT("InstaLOD.LockBoundaries"), 0, TEXT("Locks mesh boundary vertices in place."));
static TAutoConsoleVariable<int32> CVarLockSplits(TEXT("InstaLOD.LockSplits"), 0, TEXT("Locks split vertices in place."));
static TAutoConsoleVariable<int32> CVarOptimalPlacement(TEXT("InstaLOD.OptimalPlacement"), 1, TEXT("Enables optimal placement of vertices."));
static TAutoConsoleVariable<int32> CVarWeldingProtectDistinctUVShells(TEXT("InstaLOD.WeldingProtectDistinctUVShells"), 1, TEXT("Enables protection of distinct UV shells during weld operations."));
static TAutoConsoleVariable<int32> CVarWeightedNormals(TEXT("InstaLOD.WeightedNormals"), 1, TEXT("Enables weighted normals when recalculating normals."));
static TAutoConsoleVariable<int32> CVarForceOptimizerWeights(TEXT("InstaLOD.ForceOptimizerWeights"), 0, TEXT("Force enables optimizer vertex weights via vertex colors."));
static TAutoConsoleVariable<int32> CVarDeviationBasedScreenSize(TEXT("InstaLOD.DeviationBasedScreenSize"), 1, TEXT("Base the auto LOD screen size calculation on the mesh deviation."));

static TAutoConsoleVariable<float> CVarHLODScreenSizeFactor(TEXT("InstaLOD.HLODScreenSizeFactor"), 1.0f, TEXT("Controls the screen size based maximum deviation calculation."));
static TAutoConsoleVariable<int32> CVarHLODRemesh(TEXT("InstaLOD.HLODRemesh"), 1, TEXT("Determines whether HLOD proxies use remeshing or mesh merging and optimize."));

static TAutoConsoleVariable<int32> CVarInstaDebug(TEXT("InstaLOD.Debug"), 0, TEXT("Internal debugging cvar."));
static TAutoConsoleVariable<FString> CVarWriteOBJ(TEXT("InstaLOD.WriteOBJ"), TEXT(""), TEXT("Write a OBJ file containing a representation of the optimized mesh to the path specified in the cvar."));

namespace UE4InstaLODMeshHelper
{
	static inline InstaLOD::InstaVec2F FVectorToInstaVec(const FVector2D& Vector)
	{
		InstaLOD::InstaVec2F OutVector;
		OutVector.X = Vector.X;
		OutVector.Y = Vector.Y;
		return OutVector;
	}
	
	static inline InstaLOD::InstaVec3F FVectorToInstaVec(const FVector& Vector)
	{
		InstaLOD::InstaVec3F OutVector;
		OutVector.X = Vector.X;
		OutVector.Y = Vector.Y;
		OutVector.Z = Vector.Z;
		return OutVector;
	}

	static inline InstaLOD::InstaQuaternionF FQuatToInstaQuaternion(const FQuat& Quaternion)
	{
		InstaLOD::InstaQuaternionF OutQuaternion;
		OutQuaternion.W = Quaternion.W;
		OutQuaternion.X = Quaternion.X;
		OutQuaternion.Y = Quaternion.Y;
		OutQuaternion.Z = Quaternion.Z;
		return OutQuaternion;
	}
	
	static inline InstaLOD::InstaColorRGBAF32 FColorToInstaColorRGBAF32(const FColor& Color)
	{
		const FLinearColor LinearColor = Color.ReinterpretAsLinear();
		InstaLOD::InstaColorRGBAF32 OutColor;
		OutColor.R = LinearColor.R;
		OutColor.G = LinearColor.G;
		OutColor.B = LinearColor.B;
		OutColor.A = LinearColor.A;
		return OutColor;
	}
	
	static inline FVector2D InstaVecToFVector(const InstaLOD::InstaVec2F& Vector)
	{
		return FVector2D(Vector.X, Vector.Y);
	}
	
	static inline FVector InstaVecToFVector(const InstaLOD::InstaVec3F& Vector)
	{
		return FVector(Vector.X, Vector.Y, Vector.Z);
	}
	
	static inline FColor InstaColorRGBAF32ToFColor(const InstaLOD::InstaColorRGBAF32& Color)
	{
		return FLinearColor(Color.R, Color.G, Color.B, Color.A).ToFColor(false);
	}
	
	static inline void FillArray(InstaLOD::InstaVec3F *const OutData, const FVector *const InData, const size_t NumElements)
	{
		for(size_t i=0; i<NumElements; i++)
		{
			OutData[i].X = InData[i].X;
			OutData[i].Y = InData[i].Y;
			OutData[i].Z = InData[i].Z;
		}
	}
	
	static inline void FillArray(InstaLOD::InstaVec2F *const OutData, const FVector2D *const InData, const size_t NumElements)
	{
		for(size_t i=0; i<NumElements; i++)
		{
			OutData[i].X = InData[i].X;
			OutData[i].Y = InData[i].Y;
		}
	}
	
	static inline void FillArray(InstaLOD::InstaColorRGBAF32 *const OutData, const FColor *const InData, const size_t NumElements)
	{
		for(size_t i=0; i<NumElements; i++)
		{
			FLinearColor color = InData[i].ReinterpretAsLinear();
			
			OutData[i].R = color.R;
			OutData[i].G = color.G;
			OutData[i].B = color.B;
			OutData[i].A = color.A;
		}
	}
	
	template<typename T>
	static inline void FillArray(T *const OutData, const T *const InData, const size_t NumElements)
	{
		for(size_t i=0; i<NumElements; i++)
		{
			OutData[i] = InData[i];
		}
	}
	
	static inline void SanitizeFloatArray(float *const OutData, const size_t NumElements, const float InDefaultValue)
	{
		// NOTE: it is possible that UE4 sends invalid data to InstaLOD that contains NaNs or infinite numbers
		// in order to avoid invalid meshes we sanitze all float arrays by default
		for(size_t i=0; i<NumElements; i++)
		{
			if (FMath::IsNaN(OutData[i]) || !FMath::IsFinite(OutData[i]))
			{
				UE_LOG(LogInstaLOD, Warning, TEXT("Sanitzing NaN/infinite value in data received from Unreal Engine."));
				OutData[i] = InDefaultValue;
			}
		}
	}
	
	template<typename T>
	static inline void FillTArray(TArray<T>& OutArray, const T *const InData, const size_t NumElements)
	{
		OutArray.Reset();
		OutArray.AddUninitialized(NumElements);
		for(size_t i=0; i<NumElements; i++)
		{
			OutArray[i] = InData[i];
		}
	}
	
	template<typename T, typename O, O CONVERTER(const T&) >
	static inline void FillTArrayWithConverter(TArray<O>& OutArray, const T *const InData, const size_t NumElements)
	{
		OutArray.Reset();
		OutArray.AddUninitialized(NumElements);
		
		for(size_t i=0; i<NumElements; i++)
		{
			OutArray[i] = CONVERTER(InData[i]);
		}
	}

	static void RawMeshToInstaLODMesh(const FRawMesh& SourceRawMesh, InstaLOD::IInstaLODMesh *const InstaMesh)
	{
		InstaMesh->Clear();
		InstaMesh->SetFrontFaceWindingOrder(InstaLOD::IInstaLODMesh::WindingOrderClockwise);
		InstaMesh->SetMeshFormatType(InstaLOD::MeshFormat::DirectX);
		
		// per-vertex data
		InstaMesh->ResizeVertexPositions(SourceRawMesh.VertexPositions.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetVertexPositions(NULL), SourceRawMesh.VertexPositions.GetData(), SourceRawMesh.VertexPositions.Num());
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetVertexPositions(NULL), SourceRawMesh.VertexPositions.Num() * 3, 0.0f);
		
		// per-wedge data
		InstaMesh->ResizeWedgeIndices(SourceRawMesh.WedgeIndices.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeIndices(NULL), SourceRawMesh.WedgeIndices.GetData(), SourceRawMesh.WedgeIndices.Num());
		
		InstaMesh->ResizeWedgeTangents(SourceRawMesh.WedgeTangentX.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeTangents(NULL), SourceRawMesh.WedgeTangentX.GetData(), SourceRawMesh.WedgeTangentX.Num());
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetWedgeTangents(NULL), SourceRawMesh.WedgeTangentX.Num() * 3, 0.0f);
		
		InstaMesh->ResizeWedgeBinormals(SourceRawMesh.WedgeTangentY.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeBinormals(NULL), SourceRawMesh.WedgeTangentY.GetData(), SourceRawMesh.WedgeTangentY.Num());
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetWedgeBinormals(NULL), SourceRawMesh.WedgeTangentY.Num() * 3, 0.0f);
		
		InstaMesh->ResizeWedgeNormals(SourceRawMesh.WedgeTangentZ.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeNormals(NULL), SourceRawMesh.WedgeTangentZ.GetData(), SourceRawMesh.WedgeTangentZ.Num());
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetWedgeNormals(NULL), SourceRawMesh.WedgeTangentZ.Num() * 3, 0.0f);
		
		InstaMesh->ResizeWedgeColors(0, SourceRawMesh.WedgeColors.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeColors(0, NULL), SourceRawMesh.WedgeColors.GetData(), SourceRawMesh.WedgeColors.Num());
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetWedgeColors(0, NULL), SourceRawMesh.WedgeColors.Num() * 4, 0.0f);
		
		const uint32 TexcoordCount = FMath::Min<uint32>(InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS, MAX_MESH_TEXTURE_COORDS);
		for (uint32 i=0; i<TexcoordCount; i++)
		{
			InstaMesh->ResizeWedgeTexCoords(i, SourceRawMesh.WedgeTexCoords[i].Num());
			
			if (SourceRawMesh.WedgeTexCoords[i].Num() == 0)
				continue;
			
			UE4InstaLODMeshHelper::FillArray(InstaMesh->GetWedgeTexCoords(i, NULL), SourceRawMesh.WedgeTexCoords[i].GetData(), SourceRawMesh.WedgeTexCoords[i].Num());
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)InstaMesh->GetWedgeTexCoords(i, NULL), SourceRawMesh.WedgeTexCoords[i].Num() * 2, 0.0f);
		}
		
		// per-face data
		InstaMesh->ResizeFaceMaterialIndices(SourceRawMesh.FaceMaterialIndices.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetFaceMaterialIndices(NULL), SourceRawMesh.FaceMaterialIndices.GetData(), SourceRawMesh.FaceMaterialIndices.Num());
		
		// NOTE: set smoothing group to 0 for all faces
		TArray<uint32> smoothingGroup;
		smoothingGroup.AddZeroed(SourceRawMesh.FaceSmoothingMasks.Num());

		InstaMesh->ResizeFaceSmoothingGroups(SourceRawMesh.FaceSmoothingMasks.Num());
		UE4InstaLODMeshHelper::FillArray(InstaMesh->GetFaceSmoothingGroups(NULL), smoothingGroup.GetData(), smoothingGroup.Num());
	}
	
	static void InstaLODMeshToRawMesh(InstaLOD::IInstaLODMesh *const InstaMesh, FRawMesh& OutputMesh)
	{
		OutputMesh.Empty();
		
		InstaLOD::uint64 ElementCount;
		
		// per-vertex data
		InstaLOD::InstaVec3F *const Vertices = InstaMesh->GetVertexPositions(&ElementCount);
		UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaVec3F, FVector, InstaVecToFVector>(OutputMesh.VertexPositions, Vertices, ElementCount);
		
		// per-wedge data
		InstaLOD::uint32 *const WedgeIndices = InstaMesh->GetWedgeIndices(&ElementCount);
		UE4InstaLODMeshHelper::FillTArray<InstaLOD::uint32>(OutputMesh.WedgeIndices, WedgeIndices, ElementCount);
		
		InstaLOD::InstaVec3F *const WedgeTangents = InstaMesh->GetWedgeTangents(&ElementCount);
		UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaVec3F, FVector, InstaVecToFVector>(OutputMesh.WedgeTangentX, WedgeTangents, ElementCount);
		InstaLOD::InstaVec3F *const WedgeBinormals = InstaMesh->GetWedgeBinormals(&ElementCount);
		UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaVec3F, FVector, InstaVecToFVector>(OutputMesh.WedgeTangentY, WedgeBinormals, ElementCount);
		InstaLOD::InstaVec3F *const WedgeNormals = InstaMesh->GetWedgeNormals(&ElementCount);
		UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaVec3F, FVector, InstaVecToFVector>(OutputMesh.WedgeTangentZ, WedgeNormals, ElementCount);
		
		InstaLOD::InstaColorRGBAF32 *const WedgeColors = InstaMesh->GetWedgeColors(0, &ElementCount);
		UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaColorRGBAF32, FColor, InstaColorRGBAF32ToFColor>(OutputMesh.WedgeColors, WedgeColors, ElementCount);
		
		// texture coordinate sets
		const int TexCoordCount = FMath::Min<int>(InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS, MAX_MESH_TEXTURE_COORDS);
		for (size_t TexCoordSetIndex=0; TexCoordSetIndex<TexCoordCount; TexCoordSetIndex++)
		{
			InstaLOD::InstaVec2F *const TexCoords = InstaMesh->GetWedgeTexCoords(TexCoordSetIndex, &ElementCount);
			UE4InstaLODMeshHelper::FillTArrayWithConverter<InstaLOD::InstaVec2F, FVector2D, InstaVecToFVector>(OutputMesh.WedgeTexCoords[TexCoordSetIndex], TexCoords, ElementCount);
		}
		
		// per-face data
		InstaLOD::InstaMaterialID *const FaceMaterialIndices = InstaMesh->GetFaceMaterialIndices(&ElementCount);
		UE4InstaLODMeshHelper::FillTArray<InstaLOD::InstaMaterialID>(OutputMesh.FaceMaterialIndices, FaceMaterialIndices, ElementCount);
		
		InstaLOD::uint32 *const FaceSmoothingGroups = InstaMesh->GetFaceSmoothingGroups(&ElementCount);
		UE4InstaLODMeshHelper::FillTArray<InstaLOD::uint32>(OutputMesh.FaceSmoothingMasks, FaceSmoothingGroups, ElementCount);
	}
	
	static void MeshDescriptionToInstaLODMesh(const FMeshDescription& SourceMeshDescription, const TMap<FName, int32>& MaterialMapIn, InstaLOD::IInstaLODMesh *const InstaMesh)
	{
		InstaMesh->Clear();
		InstaMesh->SetFrontFaceWindingOrder(InstaLOD::IInstaLODMesh::WindingOrderClockwise);
		InstaMesh->SetMeshFormatType(InstaLOD::MeshFormat::DirectX);
		
		const FStaticMeshConstAttributes SourceMeshAttributes(SourceMeshDescription);
		TVertexAttributesConstRef<FVector> VertexPositions = SourceMeshAttributes.GetVertexPositions();
		TVertexInstanceAttributesConstRef<FVector> VertexInstanceNormals = SourceMeshAttributes.GetVertexInstanceNormals();
		TVertexInstanceAttributesConstRef<FVector> VertexInstanceTangents = SourceMeshAttributes.GetVertexInstanceTangents();
		TVertexInstanceAttributesConstRef<float> VertexInstanceBinormalSigns = SourceMeshAttributes.GetVertexInstanceBinormalSigns();
		TVertexInstanceAttributesConstRef<FVector4> VertexInstanceColors = SourceMeshAttributes.GetVertexInstanceColors();
		TVertexInstanceAttributesConstRef<FVector2D> VertexInstanceUVs = SourceMeshAttributes.GetVertexInstanceUVs();
		TPolygonGroupAttributesConstRef<FName> PolygonGroupMaterialSlotName = SourceMeshAttributes.GetPolygonGroupMaterialSlotNames();
		
		// set vertex positions 
		InstaMesh->ResizeVertexPositions(SourceMeshDescription.Vertices().GetArraySize());
		InstaLOD::InstaVec3F *OutVertexPositions = InstaMesh->GetVertexPositions(NULL);

		// lookup table to get from UE VertexId to VertexIndex
		TMap<FVertexID, uint32> VertexIDToVertexIndex;
		VertexIDToVertexIndex.Reserve(SourceMeshDescription.Vertices().GetArraySize());

		uint32 VertexIndex = 0u;
		for (const FVertexID& VertexID : SourceMeshDescription.Vertices().GetElementIDs())
		{
			InstaLOD::InstaVec3F position = UE4InstaLODMeshHelper::FVectorToInstaVec(VertexPositions[VertexID]);
			OutVertexPositions[VertexIndex] = position;
			VertexIDToVertexIndex.Add(VertexID, VertexIndex);
			VertexIndex++;
		}
		const uint32 VertexCount = VertexIndex;

		// get triangleface count
		uint32 TriangleCount = 0;
		for (const FPolygonID& PolygonID : SourceMeshDescription.Polygons().GetElementIDs())
		{
			TriangleCount += SourceMeshDescription.GetPolygonTriangleIDs(PolygonID).Num();
		}

		// NOTE: will be changed in next release to
		// SourceMeshDescription.Triangles().Num() * 3
		const uint32 WedgeCount = TriangleCount * 3u;

		// determine whether mesh has vertex colors
		bool bHasVertexColors = false;

		FVector4 White(FLinearColor::White);
		for (const FVertexInstanceID& VertexInstanceID : SourceMeshDescription.VertexInstances().GetElementIDs())
		{
			if (VertexInstanceColors[VertexInstanceID] != White)
			{
				bHasVertexColors = true;
				break;
			}
		}

		if (bHasVertexColors)
		{
			InstaMesh->ResizeWedgeColors(0, WedgeCount);
		}

		// preallocate InstaLODMesh data
		InstaMesh->ResizeFaceMaterialIndices(TriangleCount);
		InstaMesh->ResizeFaceSmoothingGroups(TriangleCount);
		InstaMesh->ResizeWedgeIndices(WedgeCount);
		InstaMesh->ResizeWedgeTangents(WedgeCount);
		InstaMesh->ResizeWedgeBinormals(WedgeCount);
		InstaMesh->ResizeWedgeNormals(WedgeCount);

		uint32 UVChannelCount = VertexInstanceUVs.GetNumIndices();
		UVChannelCount = UVChannelCount > InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS ? InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS : UVChannelCount;

		TArray<InstaLOD::InstaVec2F*> WedgeUVChannels;
		for (uint32 UVChannelIndex=0u; UVChannelIndex<UVChannelCount; UVChannelIndex++)
		{
			InstaMesh->ResizeWedgeTexCoords(UVChannelIndex, WedgeCount);
			WedgeUVChannels.Add(InstaMesh->GetWedgeTexCoords(UVChannelIndex, NULL));
		}

		// get handles to InstaLODMesh attributes
		InstaLOD::InstaMaterialID *const OutMaterialIndices = InstaMesh->GetFaceMaterialIndices(NULL);
		InstaLOD::InstaColorRGBAF32 *const OutWedgeColors = InstaMesh->GetWedgeColors(0, NULL);
		InstaLOD::InstaVec3F *const OutWedgeTangents = InstaMesh->GetWedgeTangents(NULL);
		InstaLOD::InstaVec3F *const OutWedgeBinormals = InstaMesh->GetWedgeBinormals(NULL);
		InstaLOD::InstaVec3F *const OutWedgeNormals = InstaMesh->GetWedgeNormals(NULL);
		uint32 *const OutSmoothingGroups = InstaMesh->GetFaceSmoothingGroups(NULL);
		uint32 *const OutWedgeIndices = InstaMesh->GetWedgeIndices(NULL);

		// fill InstaLODMesh with data
		uint32 TriangleIndex = 0u;
		uint32 WedgeIndex = 0u;
		for (const FPolygonID PolygonID : SourceMeshDescription.Polygons().GetElementIDs())
		{
			const FPolygonGroupID& PolygonGroupID = SourceMeshDescription.GetPolygonPolygonGroup(PolygonID);
			int32 PolygonIDValue = PolygonID.GetValue();

			const TArray<FTriangleID>& TriangleIDs = SourceMeshDescription.GetPolygonTriangleIDs(PolygonID);

			for (const FTriangleID TriangleID : TriangleIDs)
			{
				for (uint32 TriangleCorner=0u; TriangleCorner<3u; TriangleCorner++)
				{
					const FVertexInstanceID VertexInstanceID = SourceMeshDescription.GetTriangleVertexInstance(TriangleID, TriangleCorner);
					OutWedgeIndices[WedgeIndex] = VertexIDToVertexIndex[SourceMeshDescription.GetVertexInstanceVertex(VertexInstanceID)];
					OutWedgeNormals[WedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(VertexInstanceNormals[VertexInstanceID]);
					OutWedgeTangents[WedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(VertexInstanceTangents[VertexInstanceID]);
					OutWedgeBinormals[WedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(FVector::CrossProduct(VertexInstanceNormals[VertexInstanceID], VertexInstanceTangents[VertexInstanceID]).GetSafeNormal() * VertexInstanceBinormalSigns[VertexInstanceID]);
					
					for (uint32 UVChannelIndex=0; UVChannelIndex<UVChannelCount; UVChannelIndex++)
					{
						WedgeUVChannels[UVChannelIndex][WedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(VertexInstanceUVs.Get(VertexInstanceID, UVChannelIndex));
					}

					if (bHasVertexColors)
					{
						OutWedgeColors[WedgeIndex] = UE4InstaLODMeshHelper::FColorToInstaColorRGBAF32(FLinearColor(VertexInstanceColors[VertexInstanceID]).ToFColor(true));
					}

					WedgeIndex++;
				}

				// set materialindex for triangle
				if (MaterialMapIn.Contains(PolygonGroupMaterialSlotName[PolygonGroupID]))
				{
					OutMaterialIndices[TriangleIndex] = MaterialMapIn[PolygonGroupMaterialSlotName[PolygonGroupID]];
				}
				else
				{
					OutMaterialIndices[TriangleIndex] = PolygonGroupID.GetValue();
				}

				// smoothing groups not supported set default value
				OutSmoothingGroups[TriangleIndex] = 0;
				
				TriangleIndex++;
			}
		}

		// sanitize data
		{
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutVertexPositions, VertexCount * 3, 0.0f);
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeNormals, WedgeCount * 3, 0.0f);
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeBinormals, WedgeCount * 3, 0.0f);
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeTangents, WedgeCount * 3, 0.0f);

			for (uint32 UVChannelIndex=0u; UVChannelIndex<UVChannelCount; UVChannelIndex++)
			{
				UE4InstaLODMeshHelper::SanitizeFloatArray((float*)WedgeUVChannels[UVChannelIndex], WedgeCount * 2, 0.0f);
			}

			if (bHasVertexColors)
			{
				UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeColors, WedgeCount * 4, 0.0f);
			}
		}
	}

	static void InstaLODMeshToMeshDescription(InstaLOD::IInstaLODMesh *const InstaMesh, const TMap<int32, FName>& MaterialMapOut, FMeshDescription& DestinationMeshDescription)
	{
		check(InstaMesh);
		DestinationMeshDescription.Empty();
		
		uint64 WedgeIndexCount = 0;
		uint64 VertexPositionCount = 0;
		const uint32 *const WedgeIndices = InstaMesh->GetWedgeIndices(&WedgeIndexCount);
		const InstaLOD::InstaVec3F *const OutVertexPositions = InstaMesh->GetVertexPositions(&VertexPositionCount);

		const uint64 TriangleCount = WedgeIndexCount / 3;

		// preallocate mesh description data
		DestinationMeshDescription.ReserveNewVertices(VertexPositionCount);
		DestinationMeshDescription.ReserveNewVertexInstances(WedgeIndexCount);
		DestinationMeshDescription.ReserveNewPolygons(TriangleCount);
		DestinationMeshDescription.ReserveNewEdges(TriangleCount*2.5f); // approx.
		TVertexAttributesRef<FVector> VertexPositions = DestinationMeshDescription.VertexAttributes().GetAttributesRef<FVector>(MeshAttribute::Vertex::Position);
		
		// set vertex positions and create map to get from vertex index to vertexID
		TMap<uint32, FVertexID> VertexIndexToVertexID;
		VertexIndexToVertexID.Reserve(VertexPositionCount);

		for (uint32 VertexIndex=0; VertexIndex<VertexPositionCount; VertexIndex++)
		{
			const FVertexID VertexId = DestinationMeshDescription.CreateVertex();
			VertexPositions.Set(VertexId, InstaVecToFVector(OutVertexPositions[VertexIndex]));
			VertexIndexToVertexID.Add(VertexIndex, VertexId);
		}
		
		// Array references for attributes
		TVertexInstanceAttributesRef<FVector> VertexInstanceNormals = DestinationMeshDescription.VertexInstanceAttributes().GetAttributesRef<FVector>(MeshAttribute::VertexInstance::Normal);
		TVertexInstanceAttributesRef<FVector> VertexInstanceTangents = DestinationMeshDescription.VertexInstanceAttributes().GetAttributesRef<FVector>(MeshAttribute::VertexInstance::Tangent);
		TVertexInstanceAttributesRef<float> VertexInstanceBinormalSigns = DestinationMeshDescription.VertexInstanceAttributes().GetAttributesRef<float>(MeshAttribute::VertexInstance::BinormalSign);
		TVertexInstanceAttributesRef<FVector4> VertexInstanceColors = DestinationMeshDescription.VertexInstanceAttributes().GetAttributesRef<FVector4>(MeshAttribute::VertexInstance::Color);
		TVertexInstanceAttributesRef<FVector2D> VertexInstanceUVs = DestinationMeshDescription.VertexInstanceAttributes().GetAttributesRef<FVector2D>(MeshAttribute::VertexInstance::TextureCoordinate);
		TPolygonGroupAttributesRef<FName> PolygonGroupImportedMaterialSlotNames = DestinationMeshDescription.PolygonGroupAttributes().GetAttributesRef<FName>(MeshAttribute::PolygonGroup::ImportedMaterialSlotName);

		// clamp maximum texture coordinate channel to either InstaLOD max or unreal max
		const int32 MaxTexCoordChannels = MAX_MESH_TEXTURE_COORDS > InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS ? InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS : MAX_MESH_TEXTURE_COORDS;
		
		TArray<int32> TextureCoordinateRemapIndex;
		TextureCoordinateRemapIndex.AddZeroed(MaxTexCoordChannels);
		
		TArray<InstaLOD::InstaVec2F*> WedgeTextureCoordinates;
		WedgeTextureCoordinates.Reserve(MaxTexCoordChannels);

		// map texture coordinates
		int32 TexcoordsCount = 0;
		for (int32 TextureCoordinateIndex=0; TextureCoordinateIndex<MaxTexCoordChannels; TextureCoordinateIndex++)
		{
			TextureCoordinateRemapIndex[TextureCoordinateIndex] = INDEX_NONE;
			uint64 TexcoordCountInChannel = 0;
			WedgeTextureCoordinates.Add(InstaMesh->GetWedgeTexCoords((uint64) TextureCoordinateIndex, &TexcoordCountInChannel));
			
			if (TexcoordCountInChannel == WedgeIndexCount)
			{
				TextureCoordinateRemapIndex[TextureCoordinateIndex] = TexcoordsCount;
				TexcoordsCount++;
			}
		}

		VertexInstanceUVs.SetNumIndices(TexcoordsCount);
		
		// get wedge data from InstaLODMesh
		uint64 WedgeColorCount = 0;
		uint64 WedgeTangentCount = 0;
		uint64 WedgeBinormalCount = 0;
		uint64 WedgeNormalCount = 0;
		uint64 FaceMaterialIndexCount = 0;
		uint64 SmoothingGroupCount = 0;
		const InstaLOD::InstaVec3F *const WedgeTangents = InstaMesh->GetWedgeTangents(&WedgeTangentCount);
		const InstaLOD::InstaVec3F *const WedgeBinormals = InstaMesh->GetWedgeBinormals(&WedgeBinormalCount);
		const InstaLOD::InstaVec3F *const WedgeNormals = InstaMesh->GetWedgeNormals(&WedgeNormalCount);
		const InstaLOD::InstaMaterialID *const MaterialIndices = InstaMesh->GetFaceMaterialIndices(&FaceMaterialIndexCount);
		const InstaLOD::InstaColorRGBAF32 *const WedgeColors = InstaMesh->GetWedgeColors(0, &WedgeColorCount);
		const uint32 *const SmoothingGroups = InstaMesh->GetFaceSmoothingGroups(&SmoothingGroupCount);
		
		const bool bHasColors = WedgeColorCount > 0;
		const bool bHasTangents = WedgeTangentCount > 0 && WedgeBinormalCount > 0;
		const bool bHasNormals = WedgeNormalCount > 0;
		
		// Materialindices are separated by polygongroups in Mesh Description
		uint32 PolygonGroupIDSource = 0;
		TMap<int32, FPolygonGroupID> MaterialIndexToPolygonGroup;

		for (uint32 FaceIndex=0; FaceIndex<FaceMaterialIndexCount; FaceIndex++)
		{
			const int32 MaterialIndex = MaterialIndices[FaceIndex];

			if (!MaterialIndexToPolygonGroup.Contains(MaterialIndex))
			{
				const FPolygonGroupID PolygonGroupID(MaterialIndex);
				DestinationMeshDescription.CreatePolygonGroupWithID(PolygonGroupID);

				// use material map if index is set
				if (MaterialMapOut.Contains(MaterialIndex))
				{
					PolygonGroupImportedMaterialSlotNames.Set(PolygonGroupID, MaterialMapOut[MaterialIndex]);
				}
				else
				{
					PolygonGroupImportedMaterialSlotNames.Set(PolygonGroupID, FName(*FString::Printf(TEXT("MaterialSlot_%d"), MaterialIndex)));
				}
				MaterialIndexToPolygonGroup.Add(MaterialIndex, PolygonGroupID);
			}
		}

		// calculate the binormal sign
		auto fnCalculateBinormalSign = [](const FVector& Normal, const FVector& Binormal, const FVector& Tangent) -> float
		{
			const FVector CrossTangent = FVector::CrossProduct(Binormal, Normal);
			return FVector::DotProduct(Tangent, CrossTangent) < 0 ? -1.0f : 1.0f;
		};

		//Triangles 
		for (uint32 TriangleIndex=0; TriangleIndex<TriangleCount; TriangleIndex++)
		{
			const int32 MaterialIndex = MaterialIndices[TriangleIndex];
			const uint32 VertexFaceIndexBasis = TriangleIndex * 3;

			// determine whether degenerates are present
			FVertexID VertexIDs[3];
			for (int32 CornerIndex=0; CornerIndex<3; CornerIndex++)
			{
				int32 VertexIndex = VertexFaceIndexBasis + CornerIndex;

				const FVertexID VertexID = VertexIndexToVertexID[WedgeIndices[VertexIndex]];
				VertexIDs[CornerIndex] = VertexID;
			}

			if (VertexIDs[0] == VertexIDs[1] || VertexIDs[0] == VertexIDs[2] || VertexIDs[1] == VertexIDs[2])
				continue;

			FPolygonGroupID PolygonGroupID = FPolygonGroupID::Invalid;
			FName PolygonGroupImportedMaterialSlotName = NAME_None;

			if (MaterialIndexToPolygonGroup.Contains(MaterialIndex))
			{
				PolygonGroupID = MaterialIndexToPolygonGroup[MaterialIndex];
				PolygonGroupImportedMaterialSlotName = PolygonGroupImportedMaterialSlotNames[PolygonGroupID];
			}
			else if (MaterialMapOut.Num() > 0 && MaterialMapOut.Contains(MaterialIndex))
			{
				PolygonGroupImportedMaterialSlotName = MaterialMapOut[MaterialIndex];

				for (const FPolygonGroupID& SearchPolygonGroupID : DestinationMeshDescription.PolygonGroups().GetElementIDs())
				{
					if (PolygonGroupImportedMaterialSlotNames[SearchPolygonGroupID] == PolygonGroupImportedMaterialSlotName)
					{
						PolygonGroupID = SearchPolygonGroupID;
						break;
					}
				}
			}

			if (PolygonGroupID == FPolygonGroupID::Invalid)
			{
				PolygonGroupID = DestinationMeshDescription.CreatePolygonGroup();
				PolygonGroupImportedMaterialSlotNames.Set(PolygonGroupID, PolygonGroupImportedMaterialSlotName == NAME_None ? FName(*FString::Printf(TEXT("MaterialSlot_%d"), MaterialIndex)) : PolygonGroupImportedMaterialSlotName);
				MaterialIndexToPolygonGroup.Add(MaterialIndex, PolygonGroupID);
			}

			TArray<FVertexInstanceID> TriangleVertexInstanceIDs;
			TriangleVertexInstanceIDs.SetNum(3);
			const FVector ZeroVector = FVector(ForceInitToZero);

			for (uint32 CornerIndex=0; CornerIndex<3; CornerIndex++)
			{
				const uint32 WedgeIndex = VertexFaceIndexBasis + CornerIndex;
				const uint32 VertexPositionIndex = WedgeIndices[WedgeIndex];
				const FVertexID VertexID = VertexIndexToVertexID[VertexPositionIndex];
				const FVertexInstanceID VertexInstanceID = DestinationMeshDescription.CreateVertexInstance(VertexID);
				TriangleVertexInstanceIDs[CornerIndex] = VertexInstanceID;

				FLinearColor Color = FLinearColor::White;
				FVector Normal = ZeroVector;
				FVector Tangent = ZeroVector;
				float Sign = 1.0f;

				if (bHasNormals)
				{
					Normal = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeNormals[WedgeIndex]);
				}
				VertexInstanceNormals[VertexInstanceID] = Normal;

				if (bHasTangents)
				{
					Tangent = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeTangents[WedgeIndex]);
				}
				VertexInstanceTangents[VertexInstanceID] = Tangent;

				if (bHasTangents && bHasNormals)
				{
					const FVector Binormal = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeBinormals[WedgeIndex]);
					Sign = fnCalculateBinormalSign(Normal, Binormal, Tangent);
				}
				VertexInstanceBinormalSigns[VertexInstanceID] = Sign;

				if (bHasColors)
				{
					Color = FLinearColor::FromSRGBColor(UE4InstaLODMeshHelper::InstaColorRGBAF32ToFColor(WedgeColors[WedgeIndex]));
				}
				VertexInstanceColors[VertexInstanceID] = Color;

				for (int32 TextureCoordinateIndex=0; TextureCoordinateIndex<TexcoordsCount; TextureCoordinateIndex++)
				{
					const int32 TextureCoordinateIndexRemapped = TextureCoordinateRemapIndex[TextureCoordinateIndex];

					if (TextureCoordinateIndexRemapped == INDEX_NONE)
						continue;
					
					VertexInstanceUVs.Set(VertexInstanceID, TextureCoordinateIndexRemapped, UE4InstaLODMeshHelper::InstaVecToFVector(WedgeTextureCoordinates[TextureCoordinateIndex][WedgeIndex]));
				}
			}
			 
			TArray<FVertexInstanceID> TriangleVertexList;
			TriangleVertexList.Add(TriangleVertexInstanceIDs[0]);
			TriangleVertexList.Add(TriangleVertexInstanceIDs[1]);
			TriangleVertexList.Add(TriangleVertexInstanceIDs[2]);
			DestinationMeshDescription.CreateTriangle(PolygonGroupID, TriangleVertexList);
		}
				
		TArray<uint32> SmoothingGroupArray;
		SmoothingGroupArray.AddZeroed(TriangleCount);

		if (SmoothingGroupCount > 0)
		{
			for (uint32 SmoothingGroupIndex=0; SmoothingGroupIndex<SmoothingGroupCount; SmoothingGroupIndex++)
			{
				SmoothingGroupArray[SmoothingGroupIndex] = SmoothingGroups[SmoothingGroupIndex];
			}
		}

		FStaticMeshOperations::ConvertSmoothGroupToHardEdges(SmoothingGroupArray, DestinationMeshDescription);

		// If normals or tangents are missing let's unreal handle this
		if (!bHasNormals || !bHasTangents)
		{
			FStaticMeshOperations::ComputePolygonTangentsAndNormals(DestinationMeshDescription, 0.0f);
			
			EComputeNTBsFlags NormalFlags = EComputeNTBsFlags::Tangents|EComputeNTBsFlags::UseMikkTSpace|EComputeNTBsFlags::BlendOverlappingNormals;
			if (!bHasNormals)
			{
				NormalFlags |= EComputeNTBsFlags::Normals;
			}
			FStaticMeshOperations::ComputeTangentsAndNormals(DestinationMeshDescription, NormalFlags);
		}
	}

	static InstaLOD::MeshFeatureImportance::Type GetInstaLODMeshFeatureImportance(EMeshFeatureImportance::Type Value)
	{
		switch(Value)
		{
			case EMeshFeatureImportance::Off:
				return InstaLOD::MeshFeatureImportance::Off;
			case EMeshFeatureImportance::Lowest:
				return InstaLOD::MeshFeatureImportance::Lowest;
			case EMeshFeatureImportance::Low:
				return InstaLOD::MeshFeatureImportance::Low;
			case EMeshFeatureImportance::Normal:
				return InstaLOD::MeshFeatureImportance::Normal;
			case EMeshFeatureImportance::High:
				return InstaLOD::MeshFeatureImportance::High;
			case EMeshFeatureImportance::Highest:
				return InstaLOD::MeshFeatureImportance::Highest;
			default:
				return InstaLOD::MeshFeatureImportance::Normal;
		}
	}
	
	static InstaLOD::OptimizeSettings ConvertMeshReductionSettingsToInstaLOD(const FMeshReductionSettings& Settings)
	{
		InstaLOD::OptimizeSettings OptimizeSettings;
		OptimizeSettings.ScreenSizeInPixels = 0.0f;
		OptimizeSettings.PercentTriangles = Settings.PercentTriangles;
		OptimizeSettings.AlgorithmStrategy = (InstaLOD::AlgorithmStrategy::Type) CVarAlgorithmStrategy.GetValueOnAnyThread();
		OptimizeSettings.HardAngleThreshold = Settings.HardAngleThreshold;
		OptimizeSettings.MaxDeviation = Settings.MaxDeviation > 0.0f ? Settings.MaxDeviation : CVarDefaultMaximumError.GetValueOnAnyThread();
		OptimizeSettings.ShadingImportance = GetInstaLODMeshFeatureImportance(Settings.ShadingImportance);
		OptimizeSettings.TextureImportance = GetInstaLODMeshFeatureImportance(Settings.TextureImportance);
		OptimizeSettings.SilhouetteImportance = GetInstaLODMeshFeatureImportance(Settings.SilhouetteImportance == EMeshFeatureImportance::High ? EMeshFeatureImportance::Normal :
																				 (EMeshFeatureImportance::Type)Settings.SilhouetteImportance);
		OptimizeSettings.WeldingThreshold = Settings.WeldingThreshold;
		OptimizeSettings.LockSplits = CVarLockSplits.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.LockBoundaries = CVarLockBoundaries.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.RecalculateNormals = Settings.bRecalculateNormals;
		OptimizeSettings.WeightedNormals = CVarWeightedNormals.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.WeldingProtectDistinctUVShells = CVarWeldingProtectDistinctUVShells.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.OptimalPlacement = CVarOptimalPlacement.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.OptimizerVertexWeights = CVarForceOptimizerWeights.GetValueOnAnyThread() > 0 || Settings.SilhouetteImportance >= EMeshFeatureImportance::High ? true : false;
		return OptimizeSettings;
	}

	static void FillNamedMaterialMap(TMap<int32, FName> &OutMaterialMap, const TArray<FStaticMaterial>& StaticMaterials)
	{
		OutMaterialMap.Empty(StaticMaterials.Num());

		for (int32 MaterialIndex=0; MaterialIndex<StaticMaterials.Num(); MaterialIndex++)
		{
			FName MaterialName = StaticMaterials[MaterialIndex].ImportedMaterialSlotName;
			if (MaterialName == NAME_None)
			{
				MaterialName = *(TEXT("MaterialSlot_") + FString::FromInt(MaterialIndex));
			}
			OutMaterialMap.Add(MaterialIndex, MaterialName);
		}
	}

	static void CreateInputOutputMaterialMapFromMeshDescription(const FMeshDescription& InMesh, TMap<FName, int32>& InMaterialMap, TMap<int32, FName>& OutMaterialMap)
	{
		TPolygonGroupAttributesConstRef<FName> PolygonGroupMaterialSlotName = InMesh.PolygonGroupAttributes().GetAttributesRef<FName>(MeshAttribute::PolygonGroup::ImportedMaterialSlotName);

		for (const FPolygonGroupID& PolygonGroupID : InMesh.PolygonGroups().GetElementIDs())
		{
			const FName& Name = PolygonGroupMaterialSlotName[PolygonGroupID];
			
			InMaterialMap.Add(Name, PolygonGroupID.GetValue());
			OutMaterialMap.Add(PolygonGroupID.GetValue(), Name);
		}
	}
};

namespace UE4InstaLODSkeletalMeshHelper
{
	using UE4_StaticLODModel = IInstaLOD::UE4_StaticLODModel;

	static TArray<uint32> GetSkipSectionsForLODModel(const FSkeletalMeshLODModel *const SourceLODModel, const int32 LODIndex = -1)
	{
		if (SourceLODModel == nullptr)
			return TArray<uint32>();

		TArray<uint32> SkipSections;

		for (uint32 SectionIndex=0; SectionIndex<(uint32)SourceLODModel->Sections.Num(); SectionIndex++)
		{
			const FSkelMeshSection& Section = SourceLODModel->Sections[SectionIndex];

			if (Section.bDisabled)
			{
				SkipSections.Add(SectionIndex);
				continue;
			}

			if (LODIndex != -1)
			{
				const int32 LODEnabledIndex = Section.GenerateUpToLodIndex;

				if (LODEnabledIndex != -1 && LODEnabledIndex < LODIndex)
					SkipSections.Add(SectionIndex);
			}
		}
		return SkipSections;
	}

	static void BindClothAtLODIndex(USkeletalMesh* SkeletalMesh, TArray<ClothingAssetUtils::FClothingAssetMeshBinding>& ClothingBindings, const int32 LODIndex)
	{
		if (ClothingBindings.Num() == 0 || !SkeletalMesh->GetImportedModel()->LODModels.IsValidIndex(LODIndex))
			return;

		FSkeletalMeshLODModel* LODModel = SkeletalMesh->GetImportedModel()->LODModels.GetData()[LODIndex];
		for (ClothingAssetUtils::FClothingAssetMeshBinding& Binding : ClothingBindings)
		{
			for (int32 SectionIndex = 0; SectionIndex < LODModel->Sections.Num(); ++SectionIndex)
			{
				if (LODModel->Sections[SectionIndex].OriginalDataSectionIndex != Binding.SectionIndex)
					continue;

				if (Binding.LODIndex != LODIndex || !Binding.Asset)
					break;

				if (Binding.Asset->BindToSkeletalMesh(SkeletalMesh, Binding.LODIndex, SectionIndex, Binding.AssetInternalLodIndex))
				{
					LODModel = SkeletalMesh->GetImportedModel()->LODModels.GetData()[LODIndex];
					check(LODModel->UserSectionsData.Num() != 0);

					FSkelMeshSourceSectionUserData& SectionUserData = LODModel->UserSectionsData.FindChecked(Binding.SectionIndex);
					SectionUserData.CorrespondClothAssetIndex = LODModel->Sections[SectionIndex].CorrespondClothAssetIndex;
					SectionUserData.ClothingData = LODModel->Sections[SectionIndex].ClothingData;
				}
			}
		}
	}

	static void BindCloth(USkeletalMesh* SkeletalMesh, TArray<ClothingAssetUtils::FClothingAssetMeshBinding>& ClothingBindings)
	{
		if (ClothingBindings.Num() == 0)
			return;

		for (int32 LODIndex = 0; LODIndex < SkeletalMesh->GetImportedModel()->LODModels.Num(); ++LODIndex)
		{
			UE4InstaLODSkeletalMeshHelper::BindClothAtLODIndex(SkeletalMesh, ClothingBindings, LODIndex);
		}
	}

	static void UnbindClothAtLODIndex(USkeletalMesh* SkeletalMesh, TArray<ClothingAssetUtils::FClothingAssetMeshBinding>& ClothingBindings, const int32 LODIndex)
	{
		if (!SkeletalMesh->GetImportedModel()->LODModels.IsValidIndex(LODIndex))
			return;

		FSkeletalMeshLODModel* LODModel = SkeletalMesh->GetImportedModel()->LODModels.GetData()[LODIndex];
		ClothingAssetUtils::GetMeshClothingAssetBindings(SkeletalMesh, ClothingBindings, LODIndex);

		for (ClothingAssetUtils::FClothingAssetMeshBinding& Binding : ClothingBindings)
		{
			if (Binding.LODIndex != LODIndex)

				continue;

			int32 OriginalDataSectionIndex = LODModel->Sections[Binding.SectionIndex].OriginalDataSectionIndex;
			if (Binding.Asset)
			{
				Binding.Asset->UnbindFromSkeletalMesh(SkeletalMesh, Binding.LODIndex);
				Binding.SectionIndex = OriginalDataSectionIndex;
			}

			// NOTE: LODModel may change in UnbindFromSkeletal mesh
			LODModel = SkeletalMesh->GetImportedModel()->LODModels.GetData()[LODIndex];

			if (LODModel->UserSectionsData.Num() == 0)
				break;

			FSkelMeshSourceSectionUserData& SectionUserData = LODModel->UserSectionsData.FindChecked(OriginalDataSectionIndex);
			SectionUserData.ClothingData.AssetGuid = FGuid();
			SectionUserData.ClothingData.AssetLodIndex = INDEX_NONE;
			SectionUserData.CorrespondClothAssetIndex = INDEX_NONE;
		}
	}

	static void UnbindCloth(USkeletalMesh* SkeletalMesh, TArray<ClothingAssetUtils::FClothingAssetMeshBinding>& ClothingBindings)
	{
		for (int32 LODIndex = 0; LODIndex < SkeletalMesh->GetImportedModel()->LODModels.Num(); ++LODIndex)
		{
			TArray<ClothingAssetUtils::FClothingAssetMeshBinding> LODBindings;
			UE4InstaLODSkeletalMeshHelper::UnbindClothAtLODIndex(SkeletalMesh, LODBindings, LODIndex);
			ClothingBindings.Append(LODBindings);
		}
	}
	
	static void SkeletalLODModelToInstaLODMesh(const UE4_StaticLODModel& SourceLODModel, InstaLOD::IInstaLODMesh *const InstaMesh, TArray<uint32>& SkipSections, UE4_SkeletalBakePoseData *const BakePoseData = nullptr)
	{
		// build buffers
		TArray<FSoftSkinVertex> Vertices;
		SourceLODModel.GetVertices(Vertices);

		// create a list of all valid section indices from the section indices which should be skipped
		TArray<uint32> ValidSectionIndices;
		for (uint32 SectionIndex=0; SectionIndex<(uint32)SourceLODModel.Sections.Num(); SectionIndex++)
		{
			if (SkipSections.Contains(SectionIndex))
				continue;

			ValidSectionIndices.Add(SectionIndex);
		}

		uint32 VertexCount = 0;
		uint32 TriangleCount = 0;

		// collect total triangle and vertex count from valid sections
		for (uint32 SectionIndex : ValidSectionIndices)
		{
			const FSkelMeshSection& Section = SourceLODModel.Sections[SectionIndex];

			VertexCount += Section.NumVertices;
			TriangleCount += Section.NumTriangles;
		}
		
		InstaMesh->Clear();
		InstaMesh->SetFrontFaceWindingOrder(InstaLOD::IInstaLODMesh::WindingOrderClockwise);
		InstaMesh->SetMeshFormatType(InstaLOD::MeshFormat::DirectX);
		
		// setup per-vertex data buffers
		InstaMesh->ResizeVertexPositions(VertexCount);
		InstaMesh->GetSkinnedVertexData()->Initialize(VertexCount, MAX_TOTAL_INFLUENCES);
		
		// setup per-wedge data buffers
		const uint32 WedgeCount = TriangleCount * 3;
		InstaMesh->ResizeWedgeIndices(WedgeCount);
		InstaMesh->ResizeWedgeTangents(WedgeCount);
		InstaMesh->ResizeWedgeBinormals(WedgeCount);
		InstaMesh->ResizeWedgeNormals(WedgeCount);
		
		// setup per-face data buffers
		InstaMesh->ResizeFaceSmoothingGroups(TriangleCount);
		InstaMesh->ResizeFaceMaterialIndices(TriangleCount);
		
		// setup texcoords
		const int32 TexcoordCount = FMath::Min<int32>(InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS, SourceLODModel.NumTexCoords);
		for (int32 i=0; i<TexcoordCount; i++)
		{
			InstaMesh->ResizeWedgeTexCoords(i, WedgeCount);
		}
		
		// is color data available?
		InstaMesh->ResizeWedgeColors(0, WedgeCount);
		
		if (BakePoseData != nullptr &&
			BakePoseData->BakePoseAnimation != nullptr &&
			BakePoseData->ReferenceSkeleton != nullptr &&
			BakePoseData->SkeletalMesh != nullptr)
		{
			const FReferenceSkeleton& ReferenceSkeleton = *BakePoseData->ReferenceSkeleton;
			const int32 BoneCount = ReferenceSkeleton.GetNum();
			TArray<FName> BoneNames;
			BoneNames.Reserve(BoneCount);

			for (int CurrentBoneIndex=0; CurrentBoneIndex<BoneCount; CurrentBoneIndex++)
			{
				BoneNames.Add(ReferenceSkeleton.GetBoneName(CurrentBoneIndex));
			}

			TArray<FTransform> BonePoses;
			UAnimationBlueprintLibrary::GetBonePosesForFrame(BakePoseData->BakePoseAnimation, BoneNames, 0, true, BonePoses, BakePoseData->SkeletalMesh);

			const TArray<FTransform>& ReferencePoseInLocalSpace = ReferenceSkeleton.GetRefBonePose();

			// Collect transformation from bind pose and animation pose
			// and apply the animation pose to the vertices
			TArray<FTransform> ReferencePoseInComponentSpace;
			ReferencePoseInComponentSpace.AddUninitialized(ReferenceSkeleton.GetNum());

			for (int CurrentBoneIndex=0; CurrentBoneIndex<ReferencePoseInLocalSpace.Num(); CurrentBoneIndex++)
			{
				ReferencePoseInComponentSpace[CurrentBoneIndex] = FTransform::Identity;
			}

			// bind pose
			for (int CurrentBoneIndex=0; CurrentBoneIndex<BoneCount; CurrentBoneIndex++)
			{
				const int32 ParentIndex = ReferenceSkeleton.GetParentIndex(CurrentBoneIndex);

				if (ParentIndex != INDEX_NONE)
				{
					ReferencePoseInComponentSpace[CurrentBoneIndex] = ReferencePoseInLocalSpace[CurrentBoneIndex] * ReferencePoseInComponentSpace[ParentIndex];
				}
				else
				{
					ReferencePoseInComponentSpace[CurrentBoneIndex] = ReferencePoseInLocalSpace[CurrentBoneIndex];
				}
			}

			TArray<FMatrix> ComponentSpacePose;
			TArray<FMatrix> ComponentSpaceReferencePose;
			TArray<FMatrix> AnimationPoseMatrices;
			ComponentSpacePose.AddUninitialized(ReferenceSkeleton.GetNum());
			ComponentSpaceReferencePose.AddUninitialized(ReferenceSkeleton.GetNum());
			AnimationPoseMatrices.AddUninitialized(ReferenceSkeleton.GetNum());

			for (int32 CurrentBoneIndex=0; CurrentBoneIndex<ReferenceSkeleton.GetNum(); CurrentBoneIndex++)
			{
				ComponentSpaceReferencePose[CurrentBoneIndex] = ReferencePoseInComponentSpace[CurrentBoneIndex].ToMatrixWithScale();
				AnimationPoseMatrices[CurrentBoneIndex] = BonePoses[CurrentBoneIndex].ToMatrixWithScale();
			}

			// animation pose
			for (int32 CurrentBoneIndex=0; CurrentBoneIndex<BoneCount; CurrentBoneIndex++)
			{
				const int32 ParentIndex = ReferenceSkeleton.GetParentIndex(CurrentBoneIndex);
				if (ParentIndex != INDEX_NONE)
				{
					ComponentSpacePose[CurrentBoneIndex] = AnimationPoseMatrices[CurrentBoneIndex] * ComponentSpacePose[ParentIndex];
				}
				else
				{
					ComponentSpacePose[CurrentBoneIndex] = AnimationPoseMatrices[CurrentBoneIndex];
				}
			}

			// calculate relative to reference pose from animation pose
			TArray<FMatrix> RelativeToReferencePoseMatrices;
			RelativeToReferencePoseMatrices.AddUninitialized(BoneCount);

			for (int32 BoneIndex=0; BoneIndex<BoneCount; BoneIndex++)
			{
				RelativeToReferencePoseMatrices[BoneIndex] = ComponentSpaceReferencePose[BoneIndex].Inverse() * ComponentSpacePose[BoneIndex];
			}

			TArray<float> BoneInfluences;
			BoneInfluences.Reserve(MAX_TOTAL_INFLUENCES);
			TArray<uint8> BoneIndices;
			BoneIndices.Reserve(MAX_TOTAL_INFLUENCES);

			for (const uint32 SectionIndex : ValidSectionIndices)
			{
				const FSkelMeshSection& Section = SourceLODModel.Sections[SectionIndex];
				const uint32 EndVertexIndex = Section.BaseVertexIndex + Section.NumVertices;

				for (uint32 VertexIndex=Section.BaseVertexIndex; VertexIndex<EndVertexIndex; VertexIndex++)
				{
					FSoftSkinVertex& Vertex = Vertices[VertexIndex];
					int TotalInfluence = 0;

					// accumulate influences
					for (const uint8 influence:Vertex.InfluenceWeights)
					{
						BoneInfluences.Add(influence);
						TotalInfluence += influence;
					}

					if (TotalInfluence != 255)
					{
						UE_LOG(LogInstaLOD, Warning, TEXT("Skeletal mesh contains invalid weight distribution, please consider renormalizing weights."))
					}

					for (const uint8 boneIndex : Vertex.InfluenceBones)
					{
						BoneIndices.Add(boneIndex);
					}

					// Calculate blended matrix
					FMatrix BlendedMatrix(ForceInitToZero);
					
					if (TotalInfluence > 0)
					{
						for (int Index=0; Index<MAX_TOTAL_INFLUENCES; Index++)
						{
							const uint8 CurrentBoneIndex = Section.BoneMap[BoneIndices[Index]];
							const float CurrentBoneInfluence = BoneInfluences[Index];

							if (CurrentBoneInfluence>0)
							{
								BlendedMatrix += RelativeToReferencePoseMatrices[CurrentBoneIndex] * (CurrentBoneInfluence/(float)TotalInfluence);
							}
						}
					}

					// apply transformation to vertex
					FVector oldPosition = Vertex.Position;
					FVector oldTangentX = Vertex.TangentX;
					FVector oldTangentY = Vertex.TangentY;
					FVector oldTangentZ = Vertex.TangentZ;

					Vertex.Position = BlendedMatrix.TransformPosition(Vertex.Position);
					FVector WeightedTangentX = BlendedMatrix.TransformVector(Vertex.TangentX);
					FVector WeightedTangentY = BlendedMatrix.TransformVector(Vertex.TangentY);
					FVector WeightedTangentZ = BlendedMatrix.TransformVector(Vertex.TangentZ);

					Vertex.TangentX = WeightedTangentX.GetSafeNormal();
					Vertex.TangentY = WeightedTangentY.GetSafeNormal();
					uint8 WComponent = Vertex.TangentZ.W;
					Vertex.TangentZ = WeightedTangentZ.GetSafeNormal();
					Vertex.TangentZ.W = WComponent;

					if (Vertex.Position.ContainsNaN())
					{
						UE_LOG(LogInstaLOD, Warning, TEXT("Skeletal mesh Bake Pose calculation has invalid values."));
						Vertex.Position = oldPosition;
						Vertex.TangentX = oldTangentX;
						Vertex.TangentY = oldTangentY;
						Vertex.TangentZ = oldTangentZ;
					}

					BoneInfluences.Reset();
					BoneIndices.Reset();
				}
			}
		}

		// setup bone and vertex data 
		InstaLOD::InstaVec3F* OutVertexPositions = InstaMesh->GetVertexPositions(NULL);

		// index for InstaLOD vertex buffer
		uint32 OutVertexIndex = 0u;
		for (const uint32 ValidSectionIndex : ValidSectionIndices)
		{
			const FSkelMeshSection& Section = SourceLODModel.Sections[ValidSectionIndex];
			const uint32 EndVertexIndex = Section.BaseVertexIndex + Section.NumVertices;

			for (uint32 VertexIndex=Section.BaseVertexIndex; VertexIndex<EndVertexIndex && VertexIndex < (uint32) Vertices.Num(); VertexIndex++, OutVertexIndex++)
			{
				const FSoftSkinVertex& Vertex = Vertices[VertexIndex];
				OutVertexPositions[OutVertexIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(Vertex.Position);

				// setup weights for this vertex
				InstaLOD::InstaLODSkeletalMeshBoneData *const OutBoneData = InstaMesh->GetSkinnedVertexData()->GetBoneDataForVertex(OutVertexIndex);

				for (uint32 j=0u; j<MAX_TOTAL_INFLUENCES; j++)
				{
					if (Vertex.InfluenceWeights[j] == 0)
					{
						OutBoneData[j] = InstaLOD::InstaLODSkeletalMeshBoneData();
						continue;
					}
					OutBoneData[j].BoneIndex = Section.BoneMap[Vertex.InfluenceBones[j]];
					OutBoneData[j].BoneInfluence = Vertex.InfluenceWeights[j] / 255.0;
				}
			}
		}

		// setup wedge/face data
		uint32 OutWedgeIndex = 0u;
		InstaLOD::uint32 *const OutWedgeIndices = InstaMesh->GetWedgeIndices(NULL);
		InstaLOD::InstaVec3F *const OutWedgeTangents = InstaMesh->GetWedgeTangents(NULL);
		InstaLOD::InstaVec3F *const OutWedgeBinormals = InstaMesh->GetWedgeBinormals(NULL);
		InstaLOD::InstaVec3F *const OutWedgeNormals = InstaMesh->GetWedgeNormals(NULL);
		InstaLOD::InstaColorRGBAF32 *const OutWedgeColors = InstaMesh->GetWedgeColors(0, NULL);
		InstaLOD::InstaVec2F* OutWedgeTexcoords[InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS];
		for (uint32 i=0u; i<InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS; i++)
		{
			OutWedgeTexcoords[i] = InstaMesh->GetWedgeTexCoords(i, NULL);
		}
		uint32 OutFaceIndex = 0;
		InstaLOD::uint32 *const OutFaceSmoothingMasks = InstaMesh->GetFaceSmoothingGroups(NULL);
		InstaLOD::InstaMaterialID *const OutFaceMaterialIndices = InstaMesh->GetFaceMaterialIndices(NULL);

		const int32 kDefaultSmoothingGroup = 1;

		auto SkippedIndexOffset = [](const TArray<FSkelMeshSection>& Sections, const TArray<uint32>& SkipSections, const uint32 SectionIndex) -> uint32
		{
			if (SectionIndex == 0u)
				return 0u;

			uint32 IndexOffset = 0u;
			for (uint32 CurrentSectionIndex=0; CurrentSectionIndex<SectionIndex; CurrentSectionIndex++)
			{
				if (!SkipSections.Contains(CurrentSectionIndex))
					continue;

				IndexOffset += Sections[CurrentSectionIndex].NumVertices;
			}
			return IndexOffset;
		};

		for (const uint32 ValidSectionIndex : ValidSectionIndices)
		{
			const FSkelMeshSection& Section = SourceLODModel.Sections[ValidSectionIndex];
			const uint32 EndVertexIndex = Section.BaseVertexIndex + Section.NumVertices;
			const uint32 SectionWedgeCount = Section.NumTriangles*3;
			uint32 IndexOffset = SkippedIndexOffset(SourceLODModel.Sections, SkipSections, ValidSectionIndex);

			for (uint32 i=0u; i<SectionWedgeCount; i++)
			{
				const int32 WedgeIndex = Section.BaseIndex + i;
				const uint32 VertexIndex = SourceLODModel.IndexBuffer[WedgeIndex];
				const FSoftSkinVertex& Vertex = Vertices[VertexIndex];
				
				OutWedgeIndices[OutWedgeIndex] = VertexIndex - IndexOffset;
				OutWedgeNormals[OutWedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(Vertex.TangentZ);
				OutWedgeBinormals[OutWedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(Vertex.TangentY);
				OutWedgeTangents[OutWedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(Vertex.TangentX);

				for (int32 TexcoordIndex=0; TexcoordIndex<TexcoordCount; TexcoordIndex++)
				{
					OutWedgeTexcoords[TexcoordIndex][OutWedgeIndex] = UE4InstaLODMeshHelper::FVectorToInstaVec(Vertex.UVs[TexcoordIndex]);
				}

				OutWedgeColors[OutWedgeIndex] = UE4InstaLODMeshHelper::FColorToInstaColorRGBAF32(Vertex.Color);
				OutWedgeIndex++;
			}

			for (uint32 i=0u; i<Section.NumTriangles; i++)
			{
				OutFaceSmoothingMasks[OutFaceIndex] = kDefaultSmoothingGroup;
				OutFaceMaterialIndices[OutFaceIndex] = Section.MaterialIndex;
				OutFaceIndex++;
			}
		}

		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutVertexPositions, VertexCount * 3, 0.0f);
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeNormals, WedgeCount * 3, 0.0f);
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeBinormals, WedgeCount * 3, 0.0f);
		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeTangents, WedgeCount * 3, 0.0f);
		for (int32 TexcoordIndex=0; TexcoordIndex<TexcoordCount; TexcoordIndex++)
		{
			UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeTexcoords[TexcoordIndex], WedgeCount * 2, 0.0f);
		}

		UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutWedgeColors, WedgeCount * 4, 0.0f);
	}

	static bool ReferenceSkeletonToInstaLODSkeleton(const FReferenceSkeleton& ReferenceSkeleton, InstaLOD::IInstaLODSkeleton *const InstaSkeleton, TMap<int32, TPair<uint32, FString>>& OutUEBoneIndexToInstaLODBoneIndexAndName)
	{
		if (InstaSkeleton == nullptr)
			return false;

		// set bone transforms as localspace transforms
		InstaSkeleton->SetJointTransformsInWorldSpace(false);

		// NOTE: don't use raw num as we don't need potential IK bones 
		const int BoneCount = ReferenceSkeleton.GetNum();
		const TArray<FTransform>& ReferencePoseInLocalSpace = ReferenceSkeleton.GetRefBonePose();

		// register all bones from ReferenceSkeleton
		for (int CurrentBoneIndex=0; CurrentBoneIndex<BoneCount; CurrentBoneIndex++)
		{
			const int32 ParentIndex = ReferenceSkeleton.GetParentIndex(CurrentBoneIndex);
			const FName BoneName = ReferenceSkeleton.GetBoneName(CurrentBoneIndex);
			const FTransform BoneTransform = ReferencePoseInLocalSpace[CurrentBoneIndex];  
			const uint32 InstaLODParentBoneIndex = ParentIndex == INDEX_NONE ? InstaLOD::INSTALOD_JOINT_INDEX_INVALID : ParentIndex; 

			const FVector Position = BoneTransform.GetLocation();
			const FVector Scale = BoneTransform.GetScale3D();
			const FQuat Orientation = BoneTransform.GetRotation();

			const uint32 InstaLODBoneIndex = InstaSkeleton->AddJoint(
				InstaLODParentBoneIndex,
				CurrentBoneIndex, 
				UE4InstaLODMeshHelper::FVectorToInstaVec(Position),
				UE4InstaLODMeshHelper::FQuatToInstaQuaternion(Orientation),
				UE4InstaLODMeshHelper::FVectorToInstaVec(Scale),
				/*Bone Name*/ "InstaLOD",
				/*User Pointer*/ nullptr
				);

			OutUEBoneIndexToInstaLODBoneIndexAndName.Emplace(CurrentBoneIndex, TPair<uint32, FString>(InstaLODBoneIndex, BoneName.ToString()));
		}

		return true;
	}

	static void InstaLODMeshToSkeletalLODModel(InstaLOD::IInstaLODMesh *const InstaMesh, USkeletalMesh* SourceSkeletalMesh, UE4_StaticLODModel& OutputLODModel, const IInstaLOD::UE4_MeshBuildOptions &BuildOptions)
	{ 
		using namespace SkeletalMeshImportData;
		check(InstaMesh != NULL);
		check(InstaMesh->IsValid());
		
		TArray<FVector> OutPoints;
		TArray<FVertInfluence> OutInfluences;
		InstaLOD::uint64 VertexCount;
		auto Vertices = InstaMesh->GetVertexPositions(&VertexCount);
		OutPoints.AddUninitialized(VertexCount);
		
		if (InstaMesh->GetSkinnedVertexData()->IsInitialized())
		{
			OutInfluences.Reserve(VertexCount * (MAX_TOTAL_INFLUENCES/2));
			
			for (uint32 VertexIndex=0; VertexIndex<VertexCount; VertexIndex++)
			{
				OutPoints[VertexIndex] = UE4InstaLODMeshHelper::InstaVecToFVector(Vertices[VertexIndex]);
				
				InstaLOD::InstaLODSkeletalMeshBoneData *const BoneData = InstaMesh->GetSkinnedVertexData()->GetBoneDataForVertex(VertexIndex);
				
				for (uint32 InfluenceIndex=0; InfluenceIndex<MAX_TOTAL_INFLUENCES; InfluenceIndex++)
				{
					if (BoneData[InfluenceIndex].BoneInfluence <= 0.0)
						continue;
					if (BoneData[InfluenceIndex].BoneIndex == InstaLOD::INSTALOD_BONE_INDEX_INVALID)
						continue;
					
					FVertInfluence VertexInfluence;
					VertexInfluence.BoneIndex = BoneData[InfluenceIndex].BoneIndex;
					VertexInfluence.Weight = BoneData[InfluenceIndex].BoneInfluence;
					VertexInfluence.VertIndex = VertexIndex;
					
					// NOTE: if a weight is specified with a value < (1/255) horrible glitches will occur
					// this is due to the fact that UE4 converts the value to a uint8 type and does not check
					// whether the influence is still > 0
					// A minimum threshold for bone influences can be specified in the InstaLOD settings
					// InstaLOD will then remove all weights that fall below the threshold and renormalize all weights
					// we're doing this, but just in case a developer decided to change the value we've got this safety here
					if (VertexInfluence.Weight < (1.0f/250.0f))
					{
						UE_LOG(LogInstaLOD, Warning, TEXT("Invalid bone influence for vert=%i bone=%i (%s) weight=%f"),
							   VertexInfluence.VertIndex,
							   VertexInfluence.BoneIndex,
							   *(SourceSkeletalMesh->RefSkeleton.GetBoneName(VertexInfluence.BoneIndex).ToString()),
							   VertexInfluence.Weight);
						continue;
					}
					
					OutInfluences.Add(VertexInfluence);
				}
			}
		}
		else
		{
			for (uint32 i=0; i<VertexCount; i++)
			{
				OutPoints[i] = UE4InstaLODMeshHelper::InstaVecToFVector(Vertices[i]);
			}
		}
		
		// build triangle and wedge data
		InstaLOD::uint64 WedgeCount;
		InstaLOD::uint32 *const WedgeIndices = InstaMesh->GetWedgeIndices(&WedgeCount);
		InstaLOD::InstaColorRGBAF32 *const WedgeColors = InstaMesh->GetWedgeColors(0, NULL);
		InstaLOD::InstaVec3F *const WedgeTangents = InstaMesh->GetWedgeTangents(NULL);
		InstaLOD::InstaVec3F *const WedgeBinormals = InstaMesh->GetWedgeBinormals(NULL);
		InstaLOD::InstaVec3F *const WedgeNormals = InstaMesh->GetWedgeNormals(NULL);
		uint32 TexcoordCount = 0;
		InstaLOD::InstaVec2F* WedgeTexcoords[MAX_TEXCOORDS]; /**< NOTE: array size is UE4's max texcoord define */
		for (uint32 i=0; i<InstaLOD::INSTALOD_MAX_MESH_TEXCOORDS; i++)
		{
			WedgeTexcoords[TexcoordCount] = InstaMesh->GetWedgeTexCoords(i, NULL);
			
			if (WedgeTexcoords[TexcoordCount] != NULL)
			{
				TexcoordCount++;
				
				if (TexcoordCount >= MAX_TEXCOORDS)
					break;
			}
		}
		InstaLOD::uint64 FaceCount;
		InstaLOD::uint32 *const FaceSmoothingGroups = InstaMesh->GetFaceSmoothingGroups(&FaceCount);
		InstaLOD::InstaMaterialID *const FaceMaterialIndices = InstaMesh->GetFaceMaterialIndices(NULL);
		check(FaceCount * 3 == WedgeCount);
		
		TArray<FMeshWedge> OutWedges;
		TArray<FMeshFace> OutFaces;
		OutWedges.AddUninitialized(WedgeCount);
		OutFaces.AddUninitialized(FaceCount);
		
		static FColor kDefaultColor(0, 0, 0, 255);
		
		for (uint32 FaceIndex=0; FaceIndex<FaceCount; FaceIndex++)
		{
			FMeshFace &Face = OutFaces[FaceIndex];
			
			Face.MeshMaterialIndex = FaceMaterialIndices[FaceIndex];
			
			// NOTE: SmoothingGroups field has been introduced with 4.11+ API
			Face.SmoothingGroups = FaceSmoothingGroups[FaceIndex];
			
			// NOTE: this should unroll well
			for (uint32 CornerIndex=0; CornerIndex<3; CornerIndex++)
			{
				const uint32 WedgeIndex = FaceIndex*3+CornerIndex;
				
				Face.iWedge[CornerIndex] = WedgeIndex;
				Face.TangentX[CornerIndex] = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeTangents[WedgeIndex]);
				Face.TangentY[CornerIndex] = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeBinormals[WedgeIndex]);
				Face.TangentZ[CornerIndex] = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeNormals[WedgeIndex]);
				
				FMeshWedge &wedge = OutWedges[WedgeIndex];
				wedge.Color = (WedgeColors == NULL) ? kDefaultColor : UE4InstaLODMeshHelper::InstaColorRGBAF32ToFColor(WedgeColors[WedgeIndex]);
				wedge.iVertex = WedgeIndices[WedgeIndex];
				
				for (uint32 TexcoordIndex=0; TexcoordIndex<TexcoordCount; TexcoordIndex++)
				{
						wedge.UVs[TexcoordIndex] = UE4InstaLODMeshHelper::InstaVecToFVector(WedgeTexcoords[TexcoordIndex][WedgeIndex]);
				}

				for (uint32 TexcoordIndex=TexcoordCount; TexcoordIndex<MAX_TEXCOORDS; TexcoordIndex++)
				{
						wedge.UVs[TexcoordIndex] = FVector2D(0, 0);
				}
			}
		}
		
		// NOTE: we don't know how the vertices related to the original import vertices, so create a faux-map
		TArray<int32> TempPointToOriginalMap;
		TempPointToOriginalMap.AddUninitialized(OutPoints.Num());
		for(int32 i=0; i<OutPoints.Num(); i++)
		{
			TempPointToOriginalMap[i] = i;
		}
		
		IMeshUtilities& MeshUtilities = FModuleManager::Get().GetModuleChecked<IMeshUtilities>("MeshUtilities");
		
		FString SkeletalMeshName;
		SourceSkeletalMesh->GetName(SkeletalMeshName);
		const bool buildResult = MeshUtilities.BuildSkeletalMesh(OutputLODModel, SkeletalMeshName, SourceSkeletalMesh->RefSkeleton,
																 OutInfluences, OutWedges, OutFaces, OutPoints, TempPointToOriginalMap,
																 BuildOptions);
		
		// Set texture coordinate count on the new model.
		OutputLODModel.NumTexCoords = TexcoordCount;
	}
	
	static InstaLOD::MeshFeatureImportance::Type GetInstaLODMeshFeatureImportance(SkeletalMeshOptimizationImportance value)
	{
		switch(value)
		{
			case SMOI_Off:
				return InstaLOD::MeshFeatureImportance::Off;
			case SMOI_Lowest:
				return InstaLOD::MeshFeatureImportance::Lowest;
			case SMOI_Low:
				return InstaLOD::MeshFeatureImportance::Low;
			case SMOI_Normal:
				return InstaLOD::MeshFeatureImportance::Normal;
			case SMOI_High:
				return InstaLOD::MeshFeatureImportance::High;
			case SMOI_Highest:
				return InstaLOD::MeshFeatureImportance::Highest;
			default:
				return InstaLOD::MeshFeatureImportance::Normal;
		}
	}
	
	static InstaLOD::OptimizeSettings ConvertMeshReductionSettingsToInstaLOD(const FSkeletalMeshOptimizationSettings& Settings, USkeletalMesh* SkeletalMesh)
	{
		InstaLOD::OptimizeSettings OptimizeSettings;
		
		// Settings.BoneReductionRatio
		OptimizeSettings.SkinningImportance = GetInstaLODMeshFeatureImportance(Settings.SkinningImportance);
		OptimizeSettings.SkeletonOptimize.MinimumBoneInfluenceThreshold = 1.0f / 250.0f;
		OptimizeSettings.SkeletonOptimize.MaximumBoneInfluencesPerVertex = Settings.MaxBonesPerVertex;
		
		OptimizeSettings.ScreenSizeInPixels = 0.0f;
		OptimizeSettings.PercentTriangles = Settings.NumOfTrianglesPercentage;
		OptimizeSettings.AlgorithmStrategy = (InstaLOD::AlgorithmStrategy::Type) CVarAlgorithmStrategy.GetValueOnAnyThread();
		OptimizeSettings.HardAngleThreshold = Settings.NormalsThreshold;
		// NOTE: max deviation is divided by the magic-number 2000.0f as seen in PersonaMeshDetails.cpp:FSkelMeshReductionSettingsLayout::OnMaxDeviationChanged
		// this is an absurd hack, and we have to accomodate for that
		OptimizeSettings.MaxDeviation = Settings.MaxDeviationPercentage > 0 ? Settings.MaxDeviationPercentage * 2000.0f : CVarDefaultMaximumError.GetValueOnAnyThread();
		OptimizeSettings.ShadingImportance = GetInstaLODMeshFeatureImportance(Settings.ShadingImportance);
		OptimizeSettings.TextureImportance = GetInstaLODMeshFeatureImportance(Settings.TextureImportance);
		OptimizeSettings.SilhouetteImportance = GetInstaLODMeshFeatureImportance(Settings.SilhouetteImportance == SMOI_High ? SMOI_Normal : (SkeletalMeshOptimizationImportance)Settings.SilhouetteImportance);
		OptimizeSettings.SkinningImportance = GetInstaLODMeshFeatureImportance(Settings.SkinningImportance);
		OptimizeSettings.WeldingThreshold = Settings.WeldingThreshold;
		OptimizeSettings.LockSplits = CVarLockSplits.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.LockBoundaries = CVarLockBoundaries.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.RecalculateNormals = Settings.bRecalcNormals;
		OptimizeSettings.WeightedNormals = CVarWeightedNormals.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.WeldingProtectDistinctUVShells = CVarWeldingProtectDistinctUVShells.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.OptimalPlacement = CVarOptimalPlacement.GetValueOnAnyThread() > 0 ? true : false;
		OptimizeSettings.OptimizerVertexWeights = CVarForceOptimizerWeights.GetValueOnAnyThread() > 0 || Settings.SilhouetteImportance >= SMOI_High ? true : false;
		return OptimizeSettings;
	}
};

FInstaLOD::FInstaLOD(InstaLOD::IInstaLOD *InstaLODAPI)
{
	InstaLOD = InstaLODAPI;
	VersionString = InstaLODShared::Version;
}

void FInstaLOD::UnbindClothAtLODIndex(USkeletalMesh* SkeletalMesh, const int32 LODIndex)
{
	if(SkeletalMesh == nullptr)
		return;
	TArray<ClothingAssetUtils::FClothingAssetMeshBinding> ClothingBindings;
	UE4InstaLODSkeletalMeshHelper::UnbindClothAtLODIndex(SkeletalMesh, ClothingBindings, LODIndex);
}

void FInstaLOD::ReduceMeshDescription(FMeshDescription& OutReducedMesh, float& OutMaxDeviation, const FMeshDescription& InMesh,
									  const FOverlappingCorners& InOverlappingCorners, const struct FMeshReductionSettings& ReductionSettings)
{
	TMap<FName, int32> InMaterialMap;
	TMap<int32, FName> OutMaterialMap;

	UE4InstaLODMeshHelper::CreateInputOutputMaterialMapFromMeshDescription(InMesh, InMaterialMap, OutMaterialMap);

	InstaLOD::IInstaLODMesh *InstaMesh = AllocInstaLODMesh();
	InstaLOD::IInstaLODMesh *OutMesh = AllocInstaLODMesh();
	UE4InstaLODMeshHelper::MeshDescriptionToInstaLODMesh(InMesh, InMaterialMap, InstaMesh);
	InstaLOD::OptimizeSettings OptimizeSettings = UE4InstaLODMeshHelper::ConvertMeshReductionSettingsToInstaLOD(ReductionSettings);

	InstaMesh->SanitizeMesh();

	if (OptimizeSettings.OptimizerVertexWeights)
	{
		if (!InstaMesh->ConvertColorDataToOptimizerWeights(0))
		{
			UE_LOG(LogInstaLOD, Log, TEXT("Failed to convert color data to optimizer weights. Is color data available for mesh?"));
		}
	}
	
	const double T0 = FPlatformTime::Seconds();
	
	// generate optimized insta mesh
	auto InstaResult = InstaLOD->Optimize(InstaMesh, OutMesh, OptimizeSettings);
	
	const double T1 = FPlatformTime::Seconds();
	const float ElapsedTime = (float)(T1-T0);
	
	if (InstaResult.Success)
	{
		// scale deviation per cvar
		InstaResult.MeshDeviation *= CVarDecimatedErrorFactor.GetValueOnAnyThread();
		OutMaxDeviation = InstaResult.MeshDeviation;
	}
	else
	{
		char InstaLog[8192];
		InstaLOD->GetMessageLog(InstaLog, sizeof(InstaLog), NULL);
		UE_LOG(LogInstaLOD, Error, TEXT("Optimization failed. Log: %s"), UTF8_TO_TCHAR(InstaLog));
		OutMaxDeviation = 0;

		// restore input mesh
		InstaLOD::IInstaLODMesh *temp = InstaMesh;
		InstaMesh = OutMesh;
		OutMesh = temp;
	}
	
	if (CVarWriteOBJ.GetValueOnAnyThread().Len() > 0)
	{
		FText NotificationText;
		if (OutMesh->WriteLightwaveOBJ(TCHAR_TO_UTF8(*CVarWriteOBJ.GetValueOnAnyThread())))
		{
			NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Wrote Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
			DispatchNotification(NotificationText, SNotificationItem::CS_Success);
		}
		else
		{
			NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Failed to write Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
			DispatchNotification(NotificationText, SNotificationItem::CS_Fail);
		}
		UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
	}

	// remove possible duplicates
	InstaLOD->CastToInstaLODMeshExtended(OutMesh)->FixDuplicateVertexPositions(0.0f);
	
	UE4InstaLODMeshHelper::InstaLODMeshToMeshDescription(OutMesh, OutMaterialMap, OutReducedMesh);

	InstaLOD->DeallocMesh(InstaMesh);
}
 
bool FInstaLOD::ReduceSkeletalMesh(class USkeletalMesh* SkeletalMesh, int32 LODIndex)
{
	bool bReregisterComponent = false;
	const FSkeletalMeshOptimizationSettings ReductionSettings = SkeletalMesh->GetLODInfoArray().IsValidIndex(LODIndex) ? SkeletalMesh->GetLODInfo(LODIndex)->ReductionSettings  : FSkeletalMeshOptimizationSettings();
	const bool bCalcLODDistance = !SkeletalMesh->GetLODInfoArray().IsValidIndex(LODIndex); // From UE4.19, LODUtilities.cpp, line 106 

	return ReduceSkeletalMesh(SkeletalMesh, LODIndex, ReductionSettings, bCalcLODDistance, bReregisterComponent);
}

bool FInstaLOD::ReduceSkeletalMesh(class USkeletalMesh* SkeletalMesh, int32 LODIndex, const struct FSkeletalMeshOptimizationSettings& Settings,
								   bool bCalcLODDistance, bool bReregisterComponent)
{
	if (bReregisterComponent)
	{
		// Should only be used from the rendering thread.
		if (!GIsThreadedRendering)
			TComponentReregisterContext<USkinnedMeshComponent> ReregisterContext;

		SkeletalMesh->ReleaseResources();
		SkeletalMesh->ReleaseResourcesFence.Wait();
	}
	
	ReduceSkeletalMeshAtLODIndex(SkeletalMesh, LODIndex, Settings, bCalcLODDistance);
	
	if (bReregisterComponent)
	{
		SkeletalMesh->PostEditChange();
		SkeletalMesh->InitResources();
	}
	
	return true;
}

bool FInstaLOD::ReduceSkeletalMesh(class USkeletalMesh* SkeletalMesh, int32 LODIndex,
								   const struct FSkeletalMeshOptimizationSettings& Settings, bool bCalcLODDistance)
{
	ReduceSkeletalMesh(SkeletalMesh, LODIndex, Settings, bCalcLODDistance, true);
	
	return true;
}

void FInstaLOD::ReduceSkeletalMeshAtLODIndex(class USkeletalMesh* SkeletalMesh, int32 LODIndex,
	const FSkeletalMeshOptimizationSettings& Settings, bool bCalcLODDistance)
{
	check( SkeletalMesh );
	
	if (IsRunningCommandlet() && !InstaLOD->IsHostAuthorized())
	{
		UE_LOG(LogInstaLOD, Fatal, TEXT("This machine is not authorized to run InstaLOD. Please authorize this machine before cooking using the editor or InstaLOD Pipeline."));
	}

	// determine whether LOD at index is imported by checking if it exists and the HasBeenSimplified flag is not set
	bool bOldLODWasFromFile = SkeletalMesh->IsValidLODIndex(LODIndex) && SkeletalMesh->GetLODInfo(LODIndex)->bHasBeenSimplified == false;
	
	// get the default resource for this skeletal mesh
	UE4_SkeletalMeshResource *const SkeletalMeshResource = SkeletalMesh->GetImportedModel();

	if (LODIndex < 0 || LODIndex > SkeletalMesh->GetLODInfoArray().Num() || LODIndex > SkeletalMesh->GetLODInfoArray().Num())
	{
		UE_LOG(LogInstaLOD, Fatal, TEXT("LOD Index=%i out of range"), LODIndex);
		return;
	}
	
	// persist settings for this LOD
	if (!SkeletalMesh->GetLODInfoArray().IsValidIndex(LODIndex))
	{
		SkeletalMesh->AddLODInfo();
	}
	SkeletalMesh->GetLODInfo(LODIndex)->ReductionSettings = Settings;

	// copies off the source model for this skeletal mesh if necessary and returns it
	UE4_StaticLODModel* SourceLODModel = &SkeletalMeshResource->LODModels[0];

	const int32 BaseLOD = FMath::Max(LODIndex - 1, 0);

	UE4_StaticLODModel *const OutputLODModel = new UE4_StaticLODModel();

	bool bReducingOriginalSourceModel = false;
	FSkeletalMeshLODModel *OldSourceLODModel = nullptr;

	// NOTE: if this is the source model we need to keep it
	if (BaseLOD == LODIndex && SkeletalMeshResource->OriginalReductionSourceMeshData.IsValidIndex(BaseLOD) && !SkeletalMeshResource->OriginalReductionSourceMeshData[BaseLOD]->IsEmpty())
	{
		bReducingOriginalSourceModel = true;
	}

	// did append a new lod model at index?
	bool bIsNewLODIndexForModel = false;

	// keep section info
	TMap<int32, FSkelMeshSourceSectionUserData> PreviousUserSectionsData;
	FString PreviousLODModelBuildStringID = TEXT("");
	TArray<ClothingAssetUtils::FClothingAssetMeshBinding> ClothBindings;

	// is a new lod model required?
	if (!SkeletalMeshResource->LODModels.IsValidIndex(LODIndex))
	{
		SkeletalMeshResource->LODModels.Add(OutputLODModel);
		bIsNewLODIndexForModel = true;
	}
	else
	{
		// NOTE: in case of BaseLOD == LODIndex we need the previous model
		if (BaseLOD != LODIndex && SkeletalMeshResource->LODModels.GetData()[LODIndex] != NULL)
		{
			UE4InstaLODSkeletalMeshHelper::UnbindClothAtLODIndex(SkeletalMesh, ClothBindings, LODIndex);
			FSkeletalMeshLODModel& PreviousBackupSectionLODModel = SkeletalMeshResource->LODModels[LODIndex];
			PreviousLODModelBuildStringID = PreviousBackupSectionLODModel.BuildStringID;
			PreviousUserSectionsData = PreviousBackupSectionLODModel.UserSectionsData;

			// make sure data is deleted correctly
			if (Settings.OnDeleteLODModelDelegate.IsBound())
			{
				Settings.OnDeleteLODModelDelegate.Execute(SkeletalMeshResource->LODModels.GetData()[LODIndex]);
			}
			else
			{
				check(IsInGameThread());
				delete SkeletalMeshResource->LODModels.GetData()[LODIndex];
			}
		}
		else if (BaseLOD == LODIndex)
		{
			OldSourceLODModel = SkeletalMeshResource->LODModels.GetData()[LODIndex];
		}

		SkeletalMeshResource->LODModels.GetData()[LODIndex] = OutputLODModel;
	}

	// copy from settings from BaseLOD
	if (!SkeletalMesh->GetLODInfoArray().IsValidIndex(LODIndex))
	{
		SkeletalMesh->GetLODInfoArray().Add(FSkeletalMeshLODInfo());
		SkeletalMesh->GetLODInfoArray()[LODIndex] = SkeletalMesh->GetLODInfoArray()[BaseLOD];
	}

	UE4_SkeletalBakePoseData BakePoseData;

	// NOTE: if a bake pose is set we must apply it to the mesh
	// the actual BakePose is the first frame of the set animation
	if (UAnimSequence *const BakePoseAnim = SkeletalMesh->GetLODInfo(LODIndex)->BakePose)
	{
		BakePoseData.BakePoseAnimation = BakePoseAnim;
		BakePoseData.ReferenceSkeleton = &SkeletalMesh->RefSkeleton;
		BakePoseData.SkeletalMesh = SkeletalMesh;
	}

	// create our insta meshes and feed data into our mesh from UE4
	InstaLOD::IInstaLODMesh *const InstaInputMesh = AllocInstaLODMesh();
	InstaLOD::IInstaLODMesh *const InstaOutputMesh = AllocInstaLODMesh();

	// collect all skip sections
	TArray<uint32> SkipSections = UE4InstaLODSkeletalMeshHelper::GetSkipSectionsForLODModel(SourceLODModel, LODIndex);

	UE4InstaLODSkeletalMeshHelper::SkeletalLODModelToInstaLODMesh(*SourceLODModel, InstaInputMesh, SkipSections, &BakePoseData);

	const double T0 = FPlatformTime::Seconds();

	InstaLOD::OptimizeSettings OptimizeSettings = UE4InstaLODSkeletalMeshHelper::ConvertMeshReductionSettingsToInstaLOD(Settings, SkeletalMesh);

	// generate optimized insta mesh
	auto InstaResult = InstaLOD->Optimize(InstaInputMesh, InstaOutputMesh, OptimizeSettings);

	const double T1 = FPlatformTime::Seconds();
	const float ElapsedTime = (float)(T1-T0);

	if (InstaResult.Success)
	{
		// scale deviation per cvar
		InstaResult.MeshDeviation *= CVarDecimatedErrorFactor.GetValueOnAnyThread();

		IInstaLOD::UE4_MeshBuildOptions BuildOptions;
		BuildOptions.bRemoveDegenerateTriangles = false; /**< InstaLOD takes care of mesh healing */
		BuildOptions.bUseMikkTSpace = false;
		BuildOptions.bComputeNormals = false;
		BuildOptions.bComputeTangents = false;

		UE4InstaLODSkeletalMeshHelper::InstaLODMeshToSkeletalLODModel(InstaOutputMesh, SkeletalMesh, *OutputLODModel, BuildOptions);
		
		if (bOldLODWasFromFile)
		{
			SkeletalMesh->GetLODInfo(LODIndex)->LODMaterialMap.Empty();
		}
		else if (SkeletalMesh->GetLODInfo(LODIndex)->LODMaterialMap.Num() == 0 && SkeletalMesh->GetLODInfo(BaseLOD)->LODMaterialMap.Num() != 0)
		{
			SkeletalMesh->GetLODInfo(LODIndex)->LODMaterialMap = SkeletalMesh->GetLODInfo(BaseLOD)->LODMaterialMap;
		}

		SkeletalMesh->GetLODInfoArray()[LODIndex].bHasBeenSimplified = true;
		SkeletalMesh->bHasBeenSimplified = true;
		
		const int32 kInvalidSectionIndex = -1;
		TArray<FSkelMeshSection>& SourceSections = SourceLODModel->Sections;
		auto FindSourceSectionIndexWithMaterialID = [&SourceSections, kInvalidSectionIndex](uint32 MaterialIndex)-> int32
		{
			const uint32 SourceSectionCount = SourceSections.Num();
			for (uint32 Index=0; Index<SourceSectionCount; Index++)
			{
				if (SourceSections[Index].MaterialIndex == MaterialIndex)
					return (int32)Index;
			}

			return kInvalidSectionIndex;
		};

		// apply source section settings to sections of LOD
		for (FSkelMeshSection& NewSection : OutputLODModel->Sections)
		{
			const int32 SourceSectionIndex = FindSourceSectionIndexWithMaterialID(NewSection.MaterialIndex);
			if (SourceSectionIndex == kInvalidSectionIndex)
			{
				UE_LOG(LogInstaLOD, Warning, TEXT("Found invalid section material index in LOD %i"), LODIndex);
				continue;
			}

			check(SourceSectionIndex < SourceLODModel->Sections.Num());

			// copy settings to new section
			const FSkelMeshSection& SourceSection = SourceLODModel->Sections[SourceSectionIndex];
			NewSection.bCastShadow = SourceSection.bCastShadow;
			NewSection.bDisabled = SourceSection.bDisabled;
			NewSection.GenerateUpToLodIndex = SourceSection.GenerateUpToLodIndex;
			NewSection.bRecomputeTangent = SourceSection.bRecomputeTangent;
		}

		if (bCalcLODDistance)
		{
			if (LODIndex <= 0)
			{
				SkeletalMesh->GetLODInfoArray()[LODIndex].ScreenSize = 1.0f;
			}
			else
			{
				const float ToleranceFactor = 0.95f;
				const float MaxScreenSize = (LODIndex == 1 ? 1.0 : SkeletalMesh->GetLODInfoArray()[LODIndex - 1].ScreenSize.Default) * ToleranceFactor;
				const float MinScreenSize = MaxScreenSize * 0.5f;
				
				const float AutoLODError = 1.0f; /**< FIXME@Epic: this should be user configurable as with static meshes */
				const float ViewDistance = (InstaResult.MeshDeviation * 960.0f) / AutoLODError;
				// NOTE: 4.12+ has a changed API
				const float AutoScreenSize = 2.0f * SkeletalMesh->GetBounds().SphereRadius / ViewDistance;
				SkeletalMesh->GetLODInfoArray()[LODIndex].ScreenSize = FPerPlatformFloat(FMath::Clamp(AutoScreenSize, MinScreenSize, MaxScreenSize));
			}
		}

		if (CVarWriteOBJ.GetValueOnAnyThread().Len() > 0)
		{
			FText NotificationText;
			if (InstaOutputMesh->WriteLightwaveOBJ(TCHAR_TO_UTF8(*CVarWriteOBJ.GetValueOnAnyThread())))
			{
				NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Wrote Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
				DispatchNotification(NotificationText, SNotificationItem::CS_Success);
			}
			else
			{
				NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Failed to write Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
				DispatchNotification(NotificationText, SNotificationItem::CS_Fail);
			}
			UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
		}

		if(!bIsNewLODIndexForModel)
		{
			FSkeletalMeshLODModel& ImportedModelLOD = SkeletalMesh->GetImportedModel()->LODModels[LODIndex];
			ImportedModelLOD.UserSectionsData = PreviousUserSectionsData;
			ImportedModelLOD.BuildStringID = PreviousLODModelBuildStringID;
		}
	}
	else
	{
		// reduction failed, copy source mesh data
		FSkeletalMeshLODModel::CopyStructure(OutputLODModel, SourceLODModel);
		
		// we will recalculate required bones
		SkeletalMeshResource->LODModels[LODIndex].RequiredBones.Empty();

		SkeletalMesh->GetLODInfoArray()[LODIndex].bHasBeenSimplified = false;
	}

	// use bone reduction interface to apply bone reduction settings
	TMap<FBoneIndexType, FBoneIndexType> BonesToRemove;

	// NOTE: InstaLOD SDK2.0 ships with Skeleton Optimization that offers sophisticated
	// features to optimize skeletons based on leaf bones, or maximum bone depth.
	// However, here we are making use of UE4's built-in mesh bone reduction, which is
	// integrated into the UI.

	// NOTE: 4.10 on MacOS is missing the MeshBoneReduction module
	IMeshBoneReductionModule *const MeshBoneReductionModule = FModuleManager::Get().LoadModulePtr<IMeshBoneReductionModule>("MeshBoneReduction");
	if (MeshBoneReductionModule != NULL)
	{
		IMeshBoneReduction *const MeshBoneReductionInterface = MeshBoneReductionModule->GetMeshBoneReductionInterface();

		// NOTE: 4.11+ has new API
		if (MeshBoneReductionInterface->GetBoneReductionData(SkeletalMesh, LODIndex, BonesToRemove, NULL))
		{
			for (FSkelMeshSection& Section : OutputLODModel->Sections)
			{
				TMap<FName, FImportedSkinWeightProfileData>& SkinWeightProfiles = OutputLODModel->SkinWeightProfiles;
				MeshBoneReductionInterface->FixUpSectionBoneMaps(Section, BonesToRemove, SkinWeightProfiles);
			}
		}
	}

	SkeletalMesh->CalculateRequiredBones(*OutputLODModel, SkeletalMesh->RefSkeleton, &BonesToRemove);

	// only delete the model if it is not the imported source mesh
	if (!bReducingOriginalSourceModel && OldSourceLODModel != nullptr)
	{
		// make sure parallel processing doesn't corrupt bulk data
		if (Settings.OnDeleteLODModelDelegate.IsBound())
		{
			Settings.OnDeleteLODModelDelegate.Execute(OldSourceLODModel);
		}
		else
		{
			check(IsInGameThread());
			delete OldSourceLODModel;
		}
	}

	InstaLOD->DeallocMesh(InstaInputMesh);
	InstaLOD->DeallocMesh(InstaOutputMesh);

	// make sure usersections info is set
	OutputLODModel->SyncronizeUserSectionsDataArray();

	// rebind cloth data
	if (!bIsNewLODIndexForModel)
	{
		UE4InstaLODSkeletalMeshHelper::BindClothAtLODIndex(SkeletalMesh, ClothBindings, LODIndex);
	}

	PostProcessReducedSkeletalMesh(SkeletalMesh, *OutputLODModel, InstaResult.MeshDeviation, Settings, ElapsedTime);
}

void FInstaLOD::PostProcessReducedSkeletalMesh(USkeletalMesh* SkeletalMesh, UE4_StaticLODModel& OutputLODModel, float& OutMaxDeviation,
											   const FSkeletalMeshOptimizationSettings& Settings, const float ElapsedTime)
{
	// NOTE: the max deviation has been scaled for auto LOD calculation, but we want to display the actual deviation
	const float displayMaxDeviation = OutMaxDeviation / CVarDecimatedErrorFactor.GetValueOnAnyThread();
	
	FText DetailText = FText::FromString(FString::Printf(TEXT("in %.2fs with %.3f mesh deviation"), ElapsedTime, displayMaxDeviation));
	FText NotificationText = FText::Format(LOCTEXT("LODPluginOptimizeComplete", "Built LOD {0}"), DetailText);
	
	UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
}

void FInstaLOD::ReduceRawMesh(const FRawMesh& SourceRawMesh, FRawMesh& OutputMesh, float& OutMaxDeviation, const FMeshReductionSettings& Settings)
{
	UE_LOG(LogInstaLOD, Log, TEXT("Optimizing static mesh"));
	
	if (IsRunningCommandlet() && !InstaLOD->IsHostAuthorized())
	{
		UE_LOG(LogInstaLOD, Fatal, TEXT("This machine is not authorized to run InstaLOD. Please authorize this machine before cooking using the editor or InstaLOD Pipeline."));
	}
	
	InstaLOD::OptimizeSettings OptimizeSettings = UE4InstaLODMeshHelper::ConvertMeshReductionSettingsToInstaLOD(Settings);
	
	// create our insta meshes and feed data into it from UE4's rawmesh
	InstaLOD::IInstaLODMesh *InstaInputMesh = AllocInstaLODMesh();
	InstaLOD::IInstaLODMesh *InstaOutputMesh = AllocInstaLODMesh();
	UE4InstaLODMeshHelper::RawMeshToInstaLODMesh(SourceRawMesh, InstaInputMesh);
	
	// convert vertex colors to optimizer vertex weights if we've got color data
	if (OptimizeSettings.OptimizerVertexWeights)
	{
		if (!InstaInputMesh->ConvertColorDataToOptimizerWeights(0))
		{
			UE_LOG(LogInstaLOD, Log, TEXT("Failed to convert color data to optimizer weights. Is color data available for mesh?"));
		}
	}
	
	const double T0 = FPlatformTime::Seconds();
	
	// generate optimized insta mesh
	auto InstaResult = InstaLOD->Optimize(InstaInputMesh, InstaOutputMesh, OptimizeSettings);
	
	const double T1 = FPlatformTime::Seconds();
	const float ElapsedTime = (float)(T1-T0);
	
	if (InstaResult.Success)
	{
		// scale deviation per cvar
		InstaResult.MeshDeviation *= CVarDecimatedErrorFactor.GetValueOnAnyThread();
		OutMaxDeviation = InstaResult.MeshDeviation;
		// feed result back into UE4 output rawmesh
		UE4InstaLODMeshHelper::InstaLODMeshToRawMesh(InstaOutputMesh, OutputMesh);
	}
	else
	{
		char InstaLog[8192];
		InstaLOD->GetMessageLog(InstaLog, sizeof(InstaLog), NULL);
		UE_LOG(LogInstaLOD, Error, TEXT("Optimization failed. Log: %s"), UTF8_TO_TCHAR(InstaLog));
		OutMaxDeviation = 0;
		// restore input mesh
		UE4InstaLODMeshHelper::InstaLODMeshToRawMesh(InstaInputMesh, OutputMesh);
	}
	
	if (CVarWriteOBJ.GetValueOnAnyThread().Len() > 0)
	{
		FText NotificationText;
		if (InstaOutputMesh->WriteLightwaveOBJ(TCHAR_TO_UTF8(*CVarWriteOBJ.GetValueOnAnyThread())))
		{
			NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Wrote Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
			DispatchNotification(NotificationText, SNotificationItem::CS_Success);
		}
		else
		{
			NotificationText = FText::Format(LOCTEXT("LODPluginWriteOBJSuccess", "Failed to write Lightwave OBJ to \"{0}\""), FText::FromString(CVarWriteOBJ.GetValueOnAnyThread()));
			DispatchNotification(NotificationText, SNotificationItem::CS_Fail);
		}
		UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
	}
	
	// dealloc both temp meshes
	InstaLOD->DeallocMesh(InstaInputMesh);
	InstaLOD->DeallocMesh(InstaOutputMesh);
	
	// finalize
	PostProcessReducedRawMesh(SourceRawMesh, OutputMesh, OutMaxDeviation, Settings, ElapsedTime);
	
	if (CVarDeviationBasedScreenSize.GetValueOnAnyThread() == 0)
	{
		// disable deviation based Auto LOD
		OutMaxDeviation = -1.0f;
	}
}

void FInstaLOD::PostProcessReducedRawMesh(const FRawMesh& SourceRawMesh, FRawMesh& OutputMesh, float& OutMaxDeviation, const FMeshReductionSettings& Settings, const float ElapsedTime)
{
	// NOTE: the max deviation has been scaled for auto LOD calculation, but we want to display the actual deviation
	const float DisplayMaxDeviation = OutMaxDeviation / CVarDecimatedErrorFactor.GetValueOnAnyThread();
	
	FText DetailText = FText::FromString(FString::Printf(TEXT("in %.2fs with %.3f mesh deviation"), ElapsedTime, DisplayMaxDeviation));
	FText NotificationText = FText::Format(LOCTEXT("LODPluginOptimizeComplete", "Built LOD {0}"), DetailText);
	
	UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
}

static const char *const kInstaLODPageNameDiffuse = "UE4_Diffuse";
static const char *const kInstaLODPageNameNormal = "UE4_Normal";
static const char *const kInstaLODPageNameRoughness = "UE4_Roughness";
static const char *const kInstaLODPageNameSpecular = "UE4_Specular";
static const char *const kInstaLODPageNameMetallic = "UE4_Metallic";
static const char *const kInstaLODPageNameEmissive = "UE4_Emissive";
static const char *const kInstaLODPageNameOpacity = "UE4_Opacity";
static const char *const kInstaLODPageNameOpacityMask = "UE4_OpacityMask";
static const char *const kInstaLODPageNameSubSurface = "UE4_SubSurface";
static const char *const kInstaLODPageNameAmbientOcclusion = "UE4_AmbientOcclusion";

static const char *const kInstaLODPageInternalNameNormalTangentSpace = "NormalTangentSpace";
static const char *const kInstaLODPageInternalNameOpacity = "Opacity";
static const char *const kInstaLODPageInternalNameAmbientOcclusion = "AmbientOcclusion";


namespace InstaLOD
{
	struct InstaColorRGB16
	{
		uint16 R, G, B;
	};
	struct InstaColorRGBA8
	{
		uint8 R, G, B, A;
	};
	struct InstaColorR8L
	{
		uint8 L;
	};
}

class UE4InstaLODMaterialHelper
{
public:
	static void CopyColorArrayAny(TArray<FColor>& PixelData, InstaLOD::IInstaLODTexturePage* InstaLODTexturePage)
	{
		check(InstaLODTexturePage);
		
		// NOTE: try to use the fast path if possible
		if (InstaLODTexturePage->GetComponentType() == InstaLOD::IInstaLODTexturePage::ComponentTypeUInt8 &&
			InstaLODTexturePage->GetPixelType() == InstaLOD::IInstaLODTexturePage::PixelTypeRGBA)
		{
			CopyColorArray8(PixelData, InstaLODTexturePage->GetData(nullptr), InstaLODTexturePage->GetWidth()*InstaLODTexturePage->GetHeight());
			return;
		}
		
		// NOTE: texture data always needs to be 8bpp RGBA
		const uint32 Width = InstaLODTexturePage->GetWidth();
		const uint32 Height = InstaLODTexturePage->GetHeight();
		
		PixelData.SetNumUninitialized(InstaLODTexturePage->GetWidth() * InstaLODTexturePage->GetHeight());
		
		FColor *OutData = PixelData.GetData();
		
		for (uint32 Y=0; Y<Height; Y++)
		{
			for(uint32 X=0; X<Width; X++)
			{
				const InstaLOD::InstaColorRGBAF32 Color = InstaLODTexturePage->SampleFloat(X, Y);
				*OutData++ = FLinearColor(Color.R, Color.G, Color.B, Color.A).ToFColor(false);
			}
		}
		
	}
	
	static void CopyColorArray16(TArray<FColor>& OutData, const InstaLOD::uint8* InstaLODTexturePageData, size_t NumElems)
	{
		// NOTE: UE4 texture pages are always uint8, RGBA
		const InstaLOD::InstaColorRGB16 *InData = (InstaLOD::InstaColorRGB16*)InstaLODTexturePageData;
		OutData.SetNumUninitialized(NumElems);
		
		for(size_t i=0; i<NumElems; i++)
		{
			OutData[i].R = FMath::Clamp((uint32)InData[i].R * 255u / 65535u, 0u, 255u);
			OutData[i].G = FMath::Clamp((uint32)InData[i].G * 255u / 65535u, 0u, 255u);
			OutData[i].B = FMath::Clamp((uint32)InData[i].B * 255u / 65535u, 0u, 255u);
			OutData[i].A = 255;
		}
	}
	
	static void CopyColorArray8L(TArray<FColor>& OutData, const InstaLOD::uint8* InstaLODTexturePageData, size_t NumElems)
	{
		// NOTE: UE4 texture pages are always uint8, RGBA
		const InstaLOD::InstaColorR8L *InData = (InstaLOD::InstaColorR8L*)InstaLODTexturePageData;
		OutData.SetNumUninitialized(NumElems);
		
		for(size_t i=0; i<NumElems; i++)
		{
			OutData[i].R = InData[i].L;
			OutData[i].G = InData[i].L;
			OutData[i].B = InData[i].L;
			OutData[i].A = InData[i].L;
		}
	}
	
	static void CopyColorArray8(TArray<FColor>& OutData, const InstaLOD::uint8* InstaLODTexturePageData, size_t NumElems)
	{
		// NOTE: UE4 texture pages are always uint8, RGBA
		const InstaLOD::InstaColorRGBA8 *InData = (InstaLOD::InstaColorRGBA8*)InstaLODTexturePageData;
		OutData.SetNumUninitialized(NumElems);
		
		for(size_t i=0; i<NumElems; i++)
		{
			OutData[i].R = InData[i].R;
			OutData[i].G = InData[i].G;
			OutData[i].B = InData[i].B;
			OutData[i].A = InData[i].A;
		}
	}
	
	static void CopyColorArray(InstaLOD::uint8* OutInstaLODTexturePageData, const TArray<FColor>& InData)
	{
		const size_t NumElems = InData.Num();
		// NOTE: UE4 texture pages are always uint8, RGBA
		InstaLOD::InstaColorRGBA8* OutData = (InstaLOD::InstaColorRGBA8*) OutInstaLODTexturePageData;
		
		for(size_t i=0; i<NumElems; i++)
		{
			OutData[i].R = InData[i].R;
			OutData[i].G = InData[i].G;
			OutData[i].B = InData[i].B;
			OutData[i].A = InData[i].A;
		}
	}
	
	static void SetColorArrayToConstant(TArray<FColor>& OutData, const FColor& Value)
	{
		OutData.SetNum(1);
		
		const size_t NumElems = OutData.Num();
		
		for(size_t i=0; i<NumElems; i++)
		{
			OutData[i] = Value;
		}
	}
	
#	define GetFFlattenMaterialPageSize(MATERIAL, PAGENAME) (MATERIAL).GetPropertySize( EFlattenMaterialProperties :: PAGENAME)
#	define SetFFlattenMaterialPageSize(MATERIAL, PAGENAME, VALUE) (MATERIAL).SetPropertySize( EFlattenMaterialProperties :: PAGENAME, (VALUE))
#	define GetFFlattenMaterialPageData(MATERIAL, PAGENAME) (MATERIAL).GetPropertySamples( EFlattenMaterialProperties :: PAGENAME)
		
	static void ConvertInstaLODMaterialToFlattenMaterial(InstaLOD::IInstaLODMaterial *const InstaMaterial, FFlattenMaterial &OutMaterial, const IInstaLOD::UE4_MaterialProxySettings& settings)
	{
		uint32 pageWidth, pageHeight;
		OutMaterial = FMaterialUtilities::CreateFlattenMaterialWithSettings(settings);
		FColor DefaultColor(255, 255, 255, 255);
		FColor DefaultNormalColor(127, 127, 127, 255);
		
		InstaLOD::IInstaLODTexturePage *texturePage;
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameDiffuse);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Diffuse, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Diffuse), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			SetColorArrayToConstant(GetFFlattenMaterialPageData(OutMaterial, Diffuse), DefaultColor);
		}
		
		// NOTE: check if a built-in normal map sampler is available
		if (InstaMaterial != NULL && InstaMaterial->GetTexturePage(kInstaLODPageInternalNameNormalTangentSpace))
		{
			texturePage = InstaMaterial->GetTexturePage(kInstaLODPageInternalNameNormalTangentSpace);
			
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Normal, FIntPoint(pageWidth, pageHeight));
			CopyColorArray16(GetFFlattenMaterialPageData(OutMaterial, Normal), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameNormal);
			if (texturePage != NULL && texturePage->IsValid())
			{
				texturePage->GetSize(&pageWidth, &pageHeight);
				SetFFlattenMaterialPageSize(OutMaterial, Normal, FIntPoint(pageWidth, pageHeight));
				CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Normal), texturePage->GetData(NULL), pageWidth*pageHeight);
			}
			else
			{
				SetFFlattenMaterialPageSize(OutMaterial, Normal, FIntPoint(1,1));
				SetColorArrayToConstant(GetFFlattenMaterialPageData(OutMaterial, Normal), DefaultNormalColor);
			}
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameRoughness);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Roughness, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Roughness), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			FLinearColor Roughness(settings.RoughnessConstant, settings.RoughnessConstant, settings.RoughnessConstant);
			SetFFlattenMaterialPageSize(OutMaterial, Roughness, FIntPoint(1,1));
			SetColorArrayToConstant(GetFFlattenMaterialPageData(OutMaterial, Roughness), Roughness.ToFColor(true));
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameMetallic);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Metallic, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Metallic), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			FLinearColor Metallic(settings.MetallicConstant, settings.MetallicConstant, settings.MetallicConstant);
			SetFFlattenMaterialPageSize(OutMaterial, Metallic, FIntPoint(1,1));
			SetColorArrayToConstant(GetFFlattenMaterialPageData(OutMaterial, Metallic), Metallic.ToFColor(true));
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameSpecular);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Specular, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Specular), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			FLinearColor Specular(settings.SpecularConstant, settings.SpecularConstant, settings.SpecularConstant);
			SetFFlattenMaterialPageSize(OutMaterial, Specular, FIntPoint(1,1));
			SetColorArrayToConstant(GetFFlattenMaterialPageData(OutMaterial, Specular), Specular.ToFColor(true));
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameEmissive);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Emissive, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Emissive), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameOpacity);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, Opacity, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, Opacity), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameSubSurface);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, SubSurface, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, SubSurface), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		
		// NOTE: the internally generated opacity map is more important!
		{
			// convert internal opacity texture (8bpp luminance)
			texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageInternalNameOpacity);
			if (texturePage != NULL && texturePage->IsValid())
			{
				texturePage->GetSize(&pageWidth, &pageHeight);
				SetFFlattenMaterialPageSize(OutMaterial, OpacityMask, FIntPoint(pageWidth, pageHeight));
				CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, OpacityMask), texturePage->GetData(NULL), pageWidth*pageHeight);
			}
			else
			{
				texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameOpacityMask);
				if (texturePage != NULL && texturePage->IsValid())
				{
					texturePage->GetSize(&pageWidth, &pageHeight);
					SetFFlattenMaterialPageSize(OutMaterial, OpacityMask, FIntPoint(pageWidth, pageHeight));
					CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, OpacityMask), texturePage->GetData(NULL), pageWidth*pageHeight);
				}
			}
		}
		
		texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageNameAmbientOcclusion);
		if (texturePage != NULL && texturePage->IsValid())
		{
			texturePage->GetSize(&pageWidth, &pageHeight);
			SetFFlattenMaterialPageSize(OutMaterial, AmbientOcclusion, FIntPoint(pageWidth, pageHeight));
			CopyColorArray8(GetFFlattenMaterialPageData(OutMaterial, AmbientOcclusion), texturePage->GetData(NULL), pageWidth*pageHeight);
		}
		else
		{
			// convert internal ambient occlusion texture (8bpp luminance)
			texturePage = InstaMaterial == NULL ? NULL : InstaMaterial->GetTexturePage(kInstaLODPageInternalNameAmbientOcclusion);
			if (texturePage != NULL && texturePage->IsValid())
			{
				SetFFlattenMaterialPageSize(OutMaterial, AmbientOcclusion, FIntPoint(texturePage->GetWidth(), texturePage->GetHeight()));
				CopyColorArrayAny(GetFFlattenMaterialPageData(OutMaterial, AmbientOcclusion), texturePage);
			}
		}
	}
	
	static void ConvertFlattenMaterialPageToInstaTexturePage(const TArray<FColor>& InData, const FIntPoint& InSize, const char* const InName,
															  InstaLOD::IInstaLODMaterialData *const MaterialData, InstaLOD::IInstaLODMaterial *const OutInstaMaterial)
	{
		// do not create empty pages
		if (InData.Num() == 0)
		{
			return;
		}
		
		const InstaLOD::IInstaLODTexturePage::ComponentType ComponentType = InstaLOD::IInstaLODTexturePage::ComponentTypeUInt8;
		const InstaLOD::IInstaLODTexturePage::PixelType PixelType = InstaLOD::IInstaLODTexturePage::PixelTypeRGBA;
		InstaLOD::IInstaLODTexturePage::Type TexturePageType = InstaLOD::IInstaLODTexturePage::TypeColor;
		
		// NOTE: we transfer all texture pages as simple color texture pages, the only exception being tangnetspace normal maps
		if (InName == kInstaLODPageNameNormal)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeNormalMapTangentSpace;
		else if (InName == kInstaLODPageNameOpacityMask || InName == kInstaLODPageNameOpacity)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeOpacity;
		else if (InName == kInstaLODPageNameAmbientOcclusion)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeAmbientOcclusion;
		else if (InName == kInstaLODPageNameRoughness)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeRoughness;
		else if (InName == kInstaLODPageNameMetallic)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeMetalness;
		else if (InName == kInstaLODPageNameSpecular)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeSpecular;
		else if (InName == kInstaLODPageNameEmissive)
			TexturePageType = InstaLOD::IInstaLODTexturePage::TypeEmissive;
		
		InstaLOD::IInstaLODTexturePage *const TexturePage = OutInstaMaterial->AddTexturePage(InName, TexturePageType, ComponentType, PixelType);
		TexturePage->Reallocate(InSize.X, InSize.Y);
		CopyColorArray(TexturePage->GetData(NULL), InData);
		
		if (TexturePageType == InstaLOD::IInstaLODTexturePage::TypeOpacity)
		{
			// ensure alpha values are setup
			const uint32 ElementCount = InSize.X * InSize.Y;
			
			InstaLOD::InstaColorRGBA8* OutData = (InstaLOD::InstaColorRGBA8*)TexturePage->GetData(nullptr);
			for(uint32 ElementIndex=0; ElementIndex<ElementCount; ElementIndex++)
			{
				OutData->A = OutData->R;
				OutData++;
			}
			
			OutInstaMaterial->SetUseTexturePageAsAlphaMask(TexturePage);
		}
		
		// enable writing of all texture page matching the specified name and it's exact specification
		MaterialData->EnableOutputForTexturePage(InName, TexturePageType, ComponentType, PixelType);
	}
	
	static void ConvertFlattenMaterialToInstaMaterial(const FFlattenMaterial& InMaterial, InstaLOD::IInstaLODMaterialData *const MaterialData, InstaLOD::IInstaLODMaterial *const OutInstaMaterial)
	{
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Diffuse), GetFFlattenMaterialPageSize(InMaterial, Diffuse), kInstaLODPageNameDiffuse, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Normal), GetFFlattenMaterialPageSize(InMaterial, Normal), kInstaLODPageNameNormal, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Roughness), GetFFlattenMaterialPageSize(InMaterial, Roughness), kInstaLODPageNameRoughness, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Metallic), GetFFlattenMaterialPageSize(InMaterial, Metallic), kInstaLODPageNameMetallic, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Specular), GetFFlattenMaterialPageSize(InMaterial, Specular), kInstaLODPageNameSpecular, MaterialData, OutInstaMaterial);

		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Emissive), GetFFlattenMaterialPageSize(InMaterial, Emissive), kInstaLODPageNameEmissive, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, Opacity), GetFFlattenMaterialPageSize(InMaterial, Opacity), kInstaLODPageNameOpacity, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, SubSurface), GetFFlattenMaterialPageSize(InMaterial, SubSurface), kInstaLODPageNameSubSurface, MaterialData, OutInstaMaterial);

		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, OpacityMask), GetFFlattenMaterialPageSize(InMaterial, OpacityMask), kInstaLODPageNameOpacityMask, MaterialData, OutInstaMaterial);
		ConvertFlattenMaterialPageToInstaTexturePage(GetFFlattenMaterialPageData(InMaterial, AmbientOcclusion), GetFFlattenMaterialPageSize(InMaterial, AmbientOcclusion), kInstaLODPageNameAmbientOcclusion, MaterialData, OutInstaMaterial);

	}
};

struct UE4ProxyWrapper
{
	UE4ProxyWrapper(InstaLOD::IInstaLOD* InInstaLOD, const bool InIsMergeOperation) :
	InstaLOD(InInstaLOD),
	InstaMaterial(NULL),
	MergeOperation(NULL),
	RemeshOperation(NULL)
	{
		check(InInstaLOD);
		
		if (InIsMergeOperation)
			MergeOperation = InstaLOD->AllocMeshMergeOperation();
		else
			RemeshOperation = InstaLOD->AllocRemeshingOperation();
	}
	
	~UE4ProxyWrapper()
	{
		Dealloc();
	}
	
	void Dealloc()
	{
		if (MergeOperation)
		{
			InstaLOD->DeallocMeshMergeOperation(MergeOperation);
			MergeOperation = NULL;
		}
		if (RemeshOperation)
		{
			InstaLOD->DeallocRemeshingOperation(RemeshOperation);
			RemeshOperation = NULL;
		}
		
		InstaMaterial = NULL;
		InstaLOD = NULL;
	}
	
	void AddMesh(InstaLOD::IInstaLODMesh *InstaMesh)
	{
		check(InstaMesh);
		check(InstaLOD);
		
		if (MergeOperation)
			MergeOperation->AddMesh(InstaMesh);
		else
			RemeshOperation->AddMesh(InstaMesh);
	}
	
	void SetMaterialData(InstaLOD::IInstaLODMaterialData *MaterialData)
	{
		check(MaterialData);
		check(InstaLOD);
		
		if (MergeOperation)
			MergeOperation->SetMaterialData(MaterialData);
		else
			RemeshOperation->SetMaterialData(MaterialData);
	}
	
	bool Execute(InstaLOD::IInstaLODMesh *OutputMesh, const struct FMeshProxySettings& InProxySettings)
	{
		check(InstaLOD);
		
#if defined(__APPLE__)
		return false;
#endif

		InstaMaterial = NULL;
		
		if (MergeOperation != NULL)
		{
			InstaLOD::MeshMergeSettings MeshMergeSettings;
			MeshMergeSettings.SolidifyTexturePages = true;
			// NOTE: we super sample at 2x for UE4 by default. Unfortunately UE4 does not provide an API for this yet
			MeshMergeSettings.SuperSampling = InstaLOD::SuperSampling::X2;
			MeshMergeSettings.GutterSizeInPixels = 2;
			MeshMergeSettings.StackDuplicateShells = true;
			
			InstaLOD::MeshMergeResult MergeResult = MergeOperation->Execute(OutputMesh, MeshMergeSettings);
			
			if (!MergeResult.Success)
				return false;
			
			// also optimize with InstaLOD
			if (CVarHLODScreenSizeFactor.GetValueOnAnyThread() > 0.0f)
			{
				InstaLOD::OptimizeSettings OptimizeSettings = UE4InstaLODMeshHelper::ConvertMeshReductionSettingsToInstaLOD(FMeshReductionSettings());
				OptimizeSettings.ScreenSizeInPixels = InProxySettings.ScreenSize * CVarHLODScreenSizeFactor.GetValueOnAnyThread();
				OptimizeSettings.RecalculateNormals = InProxySettings.bRecalculateNormals;
				OptimizeSettings.HardAngleThreshold = InProxySettings.HardAngleThreshold;
				
				// NOTE: as we're only optimizing a single mesh, we're using the shortcut API
				// if you're optimizing multiple objects and need progress information use IInstaLOD::AllocOptimizeOperation
				InstaLOD::OptimizeResult OptimizeResult = InstaLOD->Optimize(OutputMesh, OutputMesh, OptimizeSettings);
				if (OptimizeResult.Success == false)
				{
					return false;
				}
			}
			
			InstaMaterial = MergeResult.MergeMaterial;
			return true;
		}
		else
		{
			InstaLOD::RemeshingSettings RemeshSettings;
			RemeshSettings.ScreenSizeInPixels = InProxySettings.ScreenSize;
			RemeshSettings.HardAngleThreshold = InProxySettings.HardAngleThreshold;
			RemeshSettings.BakeOutput.TangentSpaceFormat = InstaLOD::MeshFormat::DirectX;
			RemeshSettings.BakeOutput.SuperSampling = InstaLOD::SuperSampling::X2;
			RemeshSettings.BakeAutomaticRayLengthFactor = 1.5f;
			RemeshSettings.ScreenSizePixelMergeDistance = InProxySettings.MergeDistance;
			
			// NOTE: disable 'SurfaceConstructionIgnoreBackface' to switch to standard remeshing
			// behavior where non-watertight meshes will result in a mesh with interior/backface
			// geometry
			// enabling 'SurfaceConstructionIgnoreBackface' will instruct InstaLOD to construct
			// a surface without interior faces even for non-watertight meshes - however
			// if the surface contains flipped faces the resulting mesh may contain holes.
			RemeshSettings.SurfaceConstructionIgnoreBackface = true;
			RemeshSettings.ScreenSizeInPixelsAutomaticTextureSize = InProxySettings.MaterialSettings.TextureSizingType == TextureSizingType_UseSimplygonAutomaticSizing;
			
			
			InstaLOD::RemeshingResult RemeshResult = RemeshOperation->Execute(OutputMesh, RemeshSettings);
			if (RemeshResult.Success == false)
			{
				return false;
			}
			
			InstaMaterial = RemeshResult.BakeMaterial;
			return true;
		}
	}
	InstaLOD::IInstaLOD *InstaLOD;
	InstaLOD::IInstaLODMaterial* InstaMaterial;
	InstaLOD::IMeshMergeOperation2 *MergeOperation;
	InstaLOD::IRemeshingOperation *RemeshOperation;
};


InstaLOD::IInstaLODMesh* FInstaLOD::AllocInstaLODMesh()
{
	InstaLOD::IInstaLODMesh *const Mesh = InstaLOD->AllocMesh();
	if (Mesh == nullptr)
		return nullptr;
	
	Mesh->SetFrontFaceWindingOrder(InstaLOD::IInstaLODMesh::WindingOrderClockwise);
	Mesh->SetMeshFormatType(InstaLOD::MeshFormat::DirectX);
	return Mesh;
}

InstaLOD::IInstaLODSkeleton* FInstaLOD::AllocInstaLODSkeleton()
{
	InstaLOD::IInstaLODSkeleton *const Skeleton = InstaLOD->AllocSkeleton();
	if (Skeleton == nullptr)
		return nullptr;

	return Skeleton;
}
bool FInstaLOD::ConvertInstaLODMeshToRawMesh(InstaLOD::IInstaLODMesh* InMesh, struct FRawMesh &OutMesh)
{
	check(InMesh);
	UE4InstaLODMeshHelper::InstaLODMeshToRawMesh(InMesh, OutMesh);
	return true;
}

bool FInstaLOD::ConvertInstaLODMeshToMeshDescription(InstaLOD::IInstaLODMesh* InMesh, const TMap<int32, FName> &MaterialMapOut, struct FMeshDescription &OutMesh)
{
	check(InMesh);
	UE4InstaLODMeshHelper::InstaLODMeshToMeshDescription(InMesh, MaterialMapOut, OutMesh);
	return true;
}


bool FInstaLOD::ConvertRawMeshToInstaLODMesh(const struct FRawMesh &InMesh, InstaLOD::IInstaLODMesh* OutMesh)
{
	check(OutMesh);
	UE4InstaLODMeshHelper::RawMeshToInstaLODMesh(InMesh, OutMesh);
	return true;
}
 
bool FInstaLOD::ConvertMeshDescriptionToInstaLODMesh(const struct FMeshDescription &InMesh, InstaLOD::IInstaLODMesh* OutMesh)
{
	check(OutMesh);
	TMap <FName, int32> map;
	UE4InstaLODMeshHelper::MeshDescriptionToInstaLODMesh(InMesh, map, OutMesh);	
	return true;
}

bool FInstaLOD::ConvertSkeletalLODModelToInstaLODMesh(const UE4_StaticLODModel& InMesh, InstaLOD::IInstaLODMesh *const OutMesh, UE4_SkeletalBakePoseData *const BakePoseData)
{
	check(OutMesh);
	TArray<uint32> SkipSections = UE4InstaLODSkeletalMeshHelper::GetSkipSectionsForLODModel(static_cast<const FSkeletalMeshLODModel*>(&InMesh));
	UE4InstaLODSkeletalMeshHelper::SkeletalLODModelToInstaLODMesh(InMesh, OutMesh, SkipSections, BakePoseData);
	return true;
}

bool FInstaLOD::ConvertInstaLODMeshToSkeletalLODModel(InstaLOD::IInstaLODMesh *const InMesh, class USkeletalMesh* SourceSkeletalMesh, UE4_StaticLODModel& OutMesh)
{
	check(InMesh);
	check(SourceSkeletalMesh);
	
	IInstaLOD::UE4_MeshBuildOptions BuildOptions;
	BuildOptions.bRemoveDegenerateTriangles = false; /**< InstaLOD takes care of mesh healing */
	BuildOptions.bUseMikkTSpace = false;
	BuildOptions.bComputeNormals = false;
	BuildOptions.bComputeTangents = false;
	
	UE4InstaLODSkeletalMeshHelper::InstaLODMeshToSkeletalLODModel(InMesh, SourceSkeletalMesh, OutMesh, BuildOptions);
	return true;
}

bool FInstaLOD::ConvertFlattenMaterialsToInstaLODMaterialData(const TArray<FFlattenMaterial>& InputMaterials, InstaLOD::IInstaLODMaterialData* MaterialData, const IInstaLOD::UE4_MaterialProxySettings& MaterialSettings)
{
	check(MaterialData);
	
	// setup default size
	{
		FIntPoint TextureSize;
		TextureSize = MaterialSettings.TextureSize;
		MaterialData->SetDefaultOutputTextureSize(TextureSize.X, TextureSize.Y);
	}

	// setup texture page default colors
	{
		InstaLOD::InstaColorRGBAF32 kDefaultColorWhite;
		kDefaultColorWhite.R = kDefaultColorWhite.G = kDefaultColorWhite.B = kDefaultColorWhite.A = 1.0f;
		InstaLOD::InstaColorRGBAF32 kDefaultColorBlack;
		kDefaultColorBlack.R = kDefaultColorBlack.G = kDefaultColorBlack.B = 0.0f; kDefaultColorBlack.A = 1.0f;
		
		MaterialData->SetDefaultColorForTexturePage(kInstaLODPageNameOpacity, kDefaultColorWhite);
		MaterialData->SetDefaultColorForTexturePage(kInstaLODPageNameOpacityMask, kDefaultColorWhite);
		MaterialData->SetDefaultColorForTexturePage(kInstaLODPageNameAmbientOcclusion, kDefaultColorWhite);
		MaterialData->SetDefaultColorForTexturePage(kInstaLODPageNameEmissive, kDefaultColorBlack);
	}
	
	if (MaterialSettings.TextureSizingType == TextureSizingType_UseAutomaticBiasedSizes ||
		MaterialSettings.TextureSizingType == TextureSizingType_UseSimplygonAutomaticSizing)
	{
		int NormalSize = MaterialSettings.TextureSize.X;
		int DiffuseSize = FMath::Max(MaterialSettings.TextureSize.X >> 1, 32);
		int PropertiesSize = FMath::Max(MaterialSettings.TextureSize.X >> 2, 16);
		
		// NOTE: we can specify all page sizes here, it doesn't matter if they're not actually exported, InstaLOD will ignore it then
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameDiffuse, DiffuseSize, DiffuseSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameNormal, NormalSize, NormalSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameRoughness, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameMetallic, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameSpecular, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameEmissive, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameOpacity, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameOpacityMask, PropertiesSize, PropertiesSize);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameAmbientOcclusion, PropertiesSize, PropertiesSize);
		
		// NOTE: set internal sampler size
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageInternalNameNormalTangentSpace, NormalSize, NormalSize);
	}
	else if (MaterialSettings.TextureSizingType == TextureSizingType_UseManualOverrideTextureSize)
	{
		// NOTE: we can specify all page sizes here, it doesn't matter if they're not actually exported, InstaLOD will ignore it then
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameDiffuse, MaterialSettings.DiffuseTextureSize.X, MaterialSettings.DiffuseTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameNormal, MaterialSettings.NormalTextureSize.X, MaterialSettings.NormalTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameRoughness, MaterialSettings.RoughnessTextureSize.X, MaterialSettings.RoughnessTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameMetallic, MaterialSettings.MetallicTextureSize.X, MaterialSettings.MetallicTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameSpecular, MaterialSettings.SpecularTextureSize.X, MaterialSettings.SpecularTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameEmissive, MaterialSettings.EmissiveTextureSize.X, MaterialSettings.EmissiveTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameOpacity, MaterialSettings.OpacityTextureSize.X, MaterialSettings.OpacityTextureSize.Y);

		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameOpacityMask, MaterialSettings.OpacityMaskTextureSize.X, MaterialSettings.OpacityMaskTextureSize.Y);
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageNameAmbientOcclusion, MaterialSettings.AmbientOcclusionTextureSize.X, MaterialSettings.AmbientOcclusionTextureSize.Y);

		// NOTE: set internal sampler size
		MaterialData->SetOutputTextureSizeForPage(kInstaLODPageInternalNameNormalTangentSpace, MaterialSettings.NormalTextureSize.X, MaterialSettings.NormalTextureSize.Y);
	}	
	
	// NOTE: it's important that material IDs match those specified in the meshes
	for (int i=0; i<InputMaterials.Num(); i++)
	{
		FString MaterialName = FString::Printf(TEXT("INSTALOD_TEMP_MATERIAL_%i"), i);
		InstaLOD::IInstaLODMaterial *const InstaMaterial = MaterialData->AddMaterialWithID(TCHAR_TO_ANSI(*MaterialName), i);
		UE4InstaLODMaterialHelper::ConvertFlattenMaterialToInstaMaterial(InputMaterials[i], MaterialData, InstaMaterial);
	}
	
	return true;
}

bool FInstaLOD::ConvertInstaLODMaterialToFlattenMaterial(InstaLOD::IInstaLODMaterial* InMaterial, FFlattenMaterial &OutMaterial, const UE4_MaterialProxySettings& MaterialSettings)
{
	check(InMaterial)
	UE4InstaLODMaterialHelper::ConvertInstaLODMaterialToFlattenMaterial(InMaterial, OutMaterial, MaterialSettings);
	return true;
}

bool FInstaLOD::ConvertReferenceSkeletonToInstaLODSkeleton(const FReferenceSkeleton& ReferenceSkeleton, InstaLOD::IInstaLODSkeleton *const InstaSkeleton, TMap<int32, TPair<uint32, FString>>& OutUEBoneIndexToInstaLODBoneIndexAndName)
{
	return UE4InstaLODSkeletalMeshHelper::ReferenceSkeletonToInstaLODSkeleton(ReferenceSkeleton, InstaSkeleton, OutUEBoneIndexToInstaLODBoneIndexAndName);
}

void FInstaLOD::ProxyLOD(
	const TArray<struct FMeshMergeData>& InData, 
	const struct FMeshProxySettings& InProxySettings,
	const TArray<struct FFlattenMaterial>& InputMaterials, 
	const FGuid InJobGUID)
{
	UE_LOG(LogInstaLOD, Log, TEXT("Building Proxy"));
	
	if (IsRunningCommandlet() && !InstaLOD->IsHostAuthorized())
	{
		UE_LOG(LogInstaLOD, Fatal, TEXT("This machine is not authorized to run InstaLOD. Please authorize this machine before cooking using the editor or InstaLOD Pipeline."));
	}
	
#if defined(__APPLE__)
	UE_LOG(LogInstaLOD, Warning, TEXT("Proxy mesh temporarily not support on macOS due to removal of Unreal Engine core functionality."));
	return;
#endif

	const double T0 = FPlatformTime::Seconds();
	
	UE4ProxyWrapper InstaOperation(InstaLOD, CVarHLODRemesh.GetValueOnAnyThread() == 0 ? true : false);	
	
	// setup material data
	InstaLOD::IInstaLODMaterialData *const MaterialData = InstaLOD->AllocMaterialData();
	InstaOperation.SetMaterialData(MaterialData);

	IInstaLOD::UE4_MaterialProxySettings MaterialSettings;
	MaterialSettings = InProxySettings.MaterialSettings;
	
	ConvertFlattenMaterialsToInstaLODMaterialData(InputMaterials, MaterialData, MaterialSettings);
	
	TArray<InstaLOD::IInstaLODMesh*> SourceInstaMeshes;

	for(int i=0; i<InData.Num(); i++)
	{
		TMap<FName, int32> InMaterialMap;
		TMap<int32, FName> OutMaterialMap;

		UE4InstaLODMeshHelper::CreateInputOutputMaterialMapFromMeshDescription(*InData[i].RawMesh, InMaterialMap, OutMaterialMap);
		InstaLOD::IInstaLODMesh *const InstaMesh = AllocInstaLODMesh();		
		UE4InstaLODMeshHelper::MeshDescriptionToInstaLODMesh(*InData[i].RawMesh, InMaterialMap, InstaMesh);

		// replace custom UVs when vertex colors needed baking
		if (InData[i].NewUVs.Num() > 0)
		{
			InstaLOD::uint64 NumTexCoordElems;
			InstaLOD::InstaVec2F *OutTexcoords = InstaMesh->GetWedgeTexCoords(0, &NumTexCoordElems);
			
			if (NumTexCoordElems == InData[i].NewUVs.Num())
			{
				// we assume that these are for texcoord0
				UE4InstaLODMeshHelper::FillArray(OutTexcoords, InData[i].NewUVs.GetData(), NumTexCoordElems);
				UE4InstaLODMeshHelper::SanitizeFloatArray((float*)OutTexcoords, NumTexCoordElems * 2, 0.0f);
			}
		}
		InstaOperation.AddMesh(InstaMesh);
		SourceInstaMeshes.Add(InstaMesh);
	}
	
	// create output mesh
	InstaLOD::IInstaLODMesh *const OutputMesh = AllocInstaLODMesh();
	
	FMeshDescription OutProxyMesh;
	FStaticMeshAttributes(OutProxyMesh).Register();
	FFlattenMaterial OutMaterial; 

	// execute InstaLOD merge operation
	bool InstaOperationSuccess = InstaOperation.Execute(OutputMesh, InProxySettings);
	
	if (!InstaOperationSuccess)
	{
		char InstaLog[8192];
		InstaLOD->GetMessageLog(InstaLog, sizeof(InstaLog), NULL);
		UE_LOG(LogInstaLOD, Error, TEXT("Remeshing failed. Log: %s"), UTF8_TO_TCHAR(InstaLog));
	}
	else
	{
		// store merge mesh result in output FRawMesh 
		TMap<int32, FName> MaterialMap;
		ConvertInstaLODMeshToMeshDescription(OutputMesh, MaterialMap, OutProxyMesh);
		// store merge material result in output FFlattenMaterial
		ConvertInstaLODMaterialToFlattenMaterial(InstaOperation.InstaMaterial, OutMaterial, MaterialSettings);
	}
	
	const double T1 = FPlatformTime::Seconds();
	const float ElapsedTime = (float)(T1-T0);
	
	TMap<int32, FName> OutMaterialMap;
	OutMaterialMap.Add(0, FName(*FString::Printf(TEXT("MaterialSlot_%d"), 0)));

	PostProcessMergedRawMesh(OutProxyMesh, OutMaterial, InProxySettings, ElapsedTime);
		
	// free data
	for (int i=0; i<SourceInstaMeshes.Num(); i++)
	{
		InstaLOD->DeallocMesh(SourceInstaMeshes[i]);
	}
	InstaLOD->DeallocMesh(OutputMesh);
	InstaLOD->DeallocMaterialData(MaterialData);
	InstaOperation.Dealloc();
	
	CompleteDelegate.ExecuteIfBound(OutProxyMesh, OutMaterial, InJobGUID);
}

void FInstaLOD::PostProcessMergedRawMesh(FMeshDescription& OutProxyMesh, FFlattenMaterial& OutMaterial, const FMeshProxySettings& InProxySettings, const float ElapsedTime)
{
	IInstaLOD::UE4_MaterialProxySettings MaterialSettings;
	MaterialSettings = InProxySettings.MaterialSettings;
	
	// setup material constants
	auto MetallicSamples = GetFFlattenMaterialPageData(OutMaterial, Metallic);
	if (MetallicSamples.Num() == 0)
	{
		FLinearColor Metallic(MaterialSettings.MetallicConstant, MaterialSettings.MetallicConstant, MaterialSettings.MetallicConstant);
		SetFFlattenMaterialPageSize(OutMaterial, Metallic, FIntPoint(1,1));
		MetallicSamples.SetNum(1);
		MetallicSamples[0] = Metallic.ToFColor(true);
	}
	
	auto RoughnessSamples = GetFFlattenMaterialPageData(OutMaterial, Roughness);
	if (RoughnessSamples.Num() == 0)
	{
		FLinearColor Roughness(MaterialSettings.RoughnessConstant, MaterialSettings.RoughnessConstant, MaterialSettings.RoughnessConstant);
		SetFFlattenMaterialPageSize(OutMaterial, Roughness, FIntPoint(1,1));
		RoughnessSamples.SetNum(1);
		RoughnessSamples[0] = Roughness.ToFColor(true);
	}
	
	auto SpecularSamples = GetFFlattenMaterialPageData(OutMaterial, Specular);
	if (SpecularSamples.Num() == 0)
	{
		FLinearColor Specular(MaterialSettings.SpecularConstant, MaterialSettings.SpecularConstant, MaterialSettings.SpecularConstant);
		SetFFlattenMaterialPageSize(OutMaterial, Specular, FIntPoint(1,1));
		SpecularSamples.SetNum(1);
		SpecularSamples[0] = Specular.ToFColor(true);
	}
	
	FText DetailText = FText::FromString(FString::Printf(TEXT("in %.2fs"), ElapsedTime));
	FText NotificationText = FText::Format(LOCTEXT("LODPluginMergeComplete", "Built Proxy LOD {0}"), DetailText);
	
	UE_LOG(LogInstaLOD, Log, TEXT("%s"), *NotificationText.ToString());
}

void FInstaLOD::AggregateLOD()
{
}

void FInstaLOD::DispatchNotification(const FText& NotificationText, /*SNotificationItem::ECompletionState*/int32 type)
{
	if (GEditor == NULL)
		return;
	
	// send a visual notification to the user
	FNotificationInfo Info(NotificationText);
	Info.ExpireDuration = 4.0f;
	Info.bAllowThrottleWhenFrameRateIsLow = true;
	
	SNotificationItem::ECompletionState state = (SNotificationItem::ECompletionState)type;
	
	// NOTE: we will create a lambda that will dispatch the notification, else it will disappear immediately due to the huge timeout
	FTimerDelegate TimerDelegate;
	TimerDelegate.BindLambda([Info, state]() {
		TWeakPtr<SNotificationItem> Notification = FSlateNotificationManager::Get().AddNotification(Info);
		
		if (Notification.IsValid())
			Notification.Pin()->SetCompletionState(state);
		
	});
	GEditor->GetTimerManager()->SetTimerForNextTick(TimerDelegate);
}


#undef LOCTEXT_NAMESPACE
