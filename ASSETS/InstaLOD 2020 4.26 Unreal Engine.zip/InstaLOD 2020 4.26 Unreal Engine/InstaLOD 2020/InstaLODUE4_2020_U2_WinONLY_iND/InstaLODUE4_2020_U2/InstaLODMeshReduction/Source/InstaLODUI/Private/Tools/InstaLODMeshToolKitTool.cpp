/**
 * InstaLODUVTool.cpp (InstaLOD)
 *
 * Copyright 2016-2020 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODUVTool.cpp 
 * @copyright 2016-2020 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODMeshToolKitTool.h"
#include "InstaLODUIPCH.h"

#include "Utilities/InstaLODUtilities.h"
#include "Slate/InstaLODWindow.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"

UInstaLODMeshToolKitTool::UInstaLODMeshToolKitTool() : Super(),
Operation(nullptr),
OperationResult()
{
}

InstaLOD::MeshToolKitSettings UInstaLODMeshToolKitTool::GetMeshToolKitSettings()
{
	InstaLOD::MeshToolKitSettings settings;

	auto fnGetNormalHealingMode = [](const EInstaLODNormalHealing mode) -> InstaLOD::NormalHealingMode::Type
	{
		switch (mode)
		{
			case EInstaLODNormalHealing::InstaLOD_OFF :
				return InstaLOD::NormalHealingMode::Off;
			case EInstaLODNormalHealing::InstaLOD_Minimal:
				return InstaLOD::NormalHealingMode::Minimal;
			case EInstaLODNormalHealing::InstaLOD_Default:
				return InstaLOD::NormalHealingMode::Default;
		}
		return InstaLOD::NormalHealingMode::Off;
	};

	settings.WeldingThreshold = VertexWelding;
	settings.WeldingNormalAngleThreshold = VertexWeldingNormalAngle;
	settings.WeldingBoundaries = bWeldingBoundaries;
	settings.HealTJunctionThreshold = TJunctionHealing;
	settings.RemoveDegenerateFacesThreshold = RemoveDegenerateFaces;
	settings.FixNonManifold = bFixNonManifold;
	settings.ConformNormals = bConformNormals;
	settings.ConformWindingOrder = bConformWindingOrder;
	settings.FlipNormals = bFlipNormals;
	settings.FlipWindingOrder = bFlipWindingOrder;
	settings.FillHoles = bFillHoles;
	settings.NormalHealingMode = fnGetNormalHealingMode(NormalHealingMode);
	settings.RecalculateNormals = bRecalculateNormals;
	settings.HardAngleThreshold = HardangleThreshold;
	settings.WeightedNormals = bWeightedNormals;
	settings.MinimumSubMeshBoundingSphereRadius = MinimumRadius;
	settings.MinimumFaceArea = MinimumFaceArea;
	return settings;
}

void UInstaLODMeshToolKitTool::OnMeshOperationExecute(bool bIsAsynchronous)
{
	// --------------------------
	// can be run on child thread
	// --------------------------
	check(Operation == nullptr);

	InstaLOD::pfnMeshToolKitProgressCallback ProgressCallback = [](InstaLOD::IMeshToolKitOperation* MeshToolKitOperation, const InstaLOD::IInstaLODMesh* SourceMesh, InstaLOD::IInstaLODMesh* TargetMesh, const float ProgressInPercent)
	{
		if (!IsInGameThread())
		{
			AsyncTask(ENamedThreads::GameThread, [ProgressInPercent]() { GWarn->UpdateProgress(ProgressInPercent * 100, 100); });
		}
		else
		{
			GWarn->UpdateProgress(ProgressInPercent * 100, 100);
		}
	};
	
	// alloc mesh operation
	Operation = GetInstaLODInterface()->GetInstaLOD()->AllocMeshToolKitOperation();
	Operation->SetProgressCallback(ProgressCallback); 

	// execute
	OperationResult = Operation->Execute(InputMesh, OutputMesh, GetMeshToolKitSettings());
}

void UInstaLODMeshToolKitTool::ResetSettings()
{
	VertexWelding = 0.0f;
	VertexWeldingNormalAngle = 80.0f;
	TJunctionHealing = 0.0f;
	RemoveDegenerateFaces = 0.0f;
	bFixNonManifold = false;
	bConformNormals = false;
	bConformWindingOrder = false;
	bFlipNormals = false;
	bFlipWindingOrder = false;
	bFillHoles = false;
	NormalHealingMode = EInstaLODNormalHealing::InstaLOD_OFF;
	bRecalculateNormals = false;
	HardangleThreshold = 80.0f;
	bWeightedNormals = true;
	MinimumRadius = 0.0f;
	MinimumFaceArea = 0.0f;
}

void UInstaLODMeshToolKitTool::DeallocMeshOperation() 
{
	if (Operation != nullptr)
	{
		GetInstaLODInterface()->GetInstaLOD()->DeallocMeshToolKitOperation(Operation);
		Operation = nullptr;
	}
}

bool UInstaLODMeshToolKitTool::IsMeshOperationSuccessful() const
{
	return Operation != nullptr && OperationResult.Success;
};

FText UInstaLODMeshToolKitTool::GetFriendlyName() const
{
	return NSLOCTEXT("InstaLODUI", "MTKToolFriendlyName", "MTK");
}

int32 UInstaLODMeshToolKitTool::GetOrderId() const
{
	return 7;
}
