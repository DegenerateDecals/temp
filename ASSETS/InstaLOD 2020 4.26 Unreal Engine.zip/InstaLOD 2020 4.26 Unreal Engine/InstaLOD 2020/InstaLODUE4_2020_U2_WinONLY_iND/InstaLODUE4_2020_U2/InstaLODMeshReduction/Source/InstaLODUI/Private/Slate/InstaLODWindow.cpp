/**
 * InstaLODWindow.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODWindow.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODWindow.h"
#include "InstaLODUIPCH.h"

#include "InstaLODModule.h"
#include "Slate/InstaLODPluginStyle.h"
#include "Tools/InstaLODBaseTool.h"
#include "Tools/InstaLODSettings.h"

#include "LevelEditor.h"
#include "IDetailsView.h"
#include "PropertyEditorModule.h"
#include "IDocumentation.h"

#define LOCTEXT_NAMESPACE "InstaLOD"

SInstaLODWindow::SInstaLODWindow()
{
	CurrentTool = 0;
}

SInstaLODWindow::~SInstaLODWindow()
{
	FLevelEditorModule& LevelEditor = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
	LevelEditor.OnActorSelectionChanged().RemoveAll(this);

	// remove all delegates
	USelection::SelectionChangedEvent.RemoveAll(this);
	USelection::SelectObjectEvent.RemoveAll(this);
	FEditorDelegates::MapChange.RemoveAll(this);
	FEditorDelegates::NewCurrentLevel.RemoveAll(this);
}

void SInstaLODWindow::Construct(const FArguments& InArgs)
{
	// reset arrays
	SelectedObjects.Empty();
	SelectedComponents.Empty();
	
	// bind editor delegate to get updates on selected Actors
	FLevelEditorModule& LevelEditor = FModuleManager::GetModuleChecked<FLevelEditorModule>("LevelEditor");
	LevelEditor.OnActorSelectionChanged().AddRaw(this, &SInstaLODWindow::OnActorSelectionChanged);

	// get all currently selected Actors
	USelection* SelectedActors = GEditor->GetSelectedActors();

	for (FSelectionIterator Iter(*SelectedActors); Iter; ++Iter)
	{
		UObject* Actor = Cast<UObject>(*Iter);
		if (Actor)
		{
			SelectedObjects.Add(Actor);
		}
	}

	// reset the selected actor view
	Reset();

	// tools passed by the Module
	RegisteredTools = InArgs._ToolsToRegister;

	// pass each tool a reference to this Window
	for (UInstaLODBaseTool* RegisteredTool : RegisteredTools)
	{
		if (RegisteredTool)
		{
			RegisteredTool->SetInstaLODWindow(this);
		}
	}

	// we need the PropertyModule to create a DetailView
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");

	FDetailsViewArgs DetailsViewArgs;
	DetailsViewArgs.bAllowFavoriteSystem = true;
	DetailsViewArgs.bShowActorLabel = false;
	DetailsViewArgs.bAllowSearch = true;
	DetailsViewArgs.bShowScrollBar = false;
	DetailsViewArgs.bUpdatesFromSelection = false;
	DetailsViewArgs.bHideSelectionTip = true;
	DetailsViewArgs.bShowOptions = true;

	DetailView = PropertyModule.CreateDetailView(DetailsViewArgs);

	ChildSlot
	[
		SNew(SVerticalBox)
	 
		+SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Left)
		.MaxHeight(32.f)
		[
			// InstaLOD Logo
			SNew(SImage)
			.Image(FInstaLODPluginStyle::Get().GetBrush("InstaLODMeshReduction.LogoTiny"))
		]
	 
		+SVerticalBox::Slot()
		.Padding(10)
		.AutoHeight()
		.MaxHeight(128.0f)
		[
			// list of selected actors
			SAssignNew(SelectedActorList, SListView<TSharedPtr<FInstaLODMeshComponent>>)
			.ListItemsSource(&SelectedComponents)
			.OnGenerateRow(this, &SInstaLODWindow::MakeComponentListItemWidget)
		]
	 
		+ SVerticalBox::Slot()
		.AutoHeight()
		[
			// toolbar at the top of the window
			SAssignNew(ToolbarContainer, SBorder)
			.BorderImage(FEditorStyle::GetBrush("NoBorder"))
		]
	 
		+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		[
			SNew(SBorder)
			.BorderImage(FEditorStyle::GetBrush("ToolPanel.GroupBorder"))
			[
				// put a Scrollbox around the content area, in case someone resizes the window smaller
				SNew(SScrollBox)
				+ SScrollBox::Slot()
				.VAlign(VAlign_Fill)
				.HAlign(HAlign_Fill)
				[
					// detail view that shows the details of the used tools (UObject)
					DetailView->AsShared()
				 ]
				+ SScrollBox::Slot()
				.Padding(FMargin(10, 25, 10, 25))
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("InstaLODUI", "WindowFooter",
									"InstaLOD GmbH 2016 - 2020\n"
                                    "http://www.InstaLOD.com\n"
                                    "SDK2020"))
					.Justification(ETextJustify::Center)
				 ]
			]
		]
	];

	UpdateToolbar();
}


int32 SInstaLODWindow::GetNumCameraComponents() const
{
	int32 Count = 0;
	for(const TSharedPtr<FInstaLODMeshComponent>& InstaLODMeshComponent : SelectedComponents)
	{
		if (InstaLODMeshComponent->bShouldBeIncluded && InstaLODMeshComponent->CameraComponent.IsValid())
			Count++;
	}
	return Count;
}

int32 SInstaLODWindow::GetNumStaticMeshsComponents() const
{
	int32 Count = 0;
	for(const TSharedPtr<FInstaLODMeshComponent>& InstaLODMeshComponent : SelectedComponents)
	{
		if (InstaLODMeshComponent->bShouldBeIncluded && InstaLODMeshComponent->StaticMeshComponent.IsValid())
			Count++;
	}
	return Count;
}

int32 SInstaLODWindow::GetNumSkeletalMeshComponents() const
{
	int32 Count = 0;
	for(const TSharedPtr<FInstaLODMeshComponent>& InstaLODMeshComponent : SelectedComponents)
	{
		if (InstaLODMeshComponent->bShouldBeIncluded && InstaLODMeshComponent->SkeletalMeshComponent.IsValid())
			Count++;
	}
	return Count;
}


TArray<TSharedPtr<FInstaLODMeshComponent>> SInstaLODWindow::GetEnabledSelectedComponents() const
{
	return SelectedComponents;
}

TArray<TSharedPtr<FInstaLODMeshComponent>> SInstaLODWindow::GetEnabledSelectedCameraComponents() const
{
	TArray<TSharedPtr<FInstaLODMeshComponent>> MeshComponents;
	
	for (const TSharedPtr<FInstaLODMeshComponent>& MeshComponent : SelectedComponents)
	{
		// ignore unchecked components
		if (!MeshComponent->bShouldBeIncluded)
			continue;
		
		if (MeshComponent->CameraComponent == nullptr)
			continue;
		
		MeshComponents.Add(MeshComponent);
	}
	
	return MeshComponents;
}

TArray<TSharedPtr<FInstaLODMeshComponent>> SInstaLODWindow::GetEnabledSelectedMeshComponents() const
{
	TArray<TSharedPtr<FInstaLODMeshComponent>> MeshComponents;
	
	for (const TSharedPtr<FInstaLODMeshComponent>& MeshComponent : SelectedComponents)
	{
		// ignore unchecked components
		if (!MeshComponent->bShouldBeIncluded)
			continue;
		
		// require either a static mesh or skeletal mesh
		if (MeshComponent->StaticMeshComponent == nullptr &&
			MeshComponent->SkeletalMeshComponent == nullptr)
			continue;
		
		// ensure mesh data exists on the component
		if (MeshComponent->StaticMeshComponent != nullptr &&
			MeshComponent->StaticMeshComponent->GetStaticMesh() == nullptr)
			continue;
		
		if (MeshComponent->SkeletalMeshComponent != nullptr &&
			MeshComponent->SkeletalMeshComponent->SkeletalMesh == nullptr)
			continue;
		
		MeshComponents.Add(MeshComponent);
	}

	return MeshComponents;
}

void SInstaLODWindow::OnActorSelectionChanged(const TArray<UObject*>& NewSelection, bool bForceRefresh)
{
	SelectedObjects = NewSelection;
	Reset();
}

void SInstaLODWindow::UpdateToolbar()
{
	ToolbarContainer->ClearContent();
	DetailView->SetObject(nullptr);

	const ISlateStyle& StyleSet = FEditorStyle::Get();

	// create a SHorizontalBox that we will fill based on the registered tools
	TSharedRef<SHorizontalBox> HorizontalBox = SNew(SHorizontalBox);
	UInstaLODBaseTool* Settings = nullptr;
	int32 SettingsIndex = -1;

	FInstaLODModule& InstaLODModule = FModuleManager::LoadModuleChecked<FInstaLODModule>("InstaLODMeshReduction");

	bool bIsAuthorized = InstaLODModule.GetInstaLODAPI() ? InstaLODModule.GetInstaLODAPI()->IsHostAuthorized() : false;

	for (int32 ToolIndex = 0; ToolIndex < RegisteredTools.Num(); ToolIndex++)
	{
		UInstaLODBaseTool* Tool = RegisteredTools[ToolIndex];

		// save and skip the settings
		if (Tool->GetClass() == UInstaLODSettings::StaticClass())
		{
			Settings = Tool;
			SettingsIndex = ToolIndex;
			continue;
		}

		// make sure we don't create the buttons when we aren't authorized
		if (bIsAuthorized)
		{
			HorizontalBox->AddSlot()
			.MaxWidth(100)
			.Padding(StyleSet.GetMargin("EditorModesToolbar.SToolBarButtonBlock.Padding"))
			[
				SNew(SCheckBox)
				.Style(&StyleSet, "EditorModesToolbar.ToggleButton")
				.OnCheckStateChanged(this, &SInstaLODWindow::OnToolSelectionChanged, ToolIndex)
				.IsChecked(this, &SInstaLODWindow::OnIsToolSelected, ToolIndex)
				.Padding(StyleSet.GetMargin("EditorModesToolbar.SToolBarButtonBlock.CheckBox.Padding"))
				.ToolTip(IDocumentation::Get()->CreateToolTip(Tool->GetToolBarToolTip(), nullptr, FString(), FString()))
				[
					SNew(STextBlock)
					.Text(Tool->GetFriendlyName())
					.Justification(ETextJustify::Center)
				]
			];
		}
	}


	// add settings by hand, as we always want to add them
	HorizontalBox->AddSlot()
	.MaxWidth(100)
	.Padding(StyleSet.GetMargin("EditorModesToolbar.SToolBarButtonBlock.Padding"))
	[
		SNew(SCheckBox)
		.Style(&StyleSet, "EditorModesToolbar.ToggleButton")
		.OnCheckStateChanged(this, &SInstaLODWindow::OnToolSelectionChanged, SettingsIndex)
		.IsChecked(this, &SInstaLODWindow::OnIsToolSelected, SettingsIndex)
		.Padding(StyleSet.GetMargin("EditorModesToolbar.SToolBarButtonBlock.CheckBox.Padding"))
		.ToolTip(IDocumentation::Get()->CreateToolTip(Settings->GetToolBarToolTip(), nullptr, FString(), FString()))
		[
			SNew(STextBlock)
			.Text(Settings->GetFriendlyName())
			.Justification(ETextJustify::Center)
		]
	];

	// show the settings when not authorized
	if (bIsAuthorized == false)
	{
		CurrentTool = SettingsIndex;
	}

	ToolbarContainer->SetContent(HorizontalBox);

	// selection change delegates
	USelection::SelectionChangedEvent.AddRaw(this, &SInstaLODWindow::OnLevelSelectionChanged);
	USelection::SelectObjectEvent.AddRaw(this, &SInstaLODWindow::OnLevelSelectionChanged);
	FEditorDelegates::MapChange.AddSP(this, &SInstaLODWindow::OnMapChange);
	FEditorDelegates::NewCurrentLevel.AddSP(this, &SInstaLODWindow::OnNewCurrentLevel);

	// update the details view
	UpdateDetailsView();
}

void SInstaLODWindow::UpdateDetailsView()
{
	if (RegisteredTools.IsValidIndex(CurrentTool))
	{
		// set the viewed object of the DetailsView
		DetailView->SetObject(RegisteredTools[CurrentTool]);
	}
}

void SInstaLODWindow::ForceRefreshDetailsView()
{
	if (RegisteredTools.IsValidIndex(CurrentTool))
	{
		DetailView->ForceRefresh();
	}
}

void SInstaLODWindow::OnToolSelectionChanged(const ECheckBoxState NewCheckedState, int32 ToolIndex)
{
	if (NewCheckedState == ECheckBoxState::Checked)
	{
		CurrentTool = ToolIndex;
		UpdateDetailsView();
	}
}

TSharedRef<ITableRow> SInstaLODWindow::MakeComponentListItemWidget(TSharedPtr<FInstaLODMeshComponent> MeshComponent, const TSharedRef<STableViewBase>& OwnerTable)
{
	TSharedPtr<SBox> MeshDataBox;

	FText OwningActorName = MeshComponent->IsValid() ? FText::FromString(MeshComponent->GetComponent()->GetOwner()->GetName()) : FText();
	FText ComponentName = MeshComponent->IsValid() ? FText::FromString(MeshComponent->GetComponent()->GetName()) : FText();
	FText MeshName = NSLOCTEXT("InstaLODUI", "NoMeshAvailable", "No Mesh Available");
	
	// fetch persisted state
	ECheckBoxState CheckBoxState = ECheckBoxState::Checked;
	auto PersistedCheckBoxState = MeshComponent->IsValid() ?  PersistedCheckBoxStates.Find(MeshComponent->GetComponent()) : nullptr;
	if (PersistedCheckBoxState)
	{
		CheckBoxState = *PersistedCheckBoxState;
	}
	
	// get mesh names
	if (MeshComponent->IsValid())
	{
		if (MeshComponent->StaticMeshComponent.IsValid() && MeshComponent->StaticMeshComponent->GetStaticMesh() != nullptr)
		{
			MeshName = FText::FromString(MeshComponent->StaticMeshComponent->GetStaticMesh()->GetName());
		}
		else if (MeshComponent->SkeletalMeshComponent.IsValid() && MeshComponent->SkeletalMeshComponent->SkeletalMesh != nullptr)
		{
			MeshName = FText::FromString(MeshComponent->SkeletalMeshComponent->SkeletalMesh->GetName());
		}
		else if (MeshComponent->CameraComponent.IsValid())
		{
			MeshName = NSLOCTEXT("InstaLODUI", "Camera", "Camera");
		}
	}
	
	MeshDataBox = SNew(SBox)
	[
		// disable UI element if the pointer became invalid
		SNew(SHorizontalBox)
		.IsEnabled((MeshComponent->IsValid()))
		+ SHorizontalBox::Slot()
		.AutoWidth()
		[
			SNew(SCheckBox)
			.IsChecked(CheckBoxState)
			.ToolTipText(NSLOCTEXT("InstaLODUI", "IncludeMeshInOperation", "If selected, the mesh will be included in the mesh operation."))
			.OnCheckStateChanged_Lambda([=](ECheckBoxState NewState)
								  {
									  MeshComponent->bShouldBeIncluded = (NewState == ECheckBoxState::Checked);
									  OnNewSelectionDelegate.Broadcast();
								  })
		]
		+ SHorizontalBox::Slot()
		.Padding(5.0, 0, 0, 0)
		.AutoWidth()
		[
			SNew(STextBlock)
			.ColorAndOpacity(FSlateColor(FLinearColor(MeshComponent->CameraComponent.IsValid() ? FColor::Orange : FColor::White)))
			.Text(FText::Format(NSLOCTEXT("InstaLODUI", "UIMeshFormatString", "{0} - {1} ({2})"), OwningActorName, MeshName, ComponentName))
		]
	];

	return SNew(STableRow<TSharedPtr<FInstaLODMeshComponent>>, OwnerTable)
		[
			MeshDataBox->AsShared()
		];
}


void SInstaLODWindow::UpdateSelectedComponents()
{
	// filter by actors
	TArray<AActor*> Actors;
	for (UObject* SelectedObject : SelectedObjects)
	{
		AActor *const Actor = Cast<AActor>(SelectedObject);
		if (Actor == nullptr)
			continue;
		
		Actors.AddUnique(Actor);
	}

	// gather selected components relevant for us
	SelectedComponents.Empty();
	for (int32 ActorIndex = 0; ActorIndex < Actors.Num(); ++ActorIndex)
	{
		AActor *const Actor = Actors[ActorIndex];
		check(Actor != nullptr);

		const bool bIsCameraActor = Cast<ACameraActor>(Actor) != nullptr;
		bool bIncludeChildActors = true;
		
		if (bIsCameraActor)
			bIncludeChildActors = false;
		
		// add all child actors
		if (bIncludeChildActors)
		{
			TArray<UChildActorComponent*> ChildActorComponents;
			Actor->GetComponents<UChildActorComponent>(ChildActorComponents);
			for (UChildActorComponent* ChildComponent : ChildActorComponents)
			{
				AActor *const ChildActor = ChildComponent->GetChildActor();
				if (ChildActor)
				{
					Actors.AddUnique(ChildActor);
				}
			}
		}
		
		// allocate instalod components
		{
			TArray<USceneComponent*> SceneComponents;
			Actor->GetComponents<USceneComponent>(SceneComponents);
			
			for (USceneComponent* SceneComponent : SceneComponents)
			{
				TSharedPtr<FInstaLODMeshComponent> InstaLODMeshComponent;
				
				// only include compatible components
				if (Cast<UStaticMeshComponent>(SceneComponent) != nullptr && !bIsCameraActor)
					InstaLODMeshComponent = TSharedPtr<FInstaLODMeshComponent>(new FInstaLODMeshComponent(Cast<UStaticMeshComponent>(SceneComponent)));
				else if (Cast<USkeletalMeshComponent>(SceneComponent) != nullptr && !bIsCameraActor)
					InstaLODMeshComponent = TSharedPtr<FInstaLODMeshComponent>(new FInstaLODMeshComponent(Cast<USkeletalMeshComponent>(SceneComponent)));
				else if (Cast<UCameraComponent>(SceneComponent) != nullptr)
					InstaLODMeshComponent = TSharedPtr<FInstaLODMeshComponent>(new FInstaLODMeshComponent(Cast<UCameraComponent>(SceneComponent)));
				else
					continue;
				
				auto PersistedCheckBoxState = PersistedCheckBoxStates.Find(InstaLODMeshComponent->GetComponent());
				if (PersistedCheckBoxState)
				{
					InstaLODMeshComponent->bShouldBeIncluded = (*PersistedCheckBoxState == ECheckBoxState::Checked);
				}
				SelectedComponents.Add(InstaLODMeshComponent);
			}
		}
	}

	// rebuild list widget
	if (SelectedActorList.IsValid())
	{
		SelectedActorList->ClearSelection();
		SelectedActorList->RequestListRefresh();
	}	

	OnNewSelectionDelegate.Broadcast();
}

ECheckBoxState SInstaLODWindow::OnIsToolSelected(int32 ToolIndex) const
{
	return (CurrentTool == ToolIndex) ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
}

void SInstaLODWindow::PersistCheckBoxStates()
{
	PersistedCheckBoxStates.Empty();
	for (const TSharedPtr<FInstaLODMeshComponent>& SelectedComponent : SelectedComponents)
	{
		check(SelectedComponent.IsValid());
		
		const ECheckBoxState CheckBoxState = SelectedComponent->bShouldBeIncluded ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
		
		PersistedCheckBoxStates.Add(SelectedComponent->GetComponent(), CheckBoxState);
	}
}

void SInstaLODWindow::OnLevelSelectionChanged(UObject* Object)
{
	Reset();
}

void SInstaLODWindow::OnMapChange(uint32 MapFlags)
{
	Reset();
}

void SInstaLODWindow::OnNewCurrentLevel()
{
	Reset();
}

void SInstaLODWindow::Reset()
{
	PersistCheckBoxStates();
	UpdateSelectedComponents();
}

#undef LOCTEXT_NAMESPACE
