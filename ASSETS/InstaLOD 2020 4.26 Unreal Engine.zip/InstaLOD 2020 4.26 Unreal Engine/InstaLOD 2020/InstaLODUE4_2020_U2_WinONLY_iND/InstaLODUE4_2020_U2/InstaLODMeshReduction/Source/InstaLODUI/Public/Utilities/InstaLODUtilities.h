/**
 * InstaLODUtilities.h (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODUtilities.h
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#pragma once

#include "InstaLODTypes.h"
#include "InstaLOD/InstaLODAPI.h"
#include "InstaLOD/InstaLOD.h"
#include "InstaLOD/InstaLODMeshExtended.h"

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"


struct InstaLODMergeData
{
	FInstaLODMeshComponent* Component;
	InstaLOD::IInstaLODMesh* InstaLODMesh;
};


class UInstaLODUtilities : public UObject
{
public:

	/************************************************************************/
	/* Utilities                                                            */
	/************************************************************************/

	/**
	 * Writes all InstaLOD messages to the log.
	 *
	 * @return true if messages have been written to the log.
	 */
	static bool WriteInstaLODMessagesToLog(class IInstaLOD* InstaLOD);

	/**
	 * FIXME
	 */
	static void CreateMaterialData(IInstaLOD* InstaLOD, TArray<InstaLODMergeData>& InOutComponentsToMerge, class InstaLOD::IInstaLODMaterialData *OutMaterialData, const struct FMaterialProxySettings& InMaterialProxySettings, TArray<UMaterialInterface*>& OutMaterials);

	/**
	*	Appends a Static-/SkeletalMeshComponent to an InstanLODExtendedMesh.
	*
	*	@param		MeshComponent		The MeshComponent holding either Static- or SkeletalMeshComponent
	*	@param		OutInstaLODMesh		InstaLODMesh that we appended to
	*/
	static void AppendMeshComponentToInstaLODMesh(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, class InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex = 0);

	/**
	*	Converts the passed Static-/SkeletalMeshComponent into an InstaLODMesh.
	*
	*	@param		MeshComponent		The MeshComponent holding either Static- or SkeletalMeshComponent
	*	@param		OutInstaLODMesh		Converted InstaLODMesh
	*/
	static void GetInstaLODMeshFromMeshComponent(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, class InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex = 0, bool IsStaticMeshInWorldSpaceRequired = false);

	static void GetInstaLODMeshFromStaticMeshComponent(class IInstaLOD* InstaLOD, class UStaticMeshComponent* StaticMeshComponent, class InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex, bool bWorldSpace);
	static void GetInstaLODMeshFromSkeletalMeshComponent(class IInstaLOD* InstaLOD, class USkeletalMeshComponent* SkeletalMeshComponent, class InstaLOD::IInstaLODMesh* OutInstaLODMesh, int32 BaseLODIndex, class UAnimSequence *const BakePose = nullptr);
	
	/**
	*	Saves the InstaLODMesh Data into the passed Static-/SkeletalMeshComponent.
	*
	*	@param		MeshComponent		The MeshComponent holding either Static- or SkeletalMeshComponent
	*	@param		InstaLODMesh		InstaLODMesh holding the (new) Mesh Data
	*/
	static void InsertLODToMeshComponent(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, class InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial);

	static void InsertLODToStaticMesh(class IInstaLOD* InstaLOD, class UStaticMesh* StaticMesh, class InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial);
	static void InsertLODToSkeletalMesh(class IInstaLOD* InstaLOD, class USkeletalMesh* SkeletalMesh, class InstaLOD::IInstaLODMesh* InstaLODMesh, int32 TargetLODIndex, UMaterialInterface* NewMaterial);


	/**
	 * Updates the Mesh inside of the MeshComponent's Static- or SkeletalMeshComponent.
	 *
	 * @param MeshComponent The MeshComponent holding either Static- or SkeletalMeshComponent
	 * @param NewMesh New Static-/SkeletalMesh
	 */
	static void UpdateMeshOfMeshComponent(TSharedPtr<FInstaLODMeshComponent> MeshComponent, UObject* NewMesh, bool bRemoveOverrideMaterials);
	
	/**
	 * Transforms the specified mesh instance by the specified transform.
	 *
	 * @param InstaLODMesh
	 * @param Transform
	 */
	static void TransformInstaLODMesh(InstaLOD::IInstaLODMesh* InstaLODMesh, const FTransform& Transform, bool LocalToWorld);
	
	/**
	 * FIXME
	 */
	static UMaterialInstanceConstant* CreateFlattenMaterialInstance(const FFlattenMaterial& FlattenMaterial, const FMaterialProxySettings& InMaterialProxySettings, const FString& SaveObjectPath, TArray<UObject*>& OutAssetsToSync, bool bIsFlipbookMaterial = false);
	
	/**
	 * FIXME
	 */
	static UTexture* ConvertInstaLODTexturePageToTexture(InstaLOD::IInstaLODTexturePage* InstaLODTexturePage, const FString& SaveObjectPath);

	/**
	*	Saves an InstanLOD Mesh into a duplicate of an existing Static-/SkeletalMesh Asset.
	*
	*	@param		MeshComponent		The MeshComponent holding either Static- or SkeletalMeshComponent
	*	@param		InstaLODMesh		InstaLODMesh holding the (new) Mesh Data
	*	@param		SaveObjectPath		Previously determined save path for the new object
	*/
	static UObject* SaveInstaLODMeshToDuplicateAsset(class IInstaLOD* InstaLOD, TSharedPtr<FInstaLODMeshComponent> MeshComponent, class InstaLOD::IInstaLODMesh* InstaLODMesh, const FString& SaveObjectPath, bool clearMaterialAndSectionInfo);
	
	/**
	 *	Creates a plane at Zero with with the specified width and face normal (0,0,1).
	 */
	static InstaLOD::IInstaLODMesh* CreatePlane(class IInstaLOD* InstaLOD, const float Width);
	
	/**
	 *	Saves an InstanLOD Mesh to a new StaticMesh Asset.
	 *
	 *	@param		InstaLODMesh		InstaLODMesh holding the (new) Mesh Data
	 *	@param		SaveObjectPath		Previously determined save path for the new object
	 */
	static UObject* SaveInstaLODMeshToStaticMeshAsset(class IInstaLOD* InstaLOD, class InstaLOD::IInstaLODMesh* InstaLODMesh, const FString& SaveObjectPath);


	static void RetrieveMesh(UStaticMeshComponent *const StaticMeshComponent, int32 LODIndex, FMeshDescription& RawMesh, bool bPropagateVertexColours, bool bInWorldSpace);

	static void RemoveAllLODsFromStaticMesh(class UStaticMesh* StaticMesh);
	static void RemoveAllLODsFromSkeletalMesh(class USkeletalMesh* SkeletalMesh);

	/** Opens the Save Dialog and returns the selected path. */
	static FString OpenSaveDialog(const FText& DialogTitle, const FString& DefaultPackageName, const FString &AssetNamePrefix = FString(), bool bMultiSave = false);
};
