/**
 * InstaLODSettings.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODSettings.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODSettings.h"
#include "InstaLODUIPCH.h"

#include "Interfaces/IPluginManager.h"

#include "InstaLODModule.h"
#include "InstaLODUIModule.h"
#include "Utilities/InstaLODUtilities.h"
#include "Slate/InstaLODWindow.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"

UInstaLODSettings::UInstaLODSettings()
{
	FInstaLODModule& InstaLODModule = FModuleManager::LoadModuleChecked<FInstaLODModule>("InstaLODMeshReduction");

	InstaLOD::IInstaLOD* InstaLODAPI = InstaLODModule.GetInstaLODAPI();

	// fetch license information and version
	if (InstaLODAPI)
	{
		LicenseInformation = FText::FromString(ANSI_TO_TCHAR(InstaLODAPI->GetAuthorizationInformation()));
		SDKVersion = FText::FromString(ANSI_TO_TCHAR(InstaLODAPI->GetBuildDate()));
		bAuthorized = InstaLODAPI->IsHostAuthorized();
	}
}

/************************************************************************/
/* Utilities                                                            */
/************************************************************************/

void UInstaLODSettings::ClearLODsFromSelection()
{
	if (MeshComponents.Num() == 0)
		return;

	const FText MessageContents = FText::FromString("Do you really want to clear the selection of all LODs?\nThis will remove all LODs for all Instances of this Mesh and is not undoable.");
	const FText MessageTitle = LOCTEXT("InstaLODClearSelectionTitle", "InstaLOD: Clear Selection of all LODs?");

	if (FMessageDialog::Open(EAppMsgType::Ok, MessageContents, &MessageTitle) == EAppReturnType::Cancel)
		return;

	for (TSharedPtr<FInstaLODMeshComponent> MeshComponent : MeshComponents)
	{
		if (MeshComponent.IsValid())
		{
			if (MeshComponent->StaticMeshComponent.IsValid())
			{
				UStaticMesh *const Mesh = MeshComponent->StaticMeshComponent->GetStaticMesh();

				if (Mesh == nullptr)
					continue;

				UInstaLODUtilities::RemoveAllLODsFromStaticMesh(Mesh);
				Mesh->SetLODGroup(NAME_None);
			}
			else if (MeshComponent->SkeletalMeshComponent.IsValid())
			{
				UInstaLODUtilities::RemoveAllLODsFromSkeletalMesh(MeshComponent->SkeletalMeshComponent->SkeletalMesh);
			}
		}
	}
}

void UInstaLODSettings::AuthorizeWorkstation()
{
	if (AccountName.IsEmpty() == false && SerialPassword.IsEmpty() == false)
	{
		// callback to the InstaLODAPI
		FInstaLODModule& InstaLODModule = FModuleManager::LoadModuleChecked<FInstaLODModule>("InstaLODMeshReduction");
		if (InstaLODModule.GetInstaLODAPI())
		{
			if (InstaLODModule.GetInstaLODAPI()->AuthorizeMachine(TCHAR_TO_UTF8(*AccountName.ToString()), TCHAR_TO_UTF8(*SerialPassword.ToString())))
			{
				const FText MessageTitle = NSLOCTEXT("InstaLODUI", "InstaLODAuthorization", "InstaLOD: Machine Authorization");
				const FText AuthorizedMessageContent = NSLOCTEXT("InstaLODUI", "InstaLODAuthorizationCompleted", "A valid InstaLOD license has been acquired for this machine.\n\nInstaLOD will automatically refresh the license if necessary.");
				FMessageDialog::Open(EAppMsgType::Ok, AuthorizedMessageContent, &MessageTitle);
				
				LicenseInformation = FText::FromString(ANSI_TO_TCHAR(InstaLODModule.GetInstaLODAPI()->GetAuthorizationInformation()));
				bAuthorized = InstaLODModule.GetInstaLODAPI()->IsHostAuthorized();
				
				// This will result in everything being refreshed
				GetInstaLODWindow()->UpdateToolbar();
				GetInstaLODWindow()->ForceRefreshDetailsView();
				
			}
			else
			{
				FText Title = NSLOCTEXT("InstaLODUI", "AuthorizeError_Title", "Authorization Error");
				FString AuthorizationInformation = UTF8_TO_TCHAR(InstaLODModule.GetInstaLODAPI()->GetAuthorizationInformation());
				
				FMessageDialog::Open(EAppMsgType::Ok, FText::FromString("Failed to authorize machine:\n\n" + AuthorizationInformation), &Title);
			}
		}
		else
		{
			FText Title = NSLOCTEXT("InstaLODUI", "AuthorizeError_Title", "Couldn't retrieve InstaLOD Module.");
			FMessageDialog::Open(EAppMsgType::Ok, NSLOCTEXT("InstaLODUI", "AuthorizeError_Message", "Please make sure the InstaLOD Module loaded properly!"), &Title);
		}
	}
	else
	{
		FText Title = NSLOCTEXT("InstaLODUI", "AuthorizeMessage_Title", "No Username or Password!");
		FMessageDialog::Open(EAppMsgType::Ok, NSLOCTEXT("InstaLODUI", "AuthorizeMessage_Message", "Please enter Username and Password!"), &Title);
	}
}

void UInstaLODSettings::DeauthorizeWorkstation()
{
	if (AccountName.IsEmpty() == false && SerialPassword.IsEmpty() == false)
	{
		// callback to the InstaLODAPI
		FInstaLODModule& InstaLODModule = FModuleManager::LoadModuleChecked<FInstaLODModule>("InstaLODMeshReduction");
		if (InstaLODModule.GetInstaLODAPI()->DeauthorizeMachine(TCHAR_TO_UTF8(*AccountName.ToString()), TCHAR_TO_UTF8(*SerialPassword.ToString())))
		{
			LicenseInformation = FText::FromString(ANSI_TO_TCHAR(InstaLODModule.GetInstaLODAPI()->GetAuthorizationInformation()));
			bAuthorized = InstaLODModule.GetInstaLODAPI()->IsHostAuthorized();
			
			// this will result in everything being refreshed
			GetInstaLODWindow()->UpdateToolbar();
			GetInstaLODWindow()->ForceRefreshDetailsView();
		}
	}
	else
	{
		FText Title = NSLOCTEXT("InstaLODUI", "DeauthorizeMessage_Title", "No Username or Password!");
		FMessageDialog::Open(EAppMsgType::Ok, NSLOCTEXT("InstaLODUI", "DeauthorizeMessage_Message", "Please enter Username and Password!"), &Title);
	}
}

void UInstaLODSettings::ResetToolSettings()
{
	FInstaLODUIModule& InstaLODUIModule = FModuleManager::LoadModuleChecked<FInstaLODUIModule>("InstaLODUI");
	TArray<UInstaLODBaseTool*> Tools = InstaLODUIModule.GetAllTools();

	for (UInstaLODBaseTool* Tool : Tools)
	{
		if (Tool)
		{
			Tool->ResetSettings();
		}
	}
}

void UInstaLODSettings::OnlineHelp()
{
	FText Title = NSLOCTEXT("InstaLODUI", "OnlineHelp_Title", "Leaving UE4");
	EAppReturnType::Type Return = FMessageDialog::Open(EAppMsgType::YesNo, NSLOCTEXT("InstaLODUI", "OnlineHelp_Message", "This will open your default browser. Are you sure?"), &Title);

	if (Return == EAppReturnType::Yes)
	{
		FString TheURL = "http://www.InstaLOD.com/GettingStartedWithUE2018";
		FPlatformProcess::LaunchURL(*TheURL, nullptr, nullptr);
	}
}

void UInstaLODSettings::SubmitFeedback()
{
	FText Title = NSLOCTEXT("InstaLODUI", "SubmitFeedback_Title", "Leaving UE4");
	EAppReturnType::Type Return = FMessageDialog::Open(EAppMsgType::YesNo, NSLOCTEXT("InstaLODUI", "SubmitFeedback_Message", "This will open your default email client. Are you sure?"), &Title);

	if (Return == EAppReturnType::Yes)
	{
		FString FeedbackEmail = FString("mailto:support@InstaLOD.com"
										"?Subject=InstaLOD SDK2020 Feedback"
										"&Body=Please enter your feedback below this line:\n"
										"----------------------------------------------------------\n"
										"\n\n\n"
										"\n\n\n"
										"\n\n\n"
										"----------------------------------------------------------\n"
										"Thank you for submitting feedback!\n"
										"\n\n\n"
										"App: InstaLOD for Unreal Engine 2020\n") +
		FString("Version: ") + SDKVersion.ToString() + FString("\n") +
		FString("License Info:\n") + ((bAuthorized == true) ? LicenseInformation.ToString() : FString("N.A.")) + FString("\n");
		
		FeedbackEmail = FeedbackEmail.Replace(TEXT("\r\n"), TEXT("%0D%0A"));
		FeedbackEmail = FeedbackEmail.Replace(TEXT("\n"), TEXT("%0D%0A"));
		FeedbackEmail = FeedbackEmail.Replace(TEXT(" "), TEXT("%20"));
		
		FPlatformProcess::LaunchURL(*FeedbackEmail, nullptr, nullptr);
	}
}

/************************************************************************/
/* UInstaLODBaseTool Interface                                          */
/************************************************************************/

FText UInstaLODSettings::GetFriendlyName() const
{
	return NSLOCTEXT("InstaLODUI", "SettingsFriendlyName", "?");
}

FText UInstaLODSettings::GetToolBarToolTip() const
{
	return NSLOCTEXT("InstaLODUI", "SettingsToolTip", "Shows your License Information and more.");
}

int32 UInstaLODSettings::GetOrderId() const
{
	// just a big number so this is always the last
	return 9999;
}


#undef LOCTEXT_NAMESPACE
