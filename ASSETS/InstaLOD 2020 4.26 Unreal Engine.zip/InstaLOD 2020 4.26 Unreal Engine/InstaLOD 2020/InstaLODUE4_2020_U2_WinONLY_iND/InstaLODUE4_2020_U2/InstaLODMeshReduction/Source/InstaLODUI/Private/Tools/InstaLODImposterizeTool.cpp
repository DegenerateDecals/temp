/**
 * InstaLODImposterizeTool.cpp (InstaLOD)
 *
 * Copyright 2016-2019 InstaLOD GmbH - All Rights Reserved.
 *
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 * This file and all it's contents are proprietary and confidential.
 *
 * @file InstaLODImposterizeTool.cpp
 * @copyright 2016-2019 InstaLOD GmbH. All rights reserved.
 * @section License
 */

#include "InstaLODImposterizeTool.h"
#include "InstaLODUIPCH.h"

#include "PropertyEditorModule.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "InstaLODUI"

UInstaLODImposterizeTool::UInstaLODImposterizeTool() :
Operation(nullptr),
AuxMesh(nullptr),
OperationResult()
{
	SuperSampling = EInstaLODSuperSampling::InstaLOD_None;
	MaterialSettings.BlendMode = BLEND_Masked;
	MaterialSettings.bOpacityMaskMap = true;
	
	bBakeTexturePageOpacity = true;
}

FText UInstaLODImposterizeTool::GetFriendlyName() const
{
	return NSLOCTEXT("InstaLODUI", "ImposterizeToolFriendlyName", "IM");
}

int32 UInstaLODImposterizeTool::GetOrderId() const
{
	return 3;
}

void UInstaLODImposterizeTool::OnMeshOperationExecute(bool bIsAsynchronous)
{
	// --------------------------
	// can be run on child thread
	// --------------------------
	check(Operation == nullptr);
	
	InstaLOD::pfnImposterizeProgressCallback ProgressCallback  = [](class InstaLOD::IImposterizeOperation *, InstaLOD::IInstaLODMesh*, const float ProgressInPercent)
	{
		if (!IsInGameThread())
		{
			AsyncTask(ENamedThreads::GameThread, [ProgressInPercent]() { GWarn->UpdateProgress(ProgressInPercent * 100, 100); });
		}
		else
		{
			GWarn->UpdateProgress(ProgressInPercent * 100, 100);
		}
	};
	
	
	// alloc mesh operation
	Operation = GetInstaLODInterface()->GetInstaLOD()->AllocImposterizeOperation();
	Operation->SetProgressCallback(ProgressCallback);
	Operation->SetMaterialData(MaterialData);
	Operation->AddMesh(InputMesh);
	
	if (AuxMesh != nullptr)
	{
		Operation->AddCloudPolygonalMesh(AuxMesh);
		GetInstaLODInterface()->GetInstaLOD()->DeallocMesh(AuxMesh);
		AuxMesh = nullptr;
	}
	
	// execute
	OperationResult = Operation->Execute(OutputMesh, GetImposterizeSettings());
}

bool UInstaLODImposterizeTool::IsMeshOperationSuccessful() const
{
	return Operation != nullptr && OperationResult.Success;
}

bool UInstaLODImposterizeTool::CanAppendMeshToInput(FInstaLODMeshComponent& Component, InstaLOD::IInstaLODMesh *Mesh, TArray<UMaterialInterface*>* UniqueMaterials)
{
	if (UniqueMaterials == nullptr)
		return true;
	
	if (ImposterizeType != EInstaLODImposterizeType::InstaLOD_HybridBillboardCloud)
		return true;
	
	if (HybridCloudPolyMaterialSuffix.IsEmpty())
		return true;
	
	uint64 FaceCount;
	int32 *FaceMaterials = Mesh->GetFaceMaterialIndices(&FaceCount);
	
	TArray<int32> CloudPolySections;
	TArray<int32> BillboardSections;
	
	for(uint64 FaceIndex=0; FaceIndex<FaceCount; FaceIndex++)
	{
		const int32 MaterialIndex = FaceMaterials[FaceIndex];
		
		check(UniqueMaterials->IsValidIndex(MaterialIndex));
		
		UMaterialInterface* Material = (*UniqueMaterials)[MaterialIndex];
		
		if (Material->GetName().EndsWith(HybridCloudPolyMaterialSuffix))
		{
			CloudPolySections.AddUnique(MaterialIndex);
		}
		else
		{
			BillboardSections.AddUnique(MaterialIndex);
		}
	}
	
	if (CloudPolySections.Num() > 0)
	{
		InstaLOD::IInstaLODMeshExtended *TempMesh = (InstaLOD::IInstaLODMeshExtended*)GetInstaLODInterface()->AllocInstaLODMesh();
		InstaLOD::IInstaLODMeshExtended *SubMesh = (InstaLOD::IInstaLODMeshExtended*)GetInstaLODInterface()->AllocInstaLODMesh();
		
		TempMesh->AppendMesh(Mesh);
		
		// copy the material IDs to the submesh IDs so we can extract by material ID
		TempMesh->ResizeFaceSubMeshIndices(FaceCount);
		
		int32 *TempFaceMaterials = TempMesh->GetFaceMaterialIndices(&FaceCount);
		uint32 *TempFaceSubmeshIndices = TempMesh->GetFaceSubMeshIndices(&FaceCount);
		for(uint64 FaceIndex=0; FaceIndex<FaceCount; FaceIndex++)
		{
			TempFaceSubmeshIndices[FaceIndex] = TempFaceMaterials[FaceIndex];
		}
		
		// ensure the aux mesh is allocated
		if (AuxMesh == nullptr)
			AuxMesh = (InstaLOD::IInstaLODMeshExtended*)GetInstaLODInterface()->AllocInstaLODMesh();
		
		for(int32 MaterialID : CloudPolySections)
		{
			TempMesh->ExtractSubMesh(MaterialID, SubMesh);
			AuxMesh->AppendMesh(SubMesh);
		}
		
		Mesh->Clear();
		for(int32 MaterialID : BillboardSections)
		{
			TempMesh->ExtractSubMesh(MaterialID, SubMesh);
			static_cast<InstaLOD::IInstaLODMeshExtended*>(Mesh)->AppendMesh(SubMesh);
		}
		
		GetInstaLODInterface()->GetInstaLOD()->DeallocMesh(TempMesh);
		GetInstaLODInterface()->GetInstaLOD()->DeallocMesh(SubMesh);
	}
	
	return true;
}

void UInstaLODImposterizeTool::DeallocMeshOperation()
{
	check(Operation);
	GetInstaLODInterface()->GetInstaLOD()->DeallocImposterizeOperation(Operation);
	Operation = nullptr;
}

bool UInstaLODImposterizeTool::IsMeshOperationExecutable(FText* OutErrorText) const
{
	if (GetInstaLODWindow() == nullptr)
		return false;
	
	if (!Super::IsMeshOperationExecutable(OutErrorText))
		return false;
	
	if (ImposterizeType == EInstaLODImposterizeType::InstaLOD_Billboard)
	{
		if (XYAxisQuads_Billboard == 0 && XZAxisQuads_Billboard == 0 && YZAxisQuads_Billboard == 0)
		{
			if (OutErrorText != nullptr)
			{
				*OutErrorText = NSLOCTEXT("InstaLODUI", "NoBillboards", "You need to enable at least one billboard quad axis to create a billboard imposter.");
			}
			return false;
		}
	}
	if (ImposterizeType == EInstaLODImposterizeType::InstaLOD_HybridBillboardCloud)
	{
		if (!bXYAxisQuads && !bXZAxisQuads && !bYZAxisQuads)
		{
			if (OutErrorText != nullptr)
			{
				*OutErrorText = NSLOCTEXT("InstaLODUI", "NoBillboards", "You need to enable at least one billboard quad axis to create a billboard imposter.");
			}
			return false;
		}
	}
	
	return true;
}

InstaLOD::IInstaLODMaterial* UInstaLODImposterizeTool::GetBakeMaterial()
{
	if (!IsMeshOperationSuccessful())
		return nullptr;
	
	return OperationResult.BakeMaterial;
}

void UInstaLODImposterizeTool::FinalizeBakeMaterial(UMaterialInstanceConstant* Material) const
{
	check(Material);
	
	if (ImposterizeType != EInstaLODImposterizeType::InstaLOD_HybridBillboardCloud)
		return;
	
	// we always enable two sided rendering and foliage shading model for billboard cloud imposters
	Material->BasePropertyOverrides.TwoSided = true;
	Material->BasePropertyOverrides.bOverride_TwoSided = true;
	
	Material->BasePropertyOverrides.ShadingModel = MSM_TwoSidedFoliage;
	Material->BasePropertyOverrides.bOverride_ShadingModel = true;
	
	Material->PostEditChange();
}

void UInstaLODImposterizeTool::ResetSettings()
{
	ImposterizeType = EInstaLODImposterizeType::InstaLOD_Billboard;
	GutterSizeInPixels = 2;
	XYAxisQuads_Billboard = 0;
	XZAxisQuads_Billboard = 1;
	YZAxisQuads_Billboard = 1;
	bTwoSidedQuads_Billboard = true;
	SubdivisionsU = 1;
	SubdivisionsV = 1;
	AABB_Displacement = 0;
 	MaximumFaceCount = 400;
	bXYAxisQuads = false;
	bXZAxisQuads = true;
	bYZAxisQuads = true;
	bTwoSidedQuads_Hybrid = true;
	HybridCloudPolyMaterialSuffix = "_cloudpoly";
	FlipbookFramesPerAxis = 8;
	HybridMeshFaceFactor = 50.0f;

	// Reset Parent which ultimately ends in a SaveConfig() call to reset everything
	Super::ResetSettings();
	
	SuperSampling = EInstaLODSuperSampling::InstaLOD_None;
	MaterialSettings.BlendMode = BLEND_Masked;
	MaterialSettings.bOpacityMaskMap = true;
	
	bBakeTexturePageOpacity = true;
	
	// HACK: we have to invoke save settings again as we change some of our parent's default fields
	SaveConfig();
}

InstaLOD::ImposterizeSettings UInstaLODImposterizeTool::GetImposterizeSettings()
{
	InstaLOD::ImposterizeSettings Settings;

	Settings.Type = (InstaLOD::ImposterType::Type)ImposterizeType;
	Settings.FlipbookFramesPerAxis = FlipbookFramesPerAxis;
	Settings.CustomGeometry = nullptr;
	Settings.AABBDisplacement = AABB_Displacement;
	Settings.QuadXYCount = XYAxisQuads_Billboard;
	Settings.QuadXZCount = XZAxisQuads_Billboard;
	Settings.QuadYZCount = YZAxisQuads_Billboard;
	Settings.EnableQuadTwoSided = bTwoSidedQuads_Billboard;
	Settings.QuadSubdivisionsU = SubdivisionsU;
	Settings.QuadSubdivisionsV = SubdivisionsV;
	
	Settings.CloudFaceCount =  MaximumFaceCount;
	Settings.CloudPolyFaceFactor = HybridMeshFaceFactor / 100.0f;
 	Settings.EnableCloudQuadXY = bXYAxisQuads;
	Settings.EnableCloudQuadXZ = bXZAxisQuads;
	Settings.EnableCloudQuadYZ = bYZAxisQuads;
	Settings.EnableCloudQuadTwoSided = bTwoSidedQuads_Hybrid;

	Settings.AlphaCutOut = bIsAlphaCutOutEnabled;
	Settings.AlphaCutOutSubdivide = bIsAlphaCutOutSubdivideEnabled;
	Settings.AlphaCutOutResolution = AlphaCutOutResolution;
	
	Settings.AlphaMaskThreshold = AlphaMaskThreshold;
 	Settings.GutterSizeInPixels = GutterSizeInPixels;
	
	Settings.BakeOutput = GetBakeOutputSettings();
	 
	// FIXME: due to a change in the InstaLOD SDK that affects internal winding order
	// of imposters, we have to flip the Y channel of the normal map
	// this issue will be fixed in an upcoming update.
	if (Settings.Type == InstaLOD::ImposterType::Flipbook)
		Settings.BakeOutput.TangentSpaceFormat = InstaLOD::MeshFormat::OpenGL;

	return Settings;
}

#undef LOCTEXT_NAMESPACE
