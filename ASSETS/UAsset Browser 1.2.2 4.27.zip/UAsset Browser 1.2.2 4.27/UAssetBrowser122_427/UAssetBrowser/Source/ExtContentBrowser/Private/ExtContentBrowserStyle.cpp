// Copyright 2017-2021 marynate. All Rights Reserved.

#include "ExtContentBrowserStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Slate/SlateGameResources.h"
#include "Interfaces/IPluginManager.h"

TSharedPtr< FSlateStyleSet > FExtContentBrowserStyle::StyleInstance = NULL;

FLinearColor FExtContentBrowserStyle::CustomContentBrowserBorderBackgroundColor(.05f, 0.05f, 0.05f, 1.0f);
FLinearColor FExtContentBrowserStyle::CustomToolbarBackgroundColor(0.0f, 0.0f, 0.0f, .2f);
FLinearColor FExtContentBrowserStyle::CustomSourceViewBackgroundColor(0.0f, 0.0f, 0.0f, .1f);
FLinearColor FExtContentBrowserStyle::CustomAssetViewBackgroundColor(0.0f, 0.0f, 0.0f, .1f);


void FExtContentBrowserStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FExtContentBrowserStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

FName FExtContentBrowserStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("UAssetBrowserStyle"));
	return StyleSetName;
}

FSlateFontInfo FExtContentBrowserStyle::GetFontStyle(FName PropertyName, const ANSICHAR* Specifier /*= NULL*/)
{
	return Get().GetFontStyle(PropertyName, Specifier);
}

#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define TTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".ttf") ), __VA_ARGS__ )
#define OTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".otf") ), __VA_ARGS__ )

#define DEFAULT_FONT(...) FCoreStyle::GetDefaultFontStyle(__VA_ARGS__)

const FVector2D Icon12x12(12.0f, 12.0f);
const FVector2D Icon16x16(16.0f, 16.0f);
const FVector2D Icon20x20(20.0f, 20.0f);
const FVector2D Icon24x24(24.0f, 24.0f);
const FVector2D Icon40x40(40.0f, 40.0f);

TSharedRef< FSlateStyleSet > FExtContentBrowserStyle::Create()
{
	TSharedRef< FSlateStyleSet > Style = MakeShareable(new FSlateStyleSet("UAssetBrowserStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("UAssetBrowser")->GetBaseDir() / TEXT("Resources"));

	// Icons
	{
		Style->Set("UAssetBrowser.Icon16x", new IMAGE_BRUSH(TEXT("Icons/UAssetBrowserIcon24"), Icon16x16));
		Style->Set("UAssetBrowser.Icon24x", new IMAGE_BRUSH(TEXT("Icons/UAssetBrowserIcon24"), Icon24x24));
		Style->Set("UAssetBrowser.OpenUAssetBrowser", new IMAGE_BRUSH(TEXT("Icons/UAssetBrowserIcon64"), Icon40x40));
		Style->Set("UAssetBrowser.OpenUAssetBrowser.Small", new IMAGE_BRUSH(TEXT("Icons/UAssetBrowserIcon24"), Icon16x16));
	}

	// Images
	{
		Style->Set("UAssetBrowser.Help", new IMAGE_BRUSH(TEXT("Images/Documentation16"), Icon16x16));

		Style->Set("UAssetBrowser.Rotation16px", new IMAGE_BRUSH(TEXT("Images/Loading"), Icon16x16));
		
		Style->Set("UAssetBrowser.ShowSourcesView", new IMAGE_BRUSH(TEXT("Images/AssetTreeToggleExpanded16"), Icon16x16));
		Style->Set("UAssetBrowser.HideSourcesView", new IMAGE_BRUSH(TEXT("Images/AssetTreeToggleCollapsed16"), Icon16x16));

		Style->Set("UAssetBrowser.ShowDependencyViewer", new IMAGE_BRUSH(TEXT("Images/DependencyViewerExpanded16"), Icon16x16));
		Style->Set("UAssetBrowser.HideDependencyViewer", new IMAGE_BRUSH(TEXT("Images/DependencyViewer16"), Icon16x16));

		Style->Set("UAssetBrowser.ValidationUknown", new IMAGE_BRUSH(TEXT("Images/ValidationUknown"), Icon16x16));
		Style->Set("UAssetBrowser.ValidationValid", new IMAGE_BRUSH(TEXT("Images/ValidationValid"), Icon16x16));
		Style->Set("UAssetBrowser.ValidationInValid", new IMAGE_BRUSH(TEXT("Images/ValidationInValid"), Icon16x16));
		Style->Set("UAssetBrowser.ValidationIssue", new IMAGE_BRUSH(TEXT("Images/ValidationIssue"), Icon16x16));

		// Folder Icons
		Style->Set("UAssetBrowser.AssetTreeFolderDeveloper", new IMAGE_BRUSH("Images/FolderClosed", FVector2D(18, 16))); 
		Style->Set("UAssetBrowser.AssetTreeFolderOpenCode", new IMAGE_BRUSH("Images/FolderOpen_Code", FVector2D(18, 16)));
		Style->Set("UAssetBrowser.AssetTreeFolderClosedCode", new IMAGE_BRUSH("Images/FolderClosed_Code", FVector2D(18, 16)));

		Style->Set("UAssetBrowser.AssetTreeFolderClosed", new IMAGE_BRUSH("Images/FolderClosed", FVector2D(18, 16)));
		Style->Set("UAssetBrowser.AssetTreeFolderOpen", new IMAGE_BRUSH("Images/FolderOpen", FVector2D(18, 16)));
		
		Style->Set("UAssetBrowser.AssetTreeFolderClosedPlugin", new IMAGE_BRUSH("Images/FolderClosed_Plugin", FVector2D(18, 16)));
		Style->Set("UAssetBrowser.AssetTreeFolderOpenPlugin", new IMAGE_BRUSH("Images/FolderOpen_Plugin", FVector2D(18, 16)));

		Style->Set("UAssetBrowser.AssetTreeFolderClosedProject", new IMAGE_BRUSH("Images/FolderClosed_Project", FVector2D(18, 16)));
		Style->Set("UAssetBrowser.AssetTreeFolderOpenProject", new IMAGE_BRUSH("Images/FolderOpen_Project", FVector2D(18, 16)));
		
		Style->Set("UAssetBrowser.AssetTreeFolderClosedVaultCache", new IMAGE_BRUSH("Images/FolderClosed_VaultCache", FVector2D(18, 16)));
		Style->Set("UAssetBrowser.AssetTreeFolderOpenVaultCache", new IMAGE_BRUSH("Images/FolderOpen_VaultCache", FVector2D(18, 16)));
	}

	// Font
	{
		Style->Set("UAssetBrowser.SourceTreeRootItemFont", DEFAULT_FONT("Regular", 12));
		Style->Set("UAssetBrowser.SourceTreeRootItemFont.LoadingFont", DEFAULT_FONT("Regular", 9));

		Style->Set("UAssetBrowser.SourceTreeItemFont", DEFAULT_FONT("Regular", 10));
	}

	// TextStyle
	{
		FTextBlockStyle NormalText = FTextBlockStyle()
			.SetFont(DEFAULT_FONT("Regular", FCoreStyle::RegularTextSize))
			.SetColorAndOpacity(FSlateColor::UseForeground())
			.SetShadowOffset(FVector2D::ZeroVector)
			.SetShadowColorAndOpacity(FLinearColor::Black);

		Style->Set("UAssetBrowser.TopBar.Font", FTextBlockStyle(NormalText)
			.SetFont(DEFAULT_FONT("Bold", 11))
			.SetColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetHighlightColor(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetShadowOffset(FVector2D(1, 1))
			.SetShadowColorAndOpacity(FLinearColor(0, 0, 0, 0.9f)));

		Style->Set("UAssetBrowser.TopBar.DebugFont", FTextBlockStyle(NormalText)
			.SetFont(DEFAULT_FONT("Regular", 10))
			.SetColorAndOpacity(FLinearColor(.7f, .7f, .7f))
			.SetHighlightColor(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetShadowOffset(FVector2D(1, 1))
			.SetShadowColorAndOpacity(FLinearColor(0, 0, 0, 0.9f)));

		Style->Set("UAssetBrowser.ChangeLogHeaderText", FTextBlockStyle(NormalText)
			.SetFont(DEFAULT_FONT("Regular", 10))
			.SetColorAndOpacity(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetHighlightColor(FLinearColor(1.0f, 1.0f, 1.0f))
			.SetShadowOffset(FVector2D(1, 1))
			.SetShadowColorAndOpacity(FLinearColor(0, 0, 0, 0.9f)));

		Style->Set("UAssetBrowser.SourceTreeRootItem.Loading", FTextBlockStyle(NormalText)
			.SetFont(DEFAULT_FONT("Regular", 8))
			.SetColorAndOpacity(FLinearColor(0.6f, 0.6f, 0.6f)));

		Style->Set("UAssetBrowser.AssetThumbnail.EngineOverlay", FTextBlockStyle(NormalText)
			.SetFont(DEFAULT_FONT("Regular", 9))
			.SetColorAndOpacity(FLinearColor(1.0, 1.0, 1.0, 0.9))
			.SetShadowColorAndOpacity(FLinearColor(0, 0, 0, 0.8))
			.SetShadowOffset(FVector2D(1.0f, 1.0f)));
	}

	// Colors
	{
		Style->Set("ErrorReporting.HardReferenceColor", FLinearColor(0.35f, 0, 0));
		Style->Set("ErrorReporting.HardReferenceColor.Darker", FLinearColor(0.35f * 0.6f, 0, 0));
		Style->Set("ErrorReporting.SoftReferenceColor", FLinearColor(0.828f, 0.364f, 0.003f));
		Style->Set("ErrorReporting.SoftReferenceColor.Darker", FLinearColor(0.828f * 0.6f, 0.364f * 0.6f, 0.003f));
	}

	return Style;
}

#undef IMAGE_BRUSH
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef TTF_FONT
#undef OTF_FONT

void FExtContentBrowserStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FExtContentBrowserStyle::Get()
{
	return *StyleInstance;
}
