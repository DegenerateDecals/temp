// Copyright 2017-2021 marynate. All Rights Reserved.

#pragma once

#include "ExtContentBrowserSettings.h"
#include "ExtContentBrowser.h"
#include "ExtAssetData.h"

#include "HAL/FileManager.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "Misc/PackageName.h"
#include "Model.h"
#include "EngineGlobals.h"
#include "UnrealWidget.h"
#include "EditorModeManager.h"
#include "UnrealEdMisc.h"
#include "CrashReporterSettings.h"
#include "Misc/ConfigCacheIni.h" // for FConfigCacheIni::GetString()


/////////////////////////////////////////////////////////////
// UExtContentBrowserSettings implementation
//

UExtContentBrowserSettings::FSettingChangedEvent UExtContentBrowserSettings::SettingChangedEvent;

UExtContentBrowserSettings::UExtContentBrowserSettings(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)

	, NumObjectsToLoadBeforeWarning(0)
	, bOpenSourcesPanelByDefault(true)

	, SearchAndFilterRecursively(true)
	, UseStraightLineInDependencyViewer(true)
	, ShowDependencyViewerUnderAssetView(false)

	, NumObjectsInRecentList(10)
	, bShowFullCollectionNameInToolTip(true)
{
	ResetImportSettings();
	ResetExportSettings();

	ResetViewSettings();
}

void UExtContentBrowserSettings::ResetImportSettings()
{
	bSkipImportIfAnyDependencyMissing = true;
	bImportOverwriteExistingFiles = false;
	bRollbackImportIfFailed = true;
	bImportSyncAssetsInContentBrowser = true;
	bImportSyncExistingAssets = true;
	bLoadAssetAfterImport = true;

	bAddImportedAssetsToCollection = false;
	bUniqueCollectionNameForEachImportSession = false;
	DefaultImportedUAssetCollectionName = FExtAssetContants::DefaultImportedUAssetCollectionName;

	bImportToPluginFolder = false;
	bWarnBeforeImportToPluginFolder = true;
	ImportToPluginName = NAME_None;

	bImportFolderColor = false;
	bOverrideExistingFolderColor = false;

	bImportIgnoreSoftReferencesError = true;
}

void UExtContentBrowserSettings::ResetExportSettings()
{
	bSkipExportIfAnyDependencyMissing = false;
	bExportIgnoreSoftReferencesError = true;
	bExportOverwriteExistingFiles = true;
	bOpenFolderAfterExport = true;
}

void UExtContentBrowserSettings::ResetViewSettings()
{
	DisplayFolders = true;
	DisplayEmptyFolders = true;
	DisplayAssetTooltip = true;
	DisplayEngineVersionOverlay = false;

#if ECB_WIP_VALIDATE_OVERLAY
	DisplayValidationStatusOverlay = true;
#else
	DisplayValidationStatusOverlay = false;
#endif
	DisplayInvalidAssets = false;
	DisplayToolbarButton = true;

	bIgnoreFoldersStartWithDot = true;
	bIgnoreCommonNonContentFolders = true;
	bIgnoreMoreFolders = false;
}

void UExtContentBrowserSettings::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	const FName Name = (PropertyChangedEvent.Property != nullptr)
		? PropertyChangedEvent.Property->GetFName()
		: NAME_None;

	if (!FUnrealEdMisc::Get().IsDeletePreferences())
	{
		SaveConfig();
	}

	SettingChangedEvent.Broadcast(Name);
}
