// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.


#include "SExtBuildProgress.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"
#include "EditorStyleSet.h"
#include "UnrealEdMisc.h"

SBuildProgressWidget::SBuildProgressWidget()
{
}
SBuildProgressWidget::~SBuildProgressWidget()
{
}
SExtBuildProgressWidget::SExtBuildProgressWidget() 
{			
}

SExtBuildProgressWidget::~SExtBuildProgressWidget()
{
}

void SExtBuildProgressWidget::Construct( const FArguments& InArgs )
{
	BorderImage = FInvalidatableBrushAttribute(FEditorStyle::GetBrush("Menu.Background"));
	this->ChildSlot
	.VAlign(VAlign_Center)
	[
		SNew( SVerticalBox )
		+SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Fill)
		.Padding( 10.0f, 4.0f )
		[
			SNew(SBorder)
			[
				SNew( SVerticalBox )
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding( 10.0f, 4.0f )
				[
					SNew( STextBlock )
					.Text( NSLOCTEXT("BuildProgress", "BuildStatusLabel", "Build Status") )
					.ShadowOffset( FVector2D( 1.0f, 1.0f ) )
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding( 10.0f, 4.0f )
				[
					SNew( SHorizontalBox)
					+SHorizontalBox::Slot()
					.AutoWidth()
					.Padding( 0, 7.0f )
					[
						SNew( STextBlock )
						.Text( this, &SExtBuildProgressWidget::OnGetBuildTimeText )
						.ShadowOffset( FVector2D( 1.0f, 1.0f ) )
					]
					+SHorizontalBox::Slot()
					.AutoWidth()
					.Padding(10.0f, 7.0f, 10.0f, 7.0f)
					[
						SNew( STextBlock )
						.Text( this, &SExtBuildProgressWidget::OnGetProgressText )
						.ShadowOffset( FVector2D( 1.0f, 1.0f ) )
					]
				]
			]
		]
		+SVerticalBox::Slot()
		.AutoHeight()
		.HAlign(HAlign_Fill)
		.Padding(10.0f, 1.0f)
		[
			SNew(SBorder)
			[
				SNew( SVerticalBox )
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding( 10.0f, 4.0f )
				[
					SNew( STextBlock )
					.Text( NSLOCTEXT("BuildProgress", "BuildProgressLabel", "Build Progress") )
					.ShadowOffset( FVector2D( 1.0f, 1.0f ) )
				]
				+SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding( 10.0f, 7.0f, 10.0f, 7.0f )
				[
					SNew(SProgressBar)
					.Percent( this, &SExtBuildProgressWidget::OnGetProgressFraction )	
				]
			]

		]
		+SVerticalBox::Slot()
		.AutoHeight()
		.Padding(15.0f, 4.0f)
		.HAlign(HAlign_Center)
		[
			SNew(SHorizontalBox)
			+SHorizontalBox::Slot()
			.AutoWidth()
			[
				SNew(SButton)
				.Text( NSLOCTEXT("BuildProgress", "StopBuildButtonLabel", "Stop Build") )
				.ContentPadding( 5 )
				.OnClicked( this, &SExtBuildProgressWidget::OnStopBuild )
			]
		]
	];

	// Reset progress indicators
	BuildStartTime = -1;
	bStoppingBuild = false;
	SetBuildStatusText( FText::GetEmpty() );
	SetBuildProgressPercent( 0, 100 );
}

FText SExtBuildProgressWidget::OnGetProgressText() const
{
	return ProgressStatusText;
}

void SExtBuildProgressWidget::UpdateProgressText()
{
	if( ProgressNumerator > 0 && ProgressDenominator > 0 )
	{
		FFormatNamedArguments Args;
		Args.Add( TEXT("StatusText"), BuildStatusText );
		Args.Add( TEXT("ProgressCompletePercentage"), FText::AsPercent( (float)ProgressNumerator/ProgressDenominator) );
		ProgressStatusText = FText::Format( NSLOCTEXT("BuildProgress", "ProgressStatusFormat", "{StatusText} ({ProgressCompletePercentage})"), Args );
	}
	else
	{
		ProgressStatusText = BuildStatusText;
	}
}

FText SExtBuildProgressWidget::OnGetBuildTimeText() const
{
	// Only show a percentage if there is something interesting to report
	return BuildStatusTime; 
}

TOptional<float> SExtBuildProgressWidget::OnGetProgressFraction() const
{
	// Only show a percentage if there is something interesting to report
	if( ProgressNumerator > 0 && ProgressDenominator > 0 )
	{
		return (float)ProgressNumerator/ProgressDenominator;
	}
	else
	{
		// Return non-value to indicate marquee mode
		// for the progress bar.
		return TOptional<float>();
	}
}

void SExtBuildProgressWidget::SetBuildType(EBuildType InBuildType)
{
	BuildType = InBuildType;
}

FText SExtBuildProgressWidget::BuildElapsedTimeText() const
{
	// Display elapsed build time.
	return FText::AsTimespan( FDateTime::Now() - BuildStartTime );
}

void SExtBuildProgressWidget::UpdateTime()
{
	BuildStatusTime = BuildElapsedTimeText();
}

void SExtBuildProgressWidget::SetBuildStatusText( const FText& StatusText )
{
	UpdateTime();
	
	// Only update the text if we haven't canceled the build.
	if( !bStoppingBuild )
	{
		BuildStatusText = StatusText;
		UpdateProgressText();
	}
}

void SExtBuildProgressWidget::SetBuildProgressPercent( int32 InProgressNumerator, int32 InProgressDenominator )
{
	UpdateTime();

	// Only update the progress bar if we haven't canceled the build.
	if( !bStoppingBuild )
	{
		ProgressNumerator = InProgressNumerator;
		ProgressDenominator = InProgressDenominator;
		UpdateProgressText();
	}
}

void SExtBuildProgressWidget::MarkBuildStartTime()
{
	BuildStartTime = FDateTime::Now();
}

FReply SExtBuildProgressWidget::OnStopBuild()
{
	FUnrealEdMisc::Get().SetMapBuildCancelled( true );
	
	SetBuildStatusText( NSLOCTEXT("UnrealEd", "StoppingMapBuild", "Stopping Map Build...") );

	bStoppingBuild = true;

	return FReply::Handled();
}
