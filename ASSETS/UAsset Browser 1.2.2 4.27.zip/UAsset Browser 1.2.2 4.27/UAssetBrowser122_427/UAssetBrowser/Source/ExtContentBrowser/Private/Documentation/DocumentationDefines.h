// Copyright 2017-2021 marynate. All Rights Reserved.

#pragma once

#define EXT_DOC_NAMESPACE UAssetBrowserDOC
namespace EXT_DOC_NAMESPACE
{
	const FString DocumentationHostPluginName("UAssetBrowser");
	const FString DocumentationStyleSetName("UAssetBrowserDocStyleSet");
}
using namespace EXT_DOC_NAMESPACE;
